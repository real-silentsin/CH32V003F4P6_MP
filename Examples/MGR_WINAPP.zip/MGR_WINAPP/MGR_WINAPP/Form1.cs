﻿//#define NOW_HWVER_X033
#define NOW_HWVER_V003

// Здесь нужно выбрать для какой ветки идет сборка

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Be.Windows.Forms;
using ssCOMPort;
using TEST.COMport_Work1.Classes;
using TEST.COMport_Work1.Classes.TaskEngine;

namespace TEST.COMport_Work1
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Главная форма приложения
    /// </summary>
    public partial class Form1 : Form
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор формы по умолчанию
        /// </summary>
        public Form1() { InitializeComponent(); }
        // ------------------------------------------------------------------------------------------------------------
#if NOW_HWVER_X033
        /// <summary>
        /// Имя оборудования для ветки CH32X033
        /// </summary>
        public const string CONST_HARDWARE_NAME = "MOD-PCB4-X033";
#endif
        // ------------------------------------------------------------------------------------------------------------
#if NOW_HWVER_V003
        /// <summary>
        /// Имя оборудования для ветки CH32V003
        /// </summary>
        public const string CONST_HARDWARE_NAME = "MOD-PCB4-V003";
#endif
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Список виртуальных портов системы
        /// </summary>
        private ssCOMPortList _cpList;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Оболочка для последовательного порта
        /// </summary>
        private ssCOMPortHelper _helper;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Текущая страница во внешней флеш памяти
        /// </summary>
        private UInt32 flash_current_page = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Текущая страница в локальном хранилище данных
        /// </summary>
        private UInt16 file_current_page = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Текущая конфигурация внешней флеш-памяти
        /// </summary>
        private ProtoHelper.MemoryInfo flash_memory_conf = new ProtoHelper.MemoryInfo();
        private FlashHardware flash_current = new FlashHardware();
        private bool flash_memory_is_actual = false;
        private UInt32 flash_begin_freecontarea_addr = UInt32.MaxValue;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Для индикатора скачивания
        /// </summary>
        private int download_size = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Список адресов страниц, содержащих сегменты указанного файла
        /// </summary>
        private List<UInt16> file_segmetts_idx = new List<ushort>();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Хранилище данных файла
        /// </summary>
        private ProtoSimpleFileClass file_data;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Список файлов на флешке
        /// </summary>
        List<ProtoHelper.FileRecordT> flash_fileList = new List<ProtoHelper.FileRecordT>();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Провайдер для редактора
        /// </summary>
        DynamicByteProvider hex_provider;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Варианы использования реактора
        /// </summary>
        public enum EditorTargetTypes
        {
            FlashMemory,
            LocalFile
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Текущий формат данных файлового хранилища
        /// </summary>
        private ProtoSimpleFileClass.DataTypes currentDataType = ProtoSimpleFileClass.DataTypes.XProto;
        // ------------------------------------------------------------------------------------------------------------
        private int lastModeSelIndex = -1;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка подключена ли поддерживаемая микросхема памяти к адаптеру
        /// </summary>
        /// <returns></returns>
        private bool flash_exists()
        {
            return (FlashManager.GetFlashHwID(flash_current.ChipId) != FlashTypes.FLHW_W25QUNKNOWN);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие загрузки формы
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            // Создание списка портов системы (только виртуальных USB)
            _cpList = new ssCOMPortList();
            _cpList.IncludeHardwarePorts = false;

            _cpList.Refresh();

            // Заполнение списка выбора именами найденных портов
            foreach (var cp in _cpList)
            {
                int newIndex = cbPorts.Items.Add(cp.ToString());
            }

            cbUsePort.Enabled = false;
            cbPortBDR.Enabled = false;

            TaskEngineClass.OnMessage += new EventHandler<SimpleActionEventArgs>(TaskEngineClass_OnMessage);
            TaskEngineClass.OnSend += new EventHandler<SimpleActionDoEventArgs>(TaskEngineClass_OnSend);

            cbEditorTarget.SelectedIndex = 0;
            cbFileTypes.SelectedIndex = 2;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Обработчик событий присоединенных задач
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        void TaskEngineClass_OnMessage(object sender, SimpleActionEventArgs e)
        {
            switch (e.EventType)
            {
                // ----------------------------------------------------------------------------------------------------
                case SimpleEventType.smeError:

                    if (string.IsNullOrEmpty(e.Message) == false)
                    {
                        lbLogs.SelectedIndex = lbLogs.Items.Add(string.Format("{0}>   ERR({1:X2}): {2} \"{3}\"", DateTime.Now.ToLocalTime(), e.Task.Device, e.ErrorCode, e.Message));
                    }
                    else
                    {
                        lbLogs.SelectedIndex = lbLogs.Items.Add(string.Format("{0}>   ERR({1:X2}): {2}", DateTime.Now.ToLocalTime(), e.Task.Device, e.ErrorCode));
                    }

                    TaskEngineClass.RemoveTask(e.Task.Device);

                    break;
                // ----------------------------------------------------------------------------------------------------
                case SimpleEventType.smeLog:

                    if (string.IsNullOrEmpty(e.Message) == false)
                    {
                        lbLogs.SelectedIndex = lbLogs.Items.Add(string.Format("{0}>   DEV({1:X2}): {2}", DateTime.Now.ToLocalTime(), e.Task.Device, e.Message));
                    }

                    break;
                // ----------------------------------------------------------------------------------------------------
                case SimpleEventType.smeComplete:

                    if (string.IsNullOrEmpty(e.Message) == false)
                    {
                        lbLogs.SelectedIndex = lbLogs.Items.Add(string.Format("{0}>   DEV({1:X2}): {2}", DateTime.Now.ToLocalTime(), e.Task.Device, e.Message));
                    }
                    // ------------------------------------------------------------------------------------------------
                    // Получение задачей страницы из флеш
                    if (e.Task is ProtoGetPageActionClass)
                    {
                        ProtoGetPageActionClass task = (e.Task as ProtoGetPageActionClass);
                        if (task != null)
                        {
                            //hexBox1.ByteProvider = null;
                            HEXProv_AcceptData(null, 0);

                            if (Utils.ArrayIsNullOrEmpty(task.PageData) == false)
                            {
                                HEXProv_AcceptData(task.PageData, task.PageIndex);

                                //label3.Text = string.Format("Страница {0} ({1:X8})", task.PageIndex, task.PageIndex * 256);
                                edCurPage.Text = task.PageIndex.ToString();
                            }

                            TaskEngineClass.RemoveTask(task.Device);
                        }

                        progressBar1.Value = 0;
                        return;
                    }
                    // ------------------------------------------------------------------------------------------------
                    // Получение задачей страницы из флеш
                    if (e.Task is ProtoGetFileSegmentActionClass)
                    {
                        ProtoGetFileSegmentActionClass task = (e.Task as ProtoGetFileSegmentActionClass);
                        if (task != null)
                        {
                            //hexBox1.ByteProvider = null;
                            HEXProv_AcceptData(null, 0);

                            if (Utils.ArrayIsNullOrEmpty(task.PageData) == false)
                            {
                                HEXProv_AcceptData(task.PageData, task.PageIndex);

                                //label3.Text = string.Format("Страница {0} ({1:X8})", task.PageIndex, task.PageIndex * 256);
                                edCurPage.Text = task.PageIndex.ToString();
                            }

                            TaskEngineClass.RemoveTask(task.Device);
                        }

                        progressBar1.Value = 0;
                        return;
                    }
                    // ------------------------------------------------------------------------------------------------
                    // Получение задачей страницы из флеш
                    if (e.Task is ProtoReplaceFileSegmentClass)
                    {
                        ProtoReplaceFileSegmentClass task = (e.Task as ProtoReplaceFileSegmentClass);
                        if (task != null)
                        {
                            //hexBox1.ByteProvider = null;
                            HEXProv_AcceptData(null, 0);

                            // Попытка получить измененый сегмент файла (номер страницы флеш изменится!)
                            int device = TaskEngineClass.AddTask<ProtoGetFileSegmentActionClass>(false);
                            if (device > 0)
                            {
                                TaskEngineClass.SetTaskProp<UInt16>((byte)device, "fileid", task.FileID);
                                TaskEngineClass.SetTaskProp<UInt16>((byte)device, "segidx", task.SegmentNum);
                                TaskEngineClass.StartTask((byte)device);
                            }

                            TaskEngineClass.RemoveTask(task.Device);
                        }

                        progressBar1.Value = 0;
                        return;
                    }
                    // ------------------------------------------------------------------------------------------------
                    progressBar1.Value = 0;
                    TaskEngineClass.RemoveTask(e.Task.Device);
                    // ------------------------------------------------------------------------------------------------
                    break;
                // ----------------------------------------------------------------------------------------------------
                case SimpleEventType.smeProgress:

                    try
                    {
                        progressBar1.Value = e.IntValue;
                    }
                    catch { }

                    break;
                // ----------------------------------------------------------------------------------------------------
            }

            Application.DoEvents();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Обработчик событий отправки данных присоединенными задачами
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void TaskEngineClass_OnSend(object sender, SimpleActionDoEventArgs e)
        {
            if (string.IsNullOrEmpty(e.OutgoingData) == false)
            {
                _helper.Send(e.OutgoingData);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие первого показа формы на экране
        /// </summary>
        /// <param name="sender">Инициатр события</param>
        /// <param name="e">Аргументы события</param>
        private void Form1_Shown(object sender, EventArgs e)
        {
            cbPortBDR.SelectedIndex = 5;

            if (_cpList.Count == 0)
            {
                this.BackColor = Color.LightCoral;
                MessageBox.Show("На данном компьютере не найдено виртуальных портов!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение источника редактора
        /// </summary>
        /// <returns>Что редактируем</returns>
        private EditorTargetTypes GetEditorSource()
        {
            switch (cbEditorTarget.SelectedIndex)
            {
                case 1: return EditorTargetTypes.LocalFile;
                default: return EditorTargetTypes.FlashMemory;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение текущих настроек режима работы источника
        /// </summary>
        /// <returns>Режим источника</returns>
        private ProtoIDClass.FileTypes GetCurrentSourceType()
        {
            if (cbFileTypes.SelectedIndex < 0) { return ProtoIDClass.FileTypes.FILE_TYPE_MISC; }
            ProtoIDClass.FileTypes f_type = (ProtoIDClass.FileTypes)cbFileTypes.SelectedIndex;

            return f_type;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение типа источника выделенного в проводнике файла
        /// </summary>
        /// <returns>Тип источника</returns>
        private ProtoIDClass.FileTypes GetSelectedFileSourceType()
        {
            if (cbFileTypes.SelectedIndex < 0) { return ProtoIDClass.FileTypes.FILE_TYPE_MISC; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return ProtoIDClass.FileTypes.FILE_TYPE_MISC; }

            ProtoIDClass.FileTypes f_type = ProtoIDClass.GetFileType(fi.ID);

            return f_type;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Определение выбранного пользователем режима работы
        /// </summary>
        /// <returns>true - протокол, false - непрерывная область</returns>
        private bool IsProtocolSource()
        {
            if (cbFileTypes.SelectedIndex < 0) { return false; }
            ProtoIDClass.FileTypes f_type = GetCurrentSourceType();

            switch (f_type)
            {
                case ProtoIDClass.FileTypes.FILE_TYPE_ICON:
                case ProtoIDClass.FileTypes.FILE_TYPE_IMAGEPROTO:
                case ProtoIDClass.FileTypes.FILE_TYPE_SOUNDPROTO:
                case ProtoIDClass.FileTypes.FILE_TYPE_MISC:
                case ProtoIDClass.FileTypes.FILE_TYPE_OLED_BIN_IMAGE:

                    return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Управление элементами интерфейса
        /// </summary>
        private void RefreshControlInterfase()
        {
            if (_helper == null || _helper.IsOpened == false || flash_exists() == false)
            {
                //cbPorts.Enabled = true;
                //cbUsePort.Enabled = true;

                this.BackColor = Color.LightCoral;
                panel1.Enabled = false;

                btClosePort.Enabled = false;
            }
            else
            {
                //cbPorts.Enabled = false;
                //cbUsePort.Enabled = false;

                this.BackColor = SystemColors.Control;
                panel1.Enabled = true;

                btClosePort.Enabled = true;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Добавить страницу в редактор
        /// </summary>
        /// <param name="data">Добавляемые данные. NULL - очищает редактор</param>
        /// <param name="page_num">Номер отображаемой страницы</param>
        private void HEXProv_AcceptData(byte[] data, UInt32 page_num)
        {
            if (Utils.ArrayIsNullOrEmpty(data))
            {
                //flash_current_page = 0;
                hexBox1.ByteProvider = null;
                hex_provider = null;

                label3.Text = "Данные: <НЕТ>";

                return;
            }

            //flash_current_page = page_num;
            edCurPage.Text = page_num.ToString();

            label3.Text = string.Format("Страница: {0} / 0x{0:X8} (0x{1:X8})", page_num, page_num * 256);

            if (GetEditorSource() == EditorTargetTypes.LocalFile && file_data != null)
            {
                label3.Text += string.Format(", Размер: {0} байтов", file_data.FileLength);
            }

            hex_provider = new DynamicByteProvider(data);
            hexBox1.ByteProvider = hex_provider;

            // Поиск файла в списке которому принадлежит данная страница
            if (GetEditorSource() == EditorTargetTypes.FlashMemory && lvFiles.Items.Count > 0)
            {
                // Цвет заднего плана HEX-редактора
                if (flash_memory_conf.ContAreaBegin > 0 && page_num >= flash_memory_conf.ContAreaBegin)
                {
                    label3.Text += " (непрерывная область памяти)";
                    hexBox1.BackColor = Color.LightPink;
                }
                else
                {
                    hexBox1.BackColor = Color.White;
                }

                ProtoHelper.SectorPageT? header = ProtoHelper.GetProtoPageHeader(data);
                if (header != null)
                {
                    UInt32 fileID = header.Value.ID;
                    ProtoHelper.FileRecordT fi;

                    foreach (ListViewItem item in lvFiles.Items)
                    {
                        if (item.Tag == null) { continue; }

                        try { fi = (ProtoHelper.FileRecordT)item.Tag; }
                        catch { continue; }

                        if (fi.ID == fileID)
                        {
                            lvFiles.SelectedItems.Clear();
                            item.Selected = true;
                            item.Focused = true;
                            lvFiles.EnsureVisible(item.Index);

                            lvFiles.Focus();

                            break;
                        }
                    }
                }
            }

            Application.DoEvents();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Отсылка команды
        /// </summary>
        /// <param name="cmd">Код команды</param>
        /// <param name="param">Параметр</param>
        /// <param name="ext_param">Дополнительный параметр</param>
        /// <returns>Оценка успешности операции</returns>
        private bool Flash_sendCommand(UInt16 cmd, UInt32 param, UInt32 ext_param)
        {
            if (_helper == null || _helper.IsOpened == false) { return false; }

            ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, 0, cmd, param, ext_param);

            string cmd_str = cmdpack.Create();

            if (string.IsNullOrEmpty(cmd_str) == false)
            {
                _helper.Send(cmd_str);

                return true;
            }

            AddToLog("Ошибка создания команды...");

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Установка текущей страницы флеш
        /// </summary>
        /// <param name="pagenum">Новая текущая страница</param>
        private void Flash_setCurrentPage(UInt32 pagenum)
        {
            // --------------------------------------------------------------------------------------------------------
            // Если просматриваем данные локального файла
            if (GetEditorSource() == EditorTargetTypes.LocalFile)
            {
                if (pagenum >= file_data.Count)
                {
                    AddToLog(string.Format("Недопустимый номер страницы: {0}", pagenum));
                    return;
                }

                file_current_page = (ushort)pagenum;

                byte[] page_data = file_data.GetProtoPage((UInt16)pagenum);

                if (Utils.ArrayIsNullOrEmpty(page_data) == false)
                {
                    HEXProv_AcceptData(page_data, pagenum);
                    label3.Text = string.Format("Файл: {0:X4}, Страница: {1}/{2}, Размер: {3}", file_data.ID, pagenum, file_data.Count, file_data.FileLength);
                }

                return;
            }
            // --------------------------------------------------------------------------------------------------------
            if (pagenum >= flash_memory_conf.ChipSize)
            {
                AddToLog(string.Format("Недопустимый номер страницы: {0}", pagenum));
                return;
            }

            flash_current_page = pagenum;

            // Запуск присоединенной задачи для чтения страницы флеш-памяти
            int device = TaskEngineClass.AddTask<ProtoGetPageActionClass>(false);
            if (device > 0)
            {
                TaskEngineClass.SetTaskProp<UInt32>((byte)device, "pageidx", flash_current_page);
                TaskEngineClass.StartTask((byte)device);
            }
            else
            {
                AddToLog("Ошибка создания команды...");
            }
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие изменения выбора порта
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void cbUsePort_CheckedChanged(object sender, EventArgs e)
        {
            // --------------------------------------------------------------------------------------------------------
            if (cbUsePort.Checked == false)
            {
                if (_helper != null && _helper.IsOpened)
                {
                    _helper.Close();
                }

                flash_memory_is_actual = false;

                cbPortBDR.Enabled = true;
                cbPorts.Enabled = true;

                return;
            }
            // --------------------------------------------------------------------------------------------------------
            if (cbPorts.SelectedIndex == -1)
            {
                cbUsePort.Checked = false;

                MessageBox.Show("Сначала вы должны выбрать существующий порт!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            // --------------------------------------------------------------------------------------------------------
            if (cbPortBDR.SelectedIndex == -1)
            {
                cbUsePort.Checked = false;

                MessageBox.Show("Сначала вы должны выбрать скорость нового порта!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            // --------------------------------------------------------------------------------------------------------
            int _port_baudrate = 9600;

            switch (cbPortBDR.SelectedIndex)
            {
                case 0:
                    _port_baudrate = 1200;
                    break;

                case 1:
                    _port_baudrate = 1800;
                    break;

                case 2:
                    _port_baudrate = 2400;
                    break;

                case 3:
                    _port_baudrate = 4800;
                    break;

                case 4:
                    _port_baudrate = 7200;
                    break;

                case 5:
                    _port_baudrate = 9600;
                    break;

                case 6:
                    _port_baudrate = 14400;
                    break;

                case 7:
                    _port_baudrate = 19200;
                    break;

                case 8:
                    _port_baudrate = 38400;
                    break;

                case 9:
                    _port_baudrate = 57600;
                    break;

                case 10:
                    _port_baudrate = 115200;
                    break;

                case 11:
                    _port_baudrate = 230400;
                    break;

                case 12:
                    _port_baudrate = 460800;
                    break;

                case 13:
                    _port_baudrate = 921600;
                    break;

                default:
                    _port_baudrate = 9600;
                    break;
            }
            // --------------------------------------------------------------------------------------------------------
            // Открытие выбранного пользователем порта
            if (cbUsePort.Checked)
            {
                cbPortBDR.Enabled = false;
                cbPorts.Enabled = false;

                // Разрешение работы инструментальной панели
                panel1.Enabled = true;

                // ****************************************************************************************************
                // Создание виртуального порта и подписка на события
                _helper = new ssCOMPortHelper();
                _helper.Baudrate = _port_baudrate;

                if (_helper.CreatePort(_cpList[cbPorts.SelectedIndex].SimplePortName) == false)
                {
                    MessageBox.Show("Ошибка создания порта! Работа невозможна...", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                _helper.OnReceived += new ssCOMPortStringEventDelegate(_helper_OnReceived);
                _helper.OnNoAnswerFlagChanged += new EventHandler(_helper_OnNoAnswerFlagChanged);
                _helper.OnPortError += new EventHandler(_helper_OnPortError);
                // ****************************************************************************************************
                //cbPorts.Enabled = false;
                //cbUsePort.Enabled = false;
                RefreshControlInterfase();

                flash_memory_is_actual = false;

                // Запрос имени конечного (за портом) оборудования
                _helper.Send("AW?");
            }
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие возникновения исключительной ситуации
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void _helper_OnPortError(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                EventHandler cb = new EventHandler(_helper_OnPortError);
                try { Invoke(cb, new object[] { sender }); }
                catch { }

                return;
            }
            else
            {
                this.BackColor = Color.LightCoral;
                cbUsePort.Checked = false;

                try { _helper.Port.Close(); }
                catch { }

                RefreshControlInterfase();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Добавить в лог
        /// </summary>
        /// <param name="Value">Строка лога</param>
        private void AddToLog(string Value)
        {
            if (string.IsNullOrEmpty(Value)) { return; }

            if (ProtoHelper.uart_isProtoPacket(Value))
            {
                DecodeIncomingProtoPacket(Value);
                //lbLogs.SelectedIndex = lbLogs.Items.Add(string.Format("{0}>   {1}", DateTime.Now.ToLocalTime(), Value));
            }
            else
            {
                // Оборудование ответило и оно верное...
                if (Utils.StringCompare(Value, CONST_HARDWARE_NAME, false) == 0)
                {
                    // Запрос подключенного чипа памяти
                    _helper.Send("AWFT?");

                    Value = "Оборудование определено...";
                }

                if (Value.StartsWith("FLHW_"))
                {
                    // Запрос подключенного чипа памяти

                    flash_memory_is_actual = false;
                    FlashTypes _cft = FlashTypes.FLHW_W25QUNKNOWN;

                    try { _cft = (FlashTypes)Enum.Parse(typeof(FlashTypes), Value.Trim(' ', '\0'), true); }
                    catch { }

                    if (_cft != FlashTypes.FLHW_W25QUNKNOWN)
                    {
                        flash_current = FlashManager.GetFlashHw(_cft);

                        flash_memory_conf.ChipSize = flash_current.ChipSize;
                        flash_memory_conf.TotalPages = flash_current.ChipSize;
                        flash_current_page = 0;

                        cbEditorTarget.SelectedIndex = 0;
                        Flash_setCurrentPage(flash_current_page);

                        Value = string.Format("Тип подключенного чипа: {0}", _cft);

                        Application.DoEvents();
                        Thread.Sleep(2000);

                        // Запрос файлов
                        //pp2ReqFileList_Click(this, new EventArgs());

                        // Запрос состояния памяти
                        Flash_sendCommand(FlashConst.FLASH_CMD_GET_MEMINFO, 0, 0);
                    }
                }

                // Оборудование ответило - нет флеш памяти!
                if (Utils.StringCompare(Value, "ERRXP:404", false) == 0)
                {
                    // Блокирование приложения
                    flash_current.ChipId = 0;
                    flash_current.ChipSize = 0;
                    flash_current.Total4kSectors = 0;

                    flash_memory_conf.TotalPages = 0;
                    flash_memory_conf.ChipSize = 0;
                    flash_current_page = 0;

                    flash_memory_is_actual = false;

                    Value = "Флеш память отсутствует!";
                }

                lbLogs.SelectedIndex = lbLogs.Items.Add(string.Format("{0}>   {1}", DateTime.Now.ToLocalTime(), Value));

                RefreshControlInterfase();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие изменения флага "нет ответа"
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void _helper_OnNoAnswerFlagChanged(object sender, EventArgs e)
        {
            // ********************************************************************************************************
            // Передача сообщения и аргумента из внешнего потока
            if (this.InvokeRequired) { BeginInvoke((Action)delegate { lbStatus.Text = (_helper.IsNoAnswered) ? "<ожидание ответа>" : "<ОК>"; }); }
            else
            {
                lbStatus.Text = (_helper.IsNoAnswered) ? "<ожидание ответа>" : "<ОК>";
                Application.DoEvents();
            }
            // ********************************************************************************************************
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие приема сообщения из порта
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void _helper_OnReceived(object sender, SimpleStringEventArgs e)
        {
            if (e == null || string.IsNullOrEmpty(e.Message)) { return; }
            // ********************************************************************************************************
            // Передача сообщения и аргумента из внешнего потока
            if (this.InvokeRequired) { BeginInvoke((Action)delegate { AddToLog(e.Message); }); }
            else { AddToLog(e.Message); }
            // ********************************************************************************************************
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Декодирование принятого пакета протокола
        /// </summary>
        /// <param name="IncData">Строка, содержащая данные</param>
        private void DecodeIncomingProtoPacket(string IncData)
        {
            if (string.IsNullOrEmpty(IncData)) { return; }

            byte[] real_data = null;

            ProtoHelper.ProtoHeader? header = ProtoHelper.uart_decodeProto(IncData, out real_data);
            if (header == null || Utils.ArrayIsNullOrEmpty(real_data))
            {
                AddToLog("Принят поврежденный пакет протокола X, пропускаем...");
                return;
            }

            ProtoTargets.ProtoTarget target = ProtoTargets.uart_decodeTarget(header.Value.Target);

            SimpleAction sa = TaskEngineClass.GetTask(target.Device);
            if (sa != null)
            {

                if (sa.Status == SimpleActionStatusTypes.Ready)
                {
                    sa.Invoke(target, real_data);
                }
            }

            switch (target.PackIdent)
            {
                case ProtoTargets.XP_BINDATA_READ_PACKET:

                    ProcessingBINPackets(real_data, header.Value.Target);

                    break;

                case ProtoTargets.XP_BINDATA_PACKET:

                    ProcessingBINPackets(real_data, header.Value.Target);

                    break;

                case ProtoTargets.XP_STATUS_PACKET:

                    ProcessingStatusPackets(real_data, header.Value.Target);

                    break;

                case ProtoTargets.XP_CMD_PACKET:

                    ProtoHelper.CmdPackExT? cmd_t = ProtoHelper.uart_decodeCMDPacket(real_data);

                    if (cmd_t != null)
                    {
                        AddToLog(string.Format("ID: {0:X8}, Cmd: {1:X4}, Param: {2:X8}", cmd_t.Value.Id, cmd_t.Value.Cmd, cmd_t.Value.Param));
                    }

                    break;

                case ProtoTargets.XP_FLASHPAGE_READ_PACKET:

                    ProcessingBINPackets(real_data, header.Value.Target);
                    break;

                default:

                    // Обычный XProto пакет
                    break;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие закрытия формы
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            TaskEngineClass.ClearAll();

            if (_helper != null && _helper.IsOpened)
            {
                _helper.Dispose();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие клика по кнопке "Отправить команду"
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void btSendCMD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(edUserCMD.Text) == false)
            {
                _helper.Send(edUserCMD.Text);
            }

            if (cbAutoClearCMD.Checked) { edUserCMD.Text = string.Empty; }

            this.Invalidate();
            this.Enabled = true;

            edUserCMD.Focus();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие изменения индекса выделенного в списке виртуальных портов
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void cbPorts_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbUsePort.Enabled = (cbPorts.SelectedIndex != -1);
            cbPortBDR.Enabled = (cbPorts.SelectedIndex != -1);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие изменения текста в компоненте пользовательского ввода
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void edUserCMD_TextChanged(object sender, EventArgs e)
        {
            btSendCMD.Enabled = (string.IsNullOrEmpty(edUserCMD.Text) == false);
            label2.Text = string.Format("Символов: {0}", edUserCMD.Text.Length);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие клика по кнопке "Очистить ввод"
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void btClearText_Click(object sender, EventArgs e)
        {
            edUserCMD.Text = string.Empty;
            edUserCMD.Focus();
            //sSArray1.Value = "";
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие клика по кнопке "Закрыть порт"
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        private void btClosePort_Click(object sender, EventArgs e)
        {
            if (_helper != null && _helper.IsOpened)
            {
                _helper.Port.Close();
                _helper.Dispose();
            }

            HEXProv_AcceptData(null, 0);
            lvFiles.Items.Clear();
            edCurPage.Text = "0";
            flash_memory_is_actual = false;

            RefreshControlInterfase();
        }
        // ------------------------------------------------------------------------------------------------------------
        private void lbLogs_DoubleClick(object sender, EventArgs e)
        {
            if (lbLogs.SelectedIndex < 0) { return; }

            string tmp_data = lbLogs.Items[lbLogs.SelectedIndex].ToString();
            if (string.IsNullOrEmpty(tmp_data)) { return; }

            try
            {
                Clipboard.SetText(tmp_data);
            }
            catch { }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ветка обработки бинарных пакетов
        /// </summary>
        /// <param name="Data">Пакет BIN</param>
        /// <param name="Target">Цель</param>
        private void ProcessingBINPackets(byte[] Data, byte Target)
        {
            ProtoHelper.BINPacket? bin_pack = ProtoHelper.uart_decodeBinDataPacket(Data, Target);

            if (bin_pack == null) { return; }

            ProtoTargets.ProtoTarget _target = ProtoTargets.uart_decodeTarget(Target);

            switch (bin_pack.Value.HeaderU32)
            {
                // Пакет с данными непрерывной области
                case FlashConst.FLASH_PACK_FILECONTINFO:

                    List<ProtoHelper.FileRecordT> infos = XProtoSerializer.ParseFileInfo(bin_pack.Value.Data);
                    if (infos != null && infos.Count > 0)
                    {

                        if (infos[0].Type == 3)
                        {
                            flash_begin_freecontarea_addr = infos[0].Address;
                            AddToLog(string.Format("Начало свободной области: {0} ({0:X4})", flash_begin_freecontarea_addr));
                        }
                    }
                    break;

                // Пакет с данными файлов
                case FlashConst.FLASH_PACK_FILEINFO:

                    List<ProtoHelper.FileRecordT> files = XProtoSerializer.ParseFileInfo(bin_pack.Value.Data);

                    if (files != null && files.Count > 0)
                    {
                        foreach (ProtoHelper.FileRecordT file in files)
                        {
                            // Сокрытие системного файла
                            //if (file.ID == 0) { continue; }

                            flash_fileList.Add(file);

                            string fid_str = string.Format("{0:X4} ({0})", file.ID);
                            ListViewItem item = lvFiles.Items.Add(fid_str);
#if NOW_HWVER_X033
                            if (file.Blocks == 1 && file.Size == 15)
                            {
                                item.SubItems.Add(string.Format("{0} ({1}) STUB", file.Blocks, file.Size));
                                item.BackColor = SystemColors.Info;
                            }
                            else
                            {
                                item.SubItems.Add(string.Format("{0} ({1})", file.Blocks, file.Size));
                                item.BackColor = Color.White;
                            }
#else
                            if (file.Blocks == 1 && file.Size == 14)
                            {
                                item.SubItems.Add(string.Format("??? (???) STUB"));
                            } else {
                                item.SubItems.Add(string.Format("??? (???)"));
                            }
#endif

                            int i_idx = (int)ProtoIDClass.GetFileType(file.ID);
                            if (i_idx < cbFileTypes.Items.Count) { item.ImageIndex = i_idx; } else { item.ImageIndex = 2; }

                            item.Tag = file;
                        }
                    }

                    // Снова просим очередной пакет с данными
                    ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, 6, FlashConst.FLASH_CMD_GET_FILESINFO, 0);

                    string cmd_str = cmdpack.Create();

                    if (string.IsNullOrEmpty(cmd_str) == false)
                    {
                        _helper.Send(cmd_str);
                    }
                    else
                    {
                        AddToLog("Ошибка создания команды...");
                    }

                    break;

                case FlashConst.FLASH_PACK_SINGLEFILEINFO:

                    // Получен пакет с одиночным значением свойств файла

                    ProtoHelper.FileRecordT file_f = XProtoSerializer.BytesToStructure<ProtoHelper.FileRecordT>(bin_pack.Value.Data);

                    AddToLog(string.Format("Свойства файла: {0} ({0:X4})", file_f.ID));
                    AddToLog(string.Format("Размер: {0} ({1})", file_f.Size, file_f.Blocks));

                    ProtoIDClass.FileTypes f_type = ProtoIDClass.GetFileType(file_f.ID);
                    string f_type_str = Utils.GetDescription(f_type);

                    AddToLog(string.Format("Тип файла: {0}", f_type_str));

                    break;

                case FlashConst.FLASH_PACK_MEMINFO:

                    // Получен пакет с данными о занимаемой памяти

                    ProtoHelper.MemoryInfo mem_info = new ProtoHelper.MemoryInfo();

                    mem_info = XProtoSerializer.BytesToStructure<ProtoHelper.MemoryInfo>(bin_pack.Value.Data);

                    // Обновление актуальной информации о чипе
                    flash_memory_conf.ContAreaBegin = mem_info.ContAreaBegin;
                    flash_memory_conf.TotalPages = mem_info.TotalPages;
                    flash_memory_conf.ChipSize = mem_info.ChipSize;

                    uint contarea_size = mem_info.ChipSize - mem_info.ContAreaBegin;

                    AddToLog(string.Format("MEM BAD: {0}", mem_info.BadPages));
                    AddToLog(string.Format("MEM USED: {0}", mem_info.UsedPages));
                    AddToLog(string.Format("MEM TRASH: {0}", mem_info.TrashPages));
                    AddToLog(string.Format("MEM FREE: {0}", mem_info.FreePages));
                    AddToLog(string.Format("MEM TOTAL: {0}", mem_info.TotalPages));
                    AddToLog(string.Format("CHIP TOTAL: {0}", mem_info.ChipSize));
                    AddToLog(string.Format("CONT AREA: {0}", mem_info.ContAreaBegin));
                    AddToLog(string.Format("CONT FREE: {0} из {1}", mem_info.ContAreaFree, contarea_size));

                    flash_memory_is_actual = true;

                    if (lvFiles.Items.Count == 0)
                    {
                        Flash_sendCommand(FlashConst.FLASH_CMD_GET_FILES, 0, 0);
                    }

                    break;

                case FlashConst.FLASH_PACK_PAGEDATA:

                    HEXProv_AcceptData(bin_pack.Value.Data, bin_pack.Value.HeaderU32);
                    //label3.Text = string.Format("Адрес/страница: {0:X8}", bin_pack.Value.HeaderU32);

                    break;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Ветка обработки статусных пакетов
        /// </summary>
        /// <param name="Data">Пакет BIN</param>
        /// <param name="Target">Цель</param>
        private void ProcessingStatusPackets(byte[] Data, byte Target)
        {
            ProtoHelper.BINPacket? state_pack = ProtoHelper.uart_decodeBinDataPacket(Data, Target);

            if (state_pack == null) { return; }

            byte status_code = state_pack.Value.Data[0];

            ProtoTargets.ProtoTarget _target = ProtoTargets.uart_decodeTarget(Target);

            // Передача задаче предназначенный ей код ответа
            SimpleAction sa = TaskEngineClass.GetTask(_target.Device);
            if (sa != null)
            {

                if (sa.Status == SimpleActionStatusTypes.Ready)
                {
                    sa.IncomingResponce(status_code);
                    return;
                }
            }

            switch (status_code)
            {
                case FlashConst.FLASH_STATE_FILEINFO_DONE:

                    // Список файлов передан полностью
                    // Запрос начала свободной области
                    Flash_sendCommand(FlashConst.FLASH_CMD_FINDCONTPLACE, 0, 0);
                    break;

                case FlashConst.FLASH_STATE_FILEINFO_ERR:

                    break;

                case FlashConst.FLASH_STATE_MAPDATA_ERR:

                    file_segmetts_idx.Clear();
                    break;

                case FlashConst.FLASH_STATE_MAPDATA_DONE:

                    AddToLog("Список файлов успешно загружен!");
                    return;

                case FlashConst.FLASH_STATE_DELFILE_OK:

                    AddToLog("Файл успешно удален!");
                    return;

                case FlashConst.FLASH_STATE_DELFILE_FAILED:

                    AddToLog("ERR: Удаление файла не удалось...");
                    return;

                case FlashConst.FLASH_STATE_GCC_COMPLETE:

                    AddToLog(string.Format("Уборка мусора завершена: {0}", state_pack.Value.HeaderU32));
                    return;

                case FlashConst.FLASH_STATE_ERASE_CONTMEM_OK:

                    AddToLog("Очистка непрерывной области памяти успешно завершена.");
                    break;

                case FlashConst.FLASH_STATE_WIPEALL_DONE:

                    AddToLog("ПОЛНАЯ очистка флеш памяти успешно завершена.");
                    break;

                case FlashConst.FLASH_STATE_GO_REBOOT_NOW:

                    AddToLog("SYS: Система перезагружается...");
                    _helper.Close();

                    RefreshControlInterfase();
                    return;
            }

            AddToLog(string.Format("Ident: {0:X8}, Status: {1}", state_pack.Value.HeaderU32, state_pack.Value.Data[0]));
        }
        // ------------------------------------------------------------------------------------------------------------
        private void button1_Click(object sender, EventArgs e)
        {
            _helper.ClearPort();
            lbLogs.Items.Clear();
            lvFiles.Items.Clear();
            cbEditorTarget.SelectedIndex = 0;
            progressBar1.Value = 0;

            currentDataType = ProtoSimpleFileClass.DataTypes.XProto;

            if (file_data != null)
            {
                file_data.Dispose();
                file_data = null;
            }

            HEXProv_AcceptData(null, 0);

            edCurPage.Text = "0";
            textBox1_TextChanged(this, new EventArgs());

            flash_current_page = 0;
            file_current_page = 0;

            Flash_setCurrentPage(flash_current_page);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            btSetCurPage.Enabled = (string.IsNullOrEmpty(edCurPage.Text) == false);
            btAddPageNum.Enabled = (string.IsNullOrEmpty(edCurPage.Text) == false);
            btSubPageNum.Enabled = (string.IsNullOrEmpty(edCurPage.Text) == false);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void btSetCurPage_Click(object sender, EventArgs e)
        {
            UInt16 newpage = 0;

            if (UInt16.TryParse(edCurPage.Text, out newpage))
            {
                edCurPage.Text = newpage.ToString();

                if (cbSetFileID.Checked && file_data != null)
                {
                    newpage = ProtoIDClass.MakeId((ProtoIDClass.FileTypes)cbFileTypes.SelectedIndex, newpage);

                    file_data.ID = newpage;
                    edCurPage.Text = (GetEditorSource() == EditorTargetTypes.LocalFile) ? file_current_page.ToString() : flash_current_page.ToString();
                    cbSetFileID.Checked = false;

                    if (file_data != null && file_data.Count > 0) { file_data.ID = newpage; }

                    Flash_setCurrentPage(0);

                    return;
                }

                if (GetEditorSource() == EditorTargetTypes.LocalFile)
                {
                    if (file_data == null || file_data.Count == 0)
                    {
                        file_current_page = 0;
                        HEXProv_AcceptData(null, 0);

                        return;
                    }

                    if (file_data != null)
                    {
                        if (newpage < file_data.Count)
                        {
                            Flash_setCurrentPage(newpage);
                        }
                        else
                        {
                            edCurPage.Text = file_data.Count.ToString();
                        }
                    }
                }
                else
                {
                    if (newpage < flash_memory_conf.ChipSize)
                    {
                        Flash_setCurrentPage(newpage);
                    }
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void btAddPageNum_Click(object sender, EventArgs e)
        {
            UInt16 newpage = 0;

            if (UInt16.TryParse(edCurPage.Text, out newpage))
            {
                newpage += 1;
                edCurPage.Text = newpage.ToString();

                if (GetEditorSource() == EditorTargetTypes.LocalFile)
                {
                    if (newpage < file_data.Count)
                    {
                        Flash_setCurrentPage(newpage);
                    }
                    else
                    {
                        edCurPage.Text = file_data.Count.ToString();
                    }
                }
                else
                {
                    if (newpage < flash_memory_conf.ChipSize)
                    {
                        Flash_setCurrentPage(newpage);
                    }
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void btSubPageNum_Click(object sender, EventArgs e)
        {
            UInt16 newpage = 0;

            if (UInt16.TryParse(edCurPage.Text, out newpage))
            {
                newpage -= 1;
                edCurPage.Text = newpage.ToString();

                if (GetEditorSource() == EditorTargetTypes.LocalFile)
                {
                    if (newpage < file_data.Count)
                    {
                        Flash_setCurrentPage(newpage);
                    }
                    else
                    {
                        edCurPage.Text = file_data.Count.ToString();
                    }
                }
                else
                {
                    if (newpage < flash_memory_conf.ChipSize)
                    {
                        Flash_setCurrentPage(newpage);
                    }
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppReadEEPROM_Click(object sender, EventArgs e)
        {
            if (flash_current_page < flash_memory_conf.ChipSize)
            {
                Flash_setCurrentPage(flash_current_page);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppSaveDumpToFile_Click(object sender, EventArgs e)
        {
            // --------------------------------------------------------------------------------------------------------
            if (hex_provider == null) { return; }
            // --------------------------------------------------------------------------------------------------------
            byte[] send_data = hex_provider.Bytes.ToArray();
            if (Utils.ArrayIsNullOrEmpty(send_data) || send_data.Length != 256)
            {
                return;
            }
            // --------------------------------------------------------------------------------------------------------
            if (GetEditorSource() == EditorTargetTypes.FlashMemory)
            {
                int taskLoadFile = TaskEngineClass.AddTask<ProtoReplaceFileSegmentClass>(false);

                if (taskLoadFile < 0)
                {
                    AddToLog("ОШИБКА: Задача сохранения изменений не работает!");
                    return;
                }

                ProtoReplaceFileSegmentClass task = (TaskEngineClass.GetTask((byte)taskLoadFile) as ProtoReplaceFileSegmentClass);
                if (task == null) { return; }

                if (task.SetProp<byte[]>("pagedata", send_data) == false)
                {
                    AddToLog("ОШИБКА: Задача сохранения изменений не работает!");

                    TaskEngineClass.RemoveTask(task.Device);
                    return;
                }

                task.Start();
                return;
            }
            // --------------------------------------------------------------------------------------------------------
            if (GetEditorSource() == EditorTargetTypes.LocalFile && file_data != null && file_data.Count > 0)
            {
                if (file_current_page < file_data.Count)
                {

                    file_data.Accept(file_current_page, send_data, true);
                    HEXProv_AcceptData(file_data.GetProtoPage(file_current_page), file_current_page);
                }

                return;
            }
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppEraseSect0_Click(object sender, EventArgs e)
        {
            UInt16 newpage = 0;

            if (UInt16.TryParse(edCurPage.Text, out newpage) == false)
            {
                AddToLog("ОШИБКА: Ошибка в указании номера сектора!");
                return;
            }

            if (newpage > (flash_memory_conf.ChipSize / 16))
            {
                AddToLog("ОШИБКА: Ошибка в указании номера сектора!");
                return;
            }

            ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, 0, FlashConst.FLASH_CMD_ERASE_SECTOR, newpage);

            string cmd_str = cmdpack.Create();

            if (string.IsNullOrEmpty(cmd_str) == false)
            {
                _helper.Send(cmd_str);
            }
            else
            {
                AddToLog("Ошибка создания команды...");
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppLoadFromFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Загрузка данных из файла";
                dialog.Filter = "Все файлы|*.*";

                if (file_data != null) { file_data.Dispose(); }

                currentDataType = ProtoSimpleFileClass.DataTypes.XProto;
                file_data = new ProtoSimpleFileClass(ProtoSimpleFileClass.DataTypes.XProto);

                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    file_data.Clear();
                    if (file_data.Load(dialog.FileName) == false)
                    {
                        file_data.Clear();
                        MessageBox.Show("Ошибка загрузки файла!");
                    }
                    else
                    {
                        byte[] page0 = file_data.GetProtoPage(0);

                        if (Utils.ArrayIsNullOrEmpty(page0) == false)
                        {
                            HEXProv_AcceptData(page0, 0);

                            label3.Text = string.Format("Файл: {0:X4}, Страница: {1}/{2}", file_data.ID, 0, file_data.Count);

                            file_current_page = 0;
                            cbEditorTarget.SelectedIndex = 1;
                            edCurPage.Text = "0";
                        }
                    }
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppLoadFromFileBin_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Загрузка данных из файла";
                dialog.Filter = "Все файлы|*.*";

                if (file_data != null) { file_data.Dispose(); }

                currentDataType = ProtoSimpleFileClass.DataTypes.Binary;
                file_data = new ProtoSimpleFileClass(ProtoSimpleFileClass.DataTypes.Binary);

                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    file_data.Clear();
                    if (file_data.Load(dialog.FileName) == false)
                    {
                        file_data.Clear();
                        MessageBox.Show("Ошибка загрузки файла!");
                    }
                    else
                    {
                        byte[] page0 = file_data.GetProtoPage(0);

                        if (Utils.ArrayIsNullOrEmpty(page0) == false)
                        {
                            HEXProv_AcceptData(page0, 0);

                            label3.Text = string.Format("Файл: {0:X4}, Страница: {1}/{2}", file_data.ID, 0, file_data.Count);

                            file_current_page = 0;
                            cbEditorTarget.SelectedIndex = 1;
                            edCurPage.Text = "0";
                        }
                    }
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            bool enabled = (_helper != null && _helper.IsOpened);

            if (enabled == false)
            {
                foreach (var menu_item in contextMenuStrip1.Items)
                {
                    if (menu_item is ToolStripMenuItem)
                    {
                        (menu_item as ToolStripMenuItem).Enabled = false;
                    }
                }

                return;
            }

            bool isLocalRes = (GetEditorSource() == EditorTargetTypes.LocalFile);

            bool isProtoRes = IsProtocolSource();

            ppSavePageToFlash.Enabled = isProtoRes && isLocalRes && (hex_provider != null && hex_provider.HasChanges());
            ppGetMemInfo.Enabled = true;
            ppMakeFlashPage.Enabled = (GetEditorSource() == EditorTargetTypes.LocalFile && hex_provider != null);
            ppSaveFileToFlash.Enabled = (file_data != null && file_data.IsValid(true) && isLocalRes && file_data.DataType == ProtoSimpleFileClass.DataTypes.XProto && isProtoRes);
            ppSaveFileToCont.Enabled = (file_data != null && file_data.IsValid(true) && isLocalRes && file_data.DataType == ProtoSimpleFileClass.DataTypes.Binary && !isProtoRes);
            ppReadEEPROM.Enabled = (GetEditorSource() == EditorTargetTypes.FlashMemory);
            ppLoadFromFileBin.Enabled = !isProtoRes;
            ppLoadFromFileProto.Enabled = isProtoRes;

            ppClearLocalFile.Enabled = (file_data != null && isLocalRes && file_data.Count > 0);

            ppContStubDecode.Enabled = false;

            if (hex_provider != null && hex_provider.Length > 0)
            {
                if (hex_provider.ReadByte(0) == ProtoHelper.SECTOR_STATUS_LAST_USABLE)
                {
                    ppContStubDecode.Enabled = true;
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppSaveFileToFlash_Click(object sender, EventArgs e)
        {
            if (file_data.DataType != ProtoSimpleFileClass.DataTypes.XProto) { return; }

            if (file_data.IsValid(true) == false)
            {
                AddToLog("ОШИБКА: Данные в локальном хранилище не валидные!");
                return;
            }

            if (flash_memory_is_actual == false)
            {
                AddToLog("ОШИБКА: Нет данных о разметке флеши. Запросите сначала информацию о памяти!");
                return;
            }

            int taskLoadFile = TaskEngineClass.AddTask<TaskSendFileClass>(false);

            if (taskLoadFile < 0)
            {
                AddToLog("ОШИБКА: Задача копирования файла во флеш не работает!");
                return;
            }

            TaskSendFileClass task = (TaskEngineClass.GetTask((byte)taskLoadFile) as TaskSendFileClass);
            if (task == null) { return; }

            if (task.CopyData(file_data, file_data.DataType) == false)
            {
                TaskEngineClass.RemoveTask(task.Device);
                return;
            }

            task.Start();
            AddToLog("Начинается сохранение файла на флеш. Ждите...");
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppSaveFileToCont_Click(object sender, EventArgs e)
        {
            if (file_data.IsValid(true) == false)
            {
                AddToLog("ОШИБКА: Данные в локальном хранилище не валидные!");
                return;
            }

            if (file_data.DataType != ProtoSimpleFileClass.DataTypes.Binary) { return; }

            if (flash_memory_is_actual == false)
            {
                AddToLog("ОШИБКА: Нет данных о разметке флеши. Запросите сначала информацию о памяти!");
                return;
            }

            int taskLoadFile = TaskEngineClass.AddTask<TaskSendContFileClass>(false);

            if (taskLoadFile < 0)
            {
                AddToLog("ОШИБКА: Задача копирования файла во флеш не работает!");
                return;
            }

            TaskSendContFileClass task = (TaskEngineClass.GetTask((byte)taskLoadFile) as TaskSendContFileClass);
            if (task == null) { return; }

            if (task.CopyData(file_data, file_data.DataType) == false)
            {
                TaskEngineClass.RemoveTask(task.Device);
                return;
            }

            /* // Если это звук - расширяем страницы кодом тишины (0x7F)
            if (cbDataIsSound.Checked)
            {
                task.SetProp<bool>("expand", true);
                task.SetProp<byte>("tilevalue", (byte)0x7F);
            } */

            task.Start();
            AddToLog("Начинается сохранение файла на флеш. Ждите...");
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppWipeAllFlash_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно желаете очистить всю флеш-память?", this.Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, 0, FlashConst.FLASH_CMD_WIPE_ALL, 0);

                string cmd_str = cmdpack.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    _helper.Send(cmd_str);
                    AddToLog("Начинается полная очистка флеш-памяти. Ждите...");
                }
                else
                {
                    AddToLog("Ошибка создания команды...");
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppDeleteFileByID_Click(object sender, EventArgs e)
        {
            UInt16 newpage = 0;

            if (UInt16.TryParse(edCurPage.Text, out newpage) == false)
            {
                AddToLog("ОШИБКА: Ошибка в указании ID файла!");
                return;
            }

            int device = TaskEngineClass.AddTask<ProtoDeleteFileActionClass>(false);

            if (device < 1)
            {
                AddToLog("ОШИБКА: Задача удаления файла не создана!");
                return;
            }

            TaskEngineClass.SetTaskProp<UInt16>((byte)device, "fileidx", newpage);
            if (TaskEngineClass.TaskIsValid((byte)device))
            {
                TaskEngineClass.StartTask((byte)device);
            }
            else
            {
                TaskEngineClass.RemoveTask((byte)device);
                AddToLog("ОШИБКА: Задача не подтверждает целостность данных!");
                return;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppMakeFlashPage_Click(object sender, EventArgs e)
        {
            if (hex_provider == null) { return; }

            UInt16 newpage = 0;

            if (UInt16.TryParse(edCurPage.Text, out newpage) == false)
            {
                AddToLog("ОШИБКА: Ошибка в указании ID файла!");
                return;
            }

            // Получение данных из HEX редактора
            UInt16 src_length = (UInt16)hex_provider.Length;
            if (src_length > 249) { src_length = 249; }

            byte[] new_data = new byte[src_length];

            // Пропускаем заголовок (извлекаем 249 байт)
            for (int src_index = 0; src_index < src_length; src_index++)
            {
                new_data[src_index] = hex_provider.ReadByte(src_index + 7);
            }

            byte[] page_data = ProtoHelper.CreateFlashPage(new_data, newpage, 0);

            if (page_data != null)
            {
                HEXProv_AcceptData(page_data, flash_current_page);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void contextMenuStrip2_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            bool selected_exists = (lvFiles.SelectedItems.Count > 0);
            bool isFlashSrc = (GetEditorSource() == EditorTargetTypes.FlashMemory);

            ProtoIDClass.FileTypes f_type = GetSelectedFileSourceType();

            pp2DownloadFile.Enabled = selected_exists;
            pp2DeleteFile.Enabled = selected_exists;
            ppShowAsBMP.Enabled = (selected_exists && (f_type == ProtoIDClass.FileTypes.FILE_TYPE_IMAGECONT || f_type == ProtoIDClass.FileTypes.FILE_TYPE_OLED_BIN_IMAGE));
            ppPlaySound.Enabled = (selected_exists && (f_type == ProtoIDClass.FileTypes.FILE_TYPE_SOUNDPROTO));
            ppPlayTestSound.Enabled = true;
            pp2ViewSelectFileBlock.Enabled = selected_exists && isFlashSrc;
            ppPlaySondContArea.Enabled = (selected_exists && (f_type == ProtoIDClass.FileTypes.FILE_TYPE_SOUNDCONT));
            ppFileProperties.Enabled = selected_exists;
        }
        // ------------------------------------------------------------------------------------------------------------
        private void pp2DownloadFile_Click(object sender, EventArgs e)
        {

            if (lvFiles.SelectedItems[0].Tag == null) { return; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return; }

            string Filename = null;

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = "Сохранение файла";
                dialog.Filter = "Бинарные файлы|*.bin|Все файлы|*.*";

                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    Filename = dialog.FileName;
                }
            }

            if (string.IsNullOrEmpty(Filename)) { return; }

            int taskLoadFile = TaskEngineClass.AddTask<ProtoFileDownloaderClass>(false);

            if (taskLoadFile < 1)
            {
                AddToLog("ОШИБКА: Задача скачивания файла не работает!");
                return;
            }

            ProtoFileDownloaderClass task = (TaskEngineClass.GetTask((byte)taskLoadFile) as ProtoFileDownloaderClass);
            if (task == null) { return; }

            if (task.SetProp<string>("filename", Filename) == false)
            {
                TaskEngineClass.RemoveTask(task.Device);

                AddToLog("ОШИБКА: Задача скачивания файла удаляется из-за ошибки (Filename)!");
                return;
            }

            task.SetProp<UInt32>("filesize", (UInt32)fi.Size);

            if (task.SetProp<UInt16>("fileid", fi.ID))
            {
                download_size = (int)fi.Size;
                task.Start();
                AddToLog("Началось скачивание файла из флеш-памяти. Ждите...");
            }
            else
            {
                TaskEngineClass.RemoveTask(task.Device);

                AddToLog("ОШИБКА: Задача скачивания файла удаляется из-за ошибки (fileid)!");
                return;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void pp2ReqFileList_Click(object sender, EventArgs e)
        {
            lvFiles.Items.Clear();
            Flash_sendCommand(FlashConst.FLASH_CMD_GET_FILES, 0, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void pp2DeleteFile_Click(object sender, EventArgs e)
        {
            if (lvFiles.SelectedItems.Count == 0) { return; }
            if (lvFiles.SelectedItems[0].Tag == null) { return; }

            ProtoHelper.FileRecordT fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            if (fi.ID < 1) { return; }

            Flash_sendCommand(FlashConst.FLASH_CMD_ERASE_FILE, fi.ID, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppShowAsBMP_Click(object sender, EventArgs e)
        {
            if (lvFiles.SelectedItems.Count == 0) { return; }
            if (lvFiles.SelectedItems[0].Tag == null) { return; }

            ProtoHelper.FileRecordT fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            if (fi.ID < 1) { return; }

            uint scale = (uint)((cbImage2X.Checked) ? 2 : 1);

            Flash_sendCommand(FlashConst.FLASH_CMD_SHOW_BITMAP, fi.ID, scale);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppShowPromo_Click(object sender, EventArgs e)
        {
            // Показ основной заставки
            Flash_sendCommand(FlashConst.FLASH_CMD_SHOW_BITMAP, 0xFFFF, 1);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void btReboot_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы желаете перезагрузить контроллер?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.No) { return; }

            Flash_sendCommand(FlashConst.FLASH_CMD_SYS_REBOOT, 0x01AD1B72, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppGetMemInfo_Click(object sender, EventArgs e)
        {
            Flash_sendCommand(FlashConst.FLASH_CMD_GET_MEMINFO, 0, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppGoGCC_Click(object sender, EventArgs e)
        {
            Flash_sendCommand(FlashConst.FLASH_CMD_GO_GCC, 0, 0);
            AddToLog("Начинается оптимизация флеш-памяти. Ждите...");
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppPlaySound_Click(object sender, EventArgs e)
        {
            if (lvFiles.SelectedItems[0].Tag == null) { return; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return; }

            AddToLog("Начинается воспроизведение звука. Ждите...");
            Flash_sendCommand(FlashConst.FLASH_CMD_PLAY_SND, fi.ID, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppPlayTestSound_Click(object sender, EventArgs e)
        {
            Flash_sendCommand(FlashConst.FLASH_CMD_PLAY_TEST_SND, 0, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppPlaySondContArea_Click(object sender, EventArgs e)
        {
            if (lvFiles.SelectedItems[0].Tag == null) { return; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return; }

            AddToLog("Начинается воспроизведение звука. Ждите...");
            Flash_sendCommand(FlashConst.FLASH_CMD_PLAY_CONTSND, fi.ID, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void pp2ViewSelectFileBlock_Click(object sender, EventArgs e)
        {
            // Показать в HEX редакторе выбранный пользователем в поле ввода блок данных
            if (lvFiles.SelectedItems.Count == 0) { return; }
            if (lvFiles.SelectedItems[0].Tag == null) { return; }
            if (GetEditorSource() != EditorTargetTypes.FlashMemory) { return; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return; }

            UInt16 page_idx = 0;

            if (UInt16.TryParse(edCurPage.Text, out page_idx))
            {
                edCurPage.Text = page_idx.ToString();
                AddToLog(string.Format("Файл: {1}, страница: {0}", page_idx, fi.ID));

                // Запуск присоединенной задачи для чтения страницы флеш-памяти
                int device = TaskEngineClass.AddTask<ProtoGetFileSegmentActionClass>(false);
                if (device > 0)
                {
                    TaskEngineClass.SetTaskProp<UInt16>((byte)device, "fileid", fi.ID);
                    TaskEngineClass.SetTaskProp<UInt16>((byte)device, "segidx", page_idx);
                    TaskEngineClass.StartTask((byte)device);
                }
                else
                {
                    AddToLog("Ошибка создания команды...");
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void cbEditorTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbEditorTarget.SelectedIndex)
            {
                case 1:

                    cbSetFileID.Enabled = true;
                    if (currentDataType == ProtoSimpleFileClass.DataTypes.XProto)
                    {
                        hexBox1.BackColor = SystemColors.Info;
                    }
                    else
                    {
                        hexBox1.BackColor = Color.LightBlue;
                    }

                    edCurPage.Text = file_current_page.ToString();

                    break;

                default:

                    cbSetFileID.Enabled = false;

                    if (currentDataType == ProtoSimpleFileClass.DataTypes.XProto)
                    {
                        hexBox1.BackColor = Color.White;
                    }
                    else
                    {
                        hexBox1.BackColor = Color.LightGray;
                    }

                    edCurPage.Text = flash_current_page.ToString();

                    break;
            }

            btSetCurPage_Click(this, new EventArgs());
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppClearLocalFile_Click(object sender, EventArgs e)
        {
            if (GetEditorSource() == EditorTargetTypes.LocalFile)
            {
                file_data.Dispose();
                file_data = null;

                HEXProv_AcceptData(null, 0);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppEraseContArea_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы действительно желаете очистить всю непрерывную область памяти?", this.Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, 0, FlashConst.FLASH_CMD_WIPE_CONTAREA, 0);

                string cmd_str = cmdpack.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    _helper.Send(cmd_str);

                    AddToLog("Началось стирание непрерывной области. Ждите...");
                }
                else
                {
                    AddToLog("Ошибка создания команды...");
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label4.Text = string.Format("Громкость звука: {0}%", trackBar1.Value);
            button2.Enabled = true;
        }
        // ------------------------------------------------------------------------------------------------------------
        private void button2_Click(object sender, EventArgs e)
        {
            ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, 0, FlashConst.FLASH_CMD_PLAY_VOLUME, (uint)trackBar1.Value);

            string cmd_str = cmdpack.Create();

            if (string.IsNullOrEmpty(cmd_str) == false)
            {
                _helper.Send(cmd_str);

                AddToLog(string.Format("Установка громкости ({0}%)...", trackBar1.Value));
            }
            else
            {
                AddToLog("Ошибка создания команды...");
            }

            button2.Enabled = false;
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppFileProperties_Click(object sender, EventArgs e)
        {
            if (lvFiles.SelectedItems[0].Tag == null) { return; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return; }

            AddToLog(string.Format("Запрос свойств файла {0} ({0:X4}). Ждите...", fi.ID));
            Flash_sendCommand(FlashConst.FLASH_CMD_FILE_PROP, fi.ID, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
        private void cbFileTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFileTypes.SelectedIndex < 0 || file_data == null) { return; }

            bool isOK = true;

            if (file_data != null)
            {
                bool isProtoType = IsProtocolSource();

                isOK = (isProtoType ^ (file_data.DataType == ProtoSimpleFileClass.DataTypes.XProto)) == false;
            }

            if (isOK == false)
            {
                MessageBox.Show("Тип данных в локальном хранилище не соотвествует выбранной модели данных!",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);

                cbFileTypes.SelectedIndex = lastModeSelIndex;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void cbFileTypes_DropDown(object sender, EventArgs e)
        {
            lastModeSelIndex = cbFileTypes.SelectedIndex;
        }
        // ------------------------------------------------------------------------------------------------------------
        private void lvFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            label5.Text = "...";

            if (lvFiles.SelectedItems.Count == 0) { return; }
            if (lvFiles.SelectedItems[0].Tag == null) { return; }
            //if (GetEditorSource() != EditorTargetTypes.FlashMemory) { return; }

            ProtoHelper.FileRecordT fi;

            try
            {
                fi = (ProtoHelper.FileRecordT)lvFiles.SelectedItems[0].Tag;
            }
            catch { return; }

            ProtoIDClass.FileTypes f_type = ProtoIDClass.GetFileType(fi.ID);
            string ft_str = Utils.GetDescription(f_type);

            label5.Text = "Тип: \"" + ft_str + "\"";
        }
        // ------------------------------------------------------------------------------------------------------------
        private void ppContStubDecode_Click(object sender, EventArgs e)
        {
            if (hex_provider == null || hex_provider.Length == 0) { return; }
            if (hex_provider.ReadByte(0) != ProtoHelper.SECTOR_STATUS_LAST_USABLE) { return; }

            byte real_target = ProtoTargets.uart_createTarget(0, ProtoTargets.XP_BINDATA_PACKET);

            byte[] real_data = hex_provider.Bytes.ToArray();

            ProtoHelper.SectorPage? header = ProtoHelper.uart_decodePageData(real_data, false);
            if (header == null || Utils.ArrayIsNullOrEmpty(real_data)) { return; }

            ProtoHelper.FileRecordT f_cont_props = XProtoSerializer.BytesToStructure<ProtoHelper.FileRecordT>(header.Value.DATA);

            AddToLog("// -- Файл непрерывной области -----------------");
            AddToLog(string.Format("ID: {0} ({0:X4})", f_cont_props.ID));
            AddToLog(string.Format("Размер (байт): {0}", f_cont_props.Size));
            AddToLog(string.Format("Адрес: {0} (0x{0:X8})", f_cont_props.Address));
            AddToLog(string.Format("Блоков: {0}", f_cont_props.Blocks));
            AddToLog(string.Format("Тип: {0}", f_cont_props.Type));
        }
        // ------------------------------------------------------------------------------------------------------------
        private void mmSysFileDecode_Click(object sender, EventArgs e)
        {
            if (hex_provider == null || hex_provider.Length == 0) { return; }
            if (hex_provider.ReadByte(0) != ProtoHelper.SECTOR_STATUS_LAST_USABLE) { return; }

            byte real_target = ProtoTargets.uart_createTarget(0, ProtoTargets.XP_BINDATA_PACKET);

            byte[] real_data = hex_provider.Bytes.ToArray();

            ProtoHelper.SectorPage? header = ProtoHelper.uart_decodePageData(real_data, false);
            if (header == null || Utils.ArrayIsNullOrEmpty(real_data)) { return; }

            ProtoHelper.SystemRecordT f_cont_props = XProtoSerializer.BytesToStructure<ProtoHelper.SystemRecordT>(header.Value.DATA);
            AddToLog("// -- Системный файл ----------------------");
            AddToLog(string.Format("Flash: 0x{0:X8}", f_cont_props.FlashID));
            AddToLog(string.Format("Начало области: {0}", f_cont_props.ContAreaBegin));
            AddToLog(string.Format("Свободная область: {0}", f_cont_props.ContFreeBegin));
        }
        // ------------------------------------------------------------------------------------------------------------
        private void mmGetBeginFreeContAreaAddress_Click(object sender, EventArgs e)
        {
            Flash_sendCommand(FlashConst.FLASH_CMD_FINDCONTPLACE, 0, 0);
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
