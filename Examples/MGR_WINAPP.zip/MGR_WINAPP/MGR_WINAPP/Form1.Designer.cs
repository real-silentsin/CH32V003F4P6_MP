﻿namespace TEST.COMport_Work1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cbPorts = new System.Windows.Forms.ComboBox();
            this.cbUsePort = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbImage2X = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbFileTypes = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.cbEditorTarget = new System.Windows.Forms.ComboBox();
            this.btReboot = new System.Windows.Forms.Button();
            this.cbSetFileID = new System.Windows.Forms.CheckBox();
            this.btSubPageNum = new System.Windows.Forms.Button();
            this.btAddPageNum = new System.Windows.Forms.Button();
            this.btSetCurPage = new System.Windows.Forms.Button();
            this.edCurPage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btClearText = new System.Windows.Forms.Button();
            this.edUserCMD = new System.Windows.Forms.TextBox();
            this.lbStatus = new System.Windows.Forms.Label();
            this.cbAutoClearCMD = new System.Windows.Forms.CheckBox();
            this.btSendCMD = new System.Windows.Forms.Button();
            this.lbLogs = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btClosePort = new System.Windows.Forms.Button();
            this.cbPortBDR = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ppReadEEPROM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.ppSaveFileToFlash = new System.Windows.Forms.ToolStripMenuItem();
            this.ppSaveFileToCont = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.ppLoadFromFileProto = new System.Windows.Forms.ToolStripMenuItem();
            this.ppLoadFromFileBin = new System.Windows.Forms.ToolStripMenuItem();
            this.ppClearLocalFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.ppMakeFlashPage = new System.Windows.Forms.ToolStripMenuItem();
            this.ppContStubDecode = new System.Windows.Forms.ToolStripMenuItem();
            this.mmSysFileDecode = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ppSavePageToFlash = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ppGetMemInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.ppGoGCC = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.ppEraseContArea = new System.Windows.Forms.ToolStripMenuItem();
            this.ppEraseSect0 = new System.Windows.Forms.ToolStripMenuItem();
            this.ppWipeAllFlash = new System.Windows.Forms.ToolStripMenuItem();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lvFiles = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pp2ReqFileList = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.pp2DownloadFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ppPlaySound = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ppPlaySondContArea = new System.Windows.Forms.ToolStripMenuItem();
            this.ppPlayTestSound = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ppShowAsBMP = new System.Windows.Forms.ToolStripMenuItem();
            this.ppShowPromo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.pp2ViewSelectFileBlock = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.pp2DeleteFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.ppFileProperties = new System.Windows.Forms.ToolStripMenuItem();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.hexBox1 = new Be.Windows.Forms.HexBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbPorts
            // 
            this.cbPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPorts.FormattingEnabled = true;
            this.cbPorts.Location = new System.Drawing.Point(12, 27);
            this.cbPorts.Name = "cbPorts";
            this.cbPorts.Size = new System.Drawing.Size(503, 21);
            this.cbPorts.TabIndex = 0;
            this.cbPorts.SelectedIndexChanged += new System.EventHandler(this.cbPorts_SelectedIndexChanged);
            // 
            // cbUsePort
            // 
            this.cbUsePort.AutoSize = true;
            this.cbUsePort.Enabled = false;
            this.cbUsePort.Location = new System.Drawing.Point(12, 55);
            this.cbUsePort.Name = "cbUsePort";
            this.cbUsePort.Size = new System.Drawing.Size(150, 17);
            this.cbUsePort.TabIndex = 2;
            this.cbUsePort.Text = "Использовать этот порт";
            this.cbUsePort.UseVisualStyleBackColor = true;
            this.cbUsePort.CheckedChanged += new System.EventHandler(this.cbUsePort_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbImage2X);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.cbFileTypes);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.trackBar1);
            this.panel1.Controls.Add(this.cbEditorTarget);
            this.panel1.Controls.Add(this.btReboot);
            this.panel1.Controls.Add(this.cbSetFileID);
            this.panel1.Controls.Add(this.btSubPageNum);
            this.panel1.Controls.Add(this.btAddPageNum);
            this.panel1.Controls.Add(this.btSetCurPage);
            this.panel1.Controls.Add(this.edCurPage);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btClearText);
            this.panel1.Controls.Add(this.edUserCMD);
            this.panel1.Controls.Add(this.lbStatus);
            this.panel1.Controls.Add(this.cbAutoClearCMD);
            this.panel1.Controls.Add(this.btSendCMD);
            this.panel1.Controls.Add(this.lbLogs);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Enabled = false;
            this.panel1.Location = new System.Drawing.Point(0, 423);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(926, 222);
            this.panel1.TabIndex = 3;
            // 
            // cbImage2X
            // 
            this.cbImage2X.AutoSize = true;
            this.cbImage2X.Location = new System.Drawing.Point(659, 147);
            this.cbImage2X.Name = "cbImage2X";
            this.cbImage2X.Size = new System.Drawing.Size(115, 17);
            this.cbImage2X.TabIndex = 33;
            this.cbImage2X.Text = "Удвоение иконок";
            this.cbImage2X.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(656, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 13);
            this.label6.TabIndex = 32;
            this.label6.Text = "Выбор типа содержимого:";
            // 
            // cbFileTypes
            // 
            this.cbFileTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFileTypes.FormattingEnabled = true;
            this.cbFileTypes.Items.AddRange(new object[] {
            "Изображение (протокол)",
            "Изображение (непрерывный)",
            "Звуковой фрагмент (протокол)",
            "Звуковой фрагмент (непрерывный)",
            "Бинарный нейтральный (протокол)",
            "Мелкая иконка (протокол)",
            "OLED бинарная иконка (протокол)"});
            this.cbFileTypes.Location = new System.Drawing.Point(659, 41);
            this.cbFileTypes.Name = "cbFileTypes";
            this.cbFileTypes.Size = new System.Drawing.Size(255, 21);
            this.cbFileTypes.TabIndex = 31;
            this.cbFileTypes.DropDown += new System.EventHandler(this.cbFileTypes_DropDown);
            this.cbFileTypes.SelectedIndexChanged += new System.EventHandler(this.cbFileTypes_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(829, 147);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 25);
            this.button2.TabIndex = 30;
            this.button2.Tag = "10";
            this.button2.Text = "Громкость";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(656, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Громкость звука:";
            // 
            // trackBar1
            // 
            this.trackBar1.LargeChange = 10;
            this.trackBar1.Location = new System.Drawing.Point(659, 96);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(255, 45);
            this.trackBar1.SmallChange = 10;
            this.trackBar1.TabIndex = 28;
            this.trackBar1.TickFrequency = 10;
            this.trackBar1.Value = 100;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // cbEditorTarget
            // 
            this.cbEditorTarget.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEditorTarget.FormattingEnabled = true;
            this.cbEditorTarget.Items.AddRange(new object[] {
            "Массив флеш памяти",
            "Локальное хранилище"});
            this.cbEditorTarget.Location = new System.Drawing.Point(498, 129);
            this.cbEditorTarget.Name = "cbEditorTarget";
            this.cbEditorTarget.Size = new System.Drawing.Size(144, 21);
            this.cbEditorTarget.TabIndex = 26;
            this.cbEditorTarget.SelectedIndexChanged += new System.EventHandler(this.cbEditorTarget_SelectedIndexChanged);
            // 
            // btReboot
            // 
            this.btReboot.BackColor = System.Drawing.Color.MistyRose;
            this.btReboot.Location = new System.Drawing.Point(786, 184);
            this.btReboot.Name = "btReboot";
            this.btReboot.Size = new System.Drawing.Size(128, 23);
            this.btReboot.TabIndex = 25;
            this.btReboot.Text = "Перезагрузка MCU";
            this.btReboot.UseVisualStyleBackColor = false;
            this.btReboot.Click += new System.EventHandler(this.btReboot_Click);
            // 
            // cbSetFileID
            // 
            this.cbSetFileID.AutoSize = true;
            this.cbSetFileID.Enabled = false;
            this.cbSetFileID.Location = new System.Drawing.Point(498, 106);
            this.cbSetFileID.Name = "cbSetFileID";
            this.cbSetFileID.Size = new System.Drawing.Size(116, 17);
            this.cbSetFileID.TabIndex = 24;
            this.cbSetFileID.Text = "Установить FileID";
            this.cbSetFileID.UseVisualStyleBackColor = true;
            // 
            // btSubPageNum
            // 
            this.btSubPageNum.Location = new System.Drawing.Point(527, 182);
            this.btSubPageNum.Name = "btSubPageNum";
            this.btSubPageNum.Size = new System.Drawing.Size(24, 25);
            this.btSubPageNum.TabIndex = 22;
            this.btSubPageNum.Tag = "10";
            this.btSubPageNum.Text = "-";
            this.btSubPageNum.UseVisualStyleBackColor = true;
            this.btSubPageNum.Click += new System.EventHandler(this.btSubPageNum_Click);
            // 
            // btAddPageNum
            // 
            this.btAddPageNum.Location = new System.Drawing.Point(497, 182);
            this.btAddPageNum.Name = "btAddPageNum";
            this.btAddPageNum.Size = new System.Drawing.Size(24, 25);
            this.btAddPageNum.TabIndex = 21;
            this.btAddPageNum.Tag = "10";
            this.btAddPageNum.Text = "+";
            this.btAddPageNum.UseVisualStyleBackColor = true;
            this.btAddPageNum.Click += new System.EventHandler(this.btAddPageNum_Click);
            // 
            // btSetCurPage
            // 
            this.btSetCurPage.Enabled = false;
            this.btSetCurPage.Location = new System.Drawing.Point(557, 183);
            this.btSetCurPage.Name = "btSetCurPage";
            this.btSetCurPage.Size = new System.Drawing.Size(85, 25);
            this.btSetCurPage.TabIndex = 19;
            this.btSetCurPage.Tag = "10";
            this.btSetCurPage.Text = "SET";
            this.btSetCurPage.UseVisualStyleBackColor = true;
            this.btSetCurPage.Click += new System.EventHandler(this.btSetCurPage_Click);
            // 
            // edCurPage
            // 
            this.edCurPage.Location = new System.Drawing.Point(498, 156);
            this.edCurPage.MaxLength = 8;
            this.edCurPage.Name = "edCurPage";
            this.edCurPage.Size = new System.Drawing.Size(144, 20);
            this.edCurPage.TabIndex = 18;
            this.edCurPage.Text = "0";
            this.edCurPage.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(344, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Всего:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(584, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(58, 26);
            this.button1.TabIndex = 15;
            this.button1.Tag = "10";
            this.button1.Text = "CLEAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btClearText
            // 
            this.btClearText.Location = new System.Drawing.Point(620, 41);
            this.btClearText.Name = "btClearText";
            this.btClearText.Size = new System.Drawing.Size(22, 22);
            this.btClearText.TabIndex = 14;
            this.btClearText.Text = "!";
            this.btClearText.UseVisualStyleBackColor = true;
            this.btClearText.Click += new System.EventHandler(this.btClearText_Click);
            // 
            // edUserCMD
            // 
            this.edUserCMD.Location = new System.Drawing.Point(13, 42);
            this.edUserCMD.Name = "edUserCMD";
            this.edUserCMD.Size = new System.Drawing.Size(601, 20);
            this.edUserCMD.TabIndex = 13;
            this.edUserCMD.TextChanged += new System.EventHandler(this.edUserCMD_TextChanged);
            // 
            // lbStatus
            // 
            this.lbStatus.AutoSize = true;
            this.lbStatus.ForeColor = System.Drawing.Color.ForestGreen;
            this.lbStatus.Location = new System.Drawing.Point(201, 11);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(76, 13);
            this.lbStatus.TabIndex = 12;
            this.lbStatus.Text = "<нет данных>";
            // 
            // cbAutoClearCMD
            // 
            this.cbAutoClearCMD.AutoSize = true;
            this.cbAutoClearCMD.Location = new System.Drawing.Point(13, 10);
            this.cbAutoClearCMD.Name = "cbAutoClearCMD";
            this.cbAutoClearCMD.Size = new System.Drawing.Size(154, 17);
            this.cbAutoClearCMD.TabIndex = 11;
            this.cbAutoClearCMD.Text = "Очищать после отправки";
            this.cbAutoClearCMD.UseVisualStyleBackColor = true;
            // 
            // btSendCMD
            // 
            this.btSendCMD.Enabled = false;
            this.btSendCMD.Location = new System.Drawing.Point(498, 73);
            this.btSendCMD.Name = "btSendCMD";
            this.btSendCMD.Size = new System.Drawing.Size(81, 26);
            this.btSendCMD.TabIndex = 9;
            this.btSendCMD.Tag = "10";
            this.btSendCMD.Text = "SEND";
            this.btSendCMD.UseVisualStyleBackColor = true;
            this.btSendCMD.Click += new System.EventHandler(this.btSendCMD_Click);
            // 
            // lbLogs
            // 
            this.lbLogs.FormattingEnabled = true;
            this.lbLogs.Location = new System.Drawing.Point(12, 73);
            this.lbLogs.Name = "lbLogs";
            this.lbLogs.Size = new System.Drawing.Size(472, 134);
            this.lbLogs.TabIndex = 3;
            this.lbLogs.DoubleClick += new System.EventHandler(this.lbLogs_DoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Список доступных виртуальных портов компьютера:";
            // 
            // btClosePort
            // 
            this.btClosePort.Location = new System.Drawing.Point(521, 25);
            this.btClosePort.Name = "btClosePort";
            this.btClosePort.Size = new System.Drawing.Size(121, 23);
            this.btClosePort.TabIndex = 15;
            this.btClosePort.Tag = "10";
            this.btClosePort.Text = "Закрыть";
            this.btClosePort.UseVisualStyleBackColor = true;
            this.btClosePort.Click += new System.EventHandler(this.btClosePort_Click);
            // 
            // cbPortBDR
            // 
            this.cbPortBDR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPortBDR.FormattingEnabled = true;
            this.cbPortBDR.Items.AddRange(new object[] {
            "1200",
            "1800",
            "2400",
            "4800",
            "7200",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800",
            "921600"});
            this.cbPortBDR.Location = new System.Drawing.Point(168, 52);
            this.cbPortBDR.Name = "cbPortBDR";
            this.cbPortBDR.Size = new System.Drawing.Size(347, 21);
            this.cbPortBDR.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 402);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Данные: <НЕТ>";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ppReadEEPROM,
            this.toolStripSeparator9,
            this.ppSaveFileToFlash,
            this.ppSaveFileToCont,
            this.toolStripMenuItem1,
            this.ppLoadFromFileProto,
            this.ppLoadFromFileBin,
            this.ppClearLocalFile,
            this.toolStripMenuItem2,
            this.ppMakeFlashPage,
            this.ppContStubDecode,
            this.mmSysFileDecode,
            this.toolStripSeparator6,
            this.ppSavePageToFlash,
            this.toolStripSeparator3,
            this.ppGetMemInfo,
            this.toolStripMenuItem3,
            this.ppGoGCC,
            this.toolStripSeparator7,
            this.ppEraseContArea,
            this.ppEraseSect0,
            this.ppWipeAllFlash});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(394, 376);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // ppReadEEPROM
            // 
            this.ppReadEEPROM.Name = "ppReadEEPROM";
            this.ppReadEEPROM.Size = new System.Drawing.Size(393, 22);
            this.ppReadEEPROM.Text = "Прочитать текущую страницу";
            this.ppReadEEPROM.Click += new System.EventHandler(this.ppReadEEPROM_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(390, 6);
            // 
            // ppSaveFileToFlash
            // 
            this.ppSaveFileToFlash.Name = "ppSaveFileToFlash";
            this.ppSaveFileToFlash.Size = new System.Drawing.Size(393, 22);
            this.ppSaveFileToFlash.Text = "Записать данные во флеш (протокол)";
            this.ppSaveFileToFlash.Click += new System.EventHandler(this.ppSaveFileToFlash_Click);
            // 
            // ppSaveFileToCont
            // 
            this.ppSaveFileToCont.Name = "ppSaveFileToCont";
            this.ppSaveFileToCont.Size = new System.Drawing.Size(393, 22);
            this.ppSaveFileToCont.Text = "Записать данные во флеш (непрерывный)";
            this.ppSaveFileToCont.Click += new System.EventHandler(this.ppSaveFileToCont_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(390, 6);
            // 
            // ppLoadFromFileProto
            // 
            this.ppLoadFromFileProto.Name = "ppLoadFromFileProto";
            this.ppLoadFromFileProto.Size = new System.Drawing.Size(393, 22);
            this.ppLoadFromFileProto.Text = "Загрузить дамп из файла (протокол)";
            this.ppLoadFromFileProto.Click += new System.EventHandler(this.ppLoadFromFile_Click);
            // 
            // ppLoadFromFileBin
            // 
            this.ppLoadFromFileBin.Name = "ppLoadFromFileBin";
            this.ppLoadFromFileBin.Size = new System.Drawing.Size(393, 22);
            this.ppLoadFromFileBin.Text = "Загрузить дамп из файла (непрерывный)";
            this.ppLoadFromFileBin.Click += new System.EventHandler(this.ppLoadFromFileBin_Click);
            // 
            // ppClearLocalFile
            // 
            this.ppClearLocalFile.Name = "ppClearLocalFile";
            this.ppClearLocalFile.Size = new System.Drawing.Size(393, 22);
            this.ppClearLocalFile.Text = "Очистить локальное хранилище";
            this.ppClearLocalFile.Click += new System.EventHandler(this.ppClearLocalFile_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(390, 6);
            // 
            // ppMakeFlashPage
            // 
            this.ppMakeFlashPage.Name = "ppMakeFlashPage";
            this.ppMakeFlashPage.Size = new System.Drawing.Size(393, 22);
            this.ppMakeFlashPage.Text = "Сформировать флеш-страницу";
            this.ppMakeFlashPage.Click += new System.EventHandler(this.ppMakeFlashPage_Click);
            // 
            // ppContStubDecode
            // 
            this.ppContStubDecode.Name = "ppContStubDecode";
            this.ppContStubDecode.Size = new System.Drawing.Size(393, 22);
            this.ppContStubDecode.Text = "Декодировать заголовочный файл непрерывной области";
            this.ppContStubDecode.Click += new System.EventHandler(this.ppContStubDecode_Click);
            // 
            // mmSysFileDecode
            // 
            this.mmSysFileDecode.Name = "mmSysFileDecode";
            this.mmSysFileDecode.Size = new System.Drawing.Size(393, 22);
            this.mmSysFileDecode.Text = "Декодировать как системный файл";
            this.mmSysFileDecode.Click += new System.EventHandler(this.mmSysFileDecode_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(390, 6);
            // 
            // ppSavePageToFlash
            // 
            this.ppSavePageToFlash.Name = "ppSavePageToFlash";
            this.ppSavePageToFlash.Size = new System.Drawing.Size(393, 22);
            this.ppSavePageToFlash.Text = "Сохранить изменения";
            this.ppSavePageToFlash.Click += new System.EventHandler(this.ppSaveDumpToFile_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(390, 6);
            // 
            // ppGetMemInfo
            // 
            this.ppGetMemInfo.Name = "ppGetMemInfo";
            this.ppGetMemInfo.Size = new System.Drawing.Size(393, 22);
            this.ppGetMemInfo.Text = "Получить информацию о памяти";
            this.ppGetMemInfo.Click += new System.EventHandler(this.ppGetMemInfo_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(390, 6);
            // 
            // ppGoGCC
            // 
            this.ppGoGCC.Name = "ppGoGCC";
            this.ppGoGCC.Size = new System.Drawing.Size(393, 22);
            this.ppGoGCC.Text = "Уборка мусора";
            this.ppGoGCC.Click += new System.EventHandler(this.ppGoGCC_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(390, 6);
            // 
            // ppEraseContArea
            // 
            this.ppEraseContArea.Name = "ppEraseContArea";
            this.ppEraseContArea.Size = new System.Drawing.Size(393, 22);
            this.ppEraseContArea.Text = "Стереть непрерывную область";
            this.ppEraseContArea.Click += new System.EventHandler(this.ppEraseContArea_Click);
            // 
            // ppEraseSect0
            // 
            this.ppEraseSect0.Name = "ppEraseSect0";
            this.ppEraseSect0.Size = new System.Drawing.Size(393, 22);
            this.ppEraseSect0.Text = "Стереть сектор (отладка)";
            this.ppEraseSect0.Click += new System.EventHandler(this.ppEraseSect0_Click);
            // 
            // ppWipeAllFlash
            // 
            this.ppWipeAllFlash.Name = "ppWipeAllFlash";
            this.ppWipeAllFlash.Size = new System.Drawing.Size(393, 22);
            this.ppWipeAllFlash.Text = "Стереть всю флеш";
            this.ppWipeAllFlash.Click += new System.EventHandler(this.ppWipeAllFlash_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(648, 402);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(273, 15);
            this.progressBar1.TabIndex = 19;
            // 
            // lvFiles
            // 
            this.lvFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvFiles.ContextMenuStrip = this.contextMenuStrip2;
            this.lvFiles.FullRowSelect = true;
            this.lvFiles.GridLines = true;
            this.lvFiles.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvFiles.HideSelection = false;
            this.lvFiles.LabelWrap = false;
            this.lvFiles.Location = new System.Drawing.Point(648, 13);
            this.lvFiles.MultiSelect = false;
            this.lvFiles.Name = "lvFiles";
            this.lvFiles.Size = new System.Drawing.Size(273, 358);
            this.lvFiles.SmallImageList = this.imageList1;
            this.lvFiles.TabIndex = 20;
            this.lvFiles.UseCompatibleStateImageBehavior = false;
            this.lvFiles.View = System.Windows.Forms.View.Details;
            this.lvFiles.SelectedIndexChanged += new System.EventHandler(this.lvFiles_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID файла";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Свойства";
            this.columnHeader2.Width = 120;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pp2ReqFileList,
            this.toolStripSeparator1,
            this.pp2DownloadFile,
            this.toolStripSeparator2,
            this.ppPlaySound,
            this.toolStripSeparator8,
            this.ppPlaySondContArea,
            this.ppPlayTestSound,
            this.toolStripSeparator4,
            this.ppShowAsBMP,
            this.ppShowPromo,
            this.toolStripMenuItem6,
            this.pp2ViewSelectFileBlock,
            this.toolStripSeparator5,
            this.pp2DeleteFile,
            this.toolStripMenuItem4,
            this.ppFileProperties});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(302, 266);
            this.contextMenuStrip2.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip2_Opening);
            // 
            // pp2ReqFileList
            // 
            this.pp2ReqFileList.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pp2ReqFileList.Name = "pp2ReqFileList";
            this.pp2ReqFileList.Size = new System.Drawing.Size(301, 22);
            this.pp2ReqFileList.Text = "Запросить список файлов флеш-памяти";
            this.pp2ReqFileList.Click += new System.EventHandler(this.pp2ReqFileList_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(298, 6);
            // 
            // pp2DownloadFile
            // 
            this.pp2DownloadFile.Name = "pp2DownloadFile";
            this.pp2DownloadFile.Size = new System.Drawing.Size(301, 22);
            this.pp2DownloadFile.Text = "Скачать файл на компьютер";
            this.pp2DownloadFile.Click += new System.EventHandler(this.pp2DownloadFile_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(298, 6);
            // 
            // ppPlaySound
            // 
            this.ppPlaySound.Name = "ppPlaySound";
            this.ppPlaySound.Size = new System.Drawing.Size(301, 22);
            this.ppPlaySound.Text = "Проиграть звук";
            this.ppPlaySound.Click += new System.EventHandler(this.ppPlaySound_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(298, 6);
            // 
            // ppPlaySondContArea
            // 
            this.ppPlaySondContArea.Name = "ppPlaySondContArea";
            this.ppPlaySondContArea.Size = new System.Drawing.Size(301, 22);
            this.ppPlaySondContArea.Text = "Проиграть звук из непрерывной области";
            this.ppPlaySondContArea.Click += new System.EventHandler(this.ppPlaySondContArea_Click);
            // 
            // ppPlayTestSound
            // 
            this.ppPlayTestSound.Name = "ppPlayTestSound";
            this.ppPlayTestSound.Size = new System.Drawing.Size(301, 22);
            this.ppPlayTestSound.Text = "Проиграть тестовый звук";
            this.ppPlayTestSound.Click += new System.EventHandler(this.ppPlayTestSound_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(298, 6);
            // 
            // ppShowAsBMP
            // 
            this.ppShowAsBMP.Name = "ppShowAsBMP";
            this.ppShowAsBMP.Size = new System.Drawing.Size(301, 22);
            this.ppShowAsBMP.Text = "Показать как картинку";
            this.ppShowAsBMP.Click += new System.EventHandler(this.ppShowAsBMP_Click);
            // 
            // ppShowPromo
            // 
            this.ppShowPromo.Name = "ppShowPromo";
            this.ppShowPromo.Size = new System.Drawing.Size(301, 22);
            this.ppShowPromo.Text = "Показать экранную заставку";
            this.ppShowPromo.Click += new System.EventHandler(this.ppShowPromo_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(298, 6);
            // 
            // pp2ViewSelectFileBlock
            // 
            this.pp2ViewSelectFileBlock.Name = "pp2ViewSelectFileBlock";
            this.pp2ViewSelectFileBlock.Size = new System.Drawing.Size(301, 22);
            this.pp2ViewSelectFileBlock.Text = "Показать выбранный блок файла";
            this.pp2ViewSelectFileBlock.Click += new System.EventHandler(this.pp2ViewSelectFileBlock_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(298, 6);
            // 
            // pp2DeleteFile
            // 
            this.pp2DeleteFile.Name = "pp2DeleteFile";
            this.pp2DeleteFile.Size = new System.Drawing.Size(301, 22);
            this.pp2DeleteFile.Text = "Удалить файл";
            this.pp2DeleteFile.Click += new System.EventHandler(this.pp2DeleteFile_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(298, 6);
            // 
            // ppFileProperties
            // 
            this.ppFileProperties.Name = "ppFileProperties";
            this.ppFileProperties.Size = new System.Drawing.Size(301, 22);
            this.ppFileProperties.Text = "Свойства файла";
            this.ppFileProperties.Click += new System.EventHandler(this.ppFileProperties_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "image16.png");
            this.imageList1.Images.SetKeyName(1, "image216.png");
            this.imageList1.Images.SetKeyName(2, "sound16.png");
            this.imageList1.Images.SetKeyName(3, "sound216.png");
            this.imageList1.Images.SetKeyName(4, "file");
            this.imageList1.Images.SetKeyName(5, "icon16.png");
            this.imageList1.Images.SetKeyName(6, "icon16.png");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(648, 382);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "...";
            // 
            // hexBox1
            // 
            this.hexBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.hexBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.hexBox1.LineInfoVisible = true;
            this.hexBox1.Location = new System.Drawing.Point(12, 88);
            this.hexBox1.Name = "hexBox1";
            this.hexBox1.ShadowSelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(60)))), ((int)(((byte)(188)))), ((int)(((byte)(255)))));
            this.hexBox1.Size = new System.Drawing.Size(630, 307);
            this.hexBox1.StringViewVisible = true;
            this.hexBox1.TabIndex = 16;
            this.hexBox1.UseFixedBytesPerLine = true;
            this.hexBox1.VScrollBarVisible = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(926, 645);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lvFiles);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.hexBox1);
            this.Controls.Add(this.cbPortBDR);
            this.Controls.Add(this.btClosePort);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbUsePort);
            this.Controls.Add(this.cbPorts);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USB/USART (XProto + Flash) Tests Application [universal]";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbPorts;
        private System.Windows.Forms.CheckBox cbUsePort;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox lbLogs;
        private System.Windows.Forms.Button btSendCMD;
        private System.Windows.Forms.CheckBox cbAutoClearCMD;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox edUserCMD;
        private System.Windows.Forms.Button btClearText;
        private System.Windows.Forms.Button btClosePort;
        private System.Windows.Forms.ComboBox cbPortBDR;
        private System.Windows.Forms.Button button1;
        private Be.Windows.Forms.HexBox hexBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ppReadEEPROM;
        private System.Windows.Forms.ToolStripMenuItem ppSavePageToFlash;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ppLoadFromFileProto;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.Button btSetCurPage;
        private System.Windows.Forms.TextBox edCurPage;
        private System.Windows.Forms.Button btSubPageNum;
        private System.Windows.Forms.Button btAddPageNum;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ppEraseSect0;
        private System.Windows.Forms.ToolStripMenuItem ppSaveFileToFlash;
        private System.Windows.Forms.CheckBox cbSetFileID;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ToolStripMenuItem ppWipeAllFlash;
        private System.Windows.Forms.ToolStripMenuItem ppMakeFlashPage;
        private System.Windows.Forms.ListView lvFiles;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem pp2DownloadFile;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem pp2DeleteFile;
        private System.Windows.Forms.ToolStripMenuItem pp2ReqFileList;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem ppShowAsBMP;
        private System.Windows.Forms.Button btReboot;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem ppGetMemInfo;
        private System.Windows.Forms.ToolStripMenuItem ppGoGCC;
        private System.Windows.Forms.ToolStripMenuItem ppPlaySound;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem ppPlayTestSound;
        private System.Windows.Forms.ToolStripMenuItem pp2ViewSelectFileBlock;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ComboBox cbEditorTarget;
        private System.Windows.Forms.ToolStripMenuItem ppClearLocalFile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem ppLoadFromFileBin;
        private System.Windows.Forms.ToolStripMenuItem ppSaveFileToCont;
        private System.Windows.Forms.ToolStripMenuItem ppEraseContArea;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem ppPlaySondContArea;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cbFileTypes;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem ppFileProperties;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem ppContStubDecode;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.CheckBox cbImage2X;
        private System.Windows.Forms.ToolStripMenuItem ppShowPromo;
        private System.Windows.Forms.ToolStripMenuItem mmSysFileDecode;

    }
}

