﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace TEST.COMport_Work1
{
    // ----------------------------------------------------------------------------
    public static class ProtoHelper
    {
        // ----------------------------------------------------------------------------
        /// <summary>
        /// Идентификатор протокола
        /// </summary>
        public const byte UART_PROTO_MAGICBYTE = 0x58;
        /// <summary>
        /// Общая ошибка протокола
        /// </summary>
        public const byte UART_PROTO_TARGET_ERROR = 0xFF;
        /// <summary>
        /// Завершающий символ передачи пакета
        /// </summary>
        public const byte UART_PROTO_TERMINATOR = 0x00;
        /// <summary>
        /// Максимальное количество байт данных в пакета BIN (кроме заголовка)
        /// </summary>
        public const UInt16 UART_PROTO_MAX_BIN_DATA_SIZE = 256;
        /// <summary>
        /// Максимальное количество байт для пакета протокола XProto
        /// </summary>
        public const UInt16 UART_PROTO_MAX_DATA_SIZE = 260;
        // ----------------------------------------------------------------------------
        /// <summary>
        /// Размер структуры SectorPageT заголовка страницы в 256 байт протокола X 
        /// </summary>
        public const UInt16 XPROTO_PAGE_HEADER_SIZE = 7;
        // ----------------------------------------------------------------------------
        // Флаги статуса сектора
        public const byte SECTOR_STATUS_NEW = 0xFF;         // Сектор не использовался
        public const byte SECTOR_STATUS_USABLE = 0xFE;      // Сектор используется
        public const byte SECTOR_STATUS_LAST_USABLE = 0xFD; // Сектор используется (последний чанк)
        public const byte SECTOR_STATUS_TRASH = 0xFC;       // Сектор брошен (не используется)
        public const byte SECTOR_STATUS_BAD = 0xF0;         // Сектор с BAD блоками

        public const byte PAGE_MAX_DATA_SIZE = 249;         // Доступно для записи по протоколу в странице
        // ----------------------------------------------------------------------------
        // Структура заголовка протокола обмена
        public struct ProtoHeader
        {
            public byte MagicByte; // 0x58
            public byte CRC8;
            public UInt16 Length;
            public byte Target;
        };
        // ----------------------------------------------------------------------------
        [StructLayout(LayoutKind.Explicit, Pack = 1, Size = 5)]
        public struct ProtoHeaderT
        {
            // Отдельные поля (побайтово)
            [FieldOffset(0)]
            public byte MagicByte;  // 0x58
            [FieldOffset(1)]
            public byte CRC8;
            [FieldOffset(2)]
            public UInt16 Length;
            [FieldOffset(4)]
            public byte Target;
        };
        // ----------------------------------------------------------------------------
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct PacketT
        {
            public uint HeaderU32;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public byte[] Data; // 256 байт данных
        };
        // ----------------------------------------------------------------------------
        // Для распаковки данных
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct BINPacket
        {
            public uint HeaderU32;

            public byte[] Data; // 256 байт данных
            public uint Length;
        };
        // ----------------------------------------------------------------------------
        // Pack = 1 убирает лишние отступы между полями (аналог #pragma pack(1))
        // Size увеличен с 10 до 14 байт
        [StructLayout(LayoutKind.Explicit, Pack = 1, Size = 14)]
        public struct CmdPackExT
        {
            // --- Группа 1: Заголовок (ID) ---
            [FieldOffset(0)]
            public uint Id;

            [FieldOffset(0)]
            public byte IdByte0; // Младший байт (Little-endian)
            [FieldOffset(1)]
            public byte IdByte1;
            [FieldOffset(2)]
            public byte IdByte2;
            [FieldOffset(3)]
            public byte IdByte3;

            // --- Группа 2: Команда ---
            [FieldOffset(4)]
            public ushort Cmd;

            // --- Группа 3: Параметр ---
            [FieldOffset(6)]
            public uint Param;

            [FieldOffset(6)]
            public ushort ParamLow;  // Младшие 16 бит
            [FieldOffset(8)]
            public ushort ParamHigh; // Старшие 16 бит

            // --- Группа 4: Расширенный параметр (Новое поле) ---
            [FieldOffset(10)]
            public uint ExtParam;

            [FieldOffset(10)]
            public byte ExtByte0; // Побайтовый доступ (Little-endian)
            [FieldOffset(11)]
            public byte ExtByte1;
            [FieldOffset(12)]
            public byte ExtByte2;
            [FieldOffset(13)]
            public byte ExtByte3;
        };
        // ----------------------------------------------------------------------------
        /* /// <summary>
        /// Структура - fileInfo
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FileInfoT
        {
            public ushort ID;     // 2 байта
            public ushort Blocks; // 2 байта
            public uint Size;     // 4 байта
        }; */
        // ----------------------------------------------------------------------------
        /// <summary>
        /// Структура - fileContRecord_t
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct FileRecordT
        {
            public ushort Type;   // 2 байта
            public ushort ID;     // 2 байта
            public uint Address;  // 4 байта
            public ushort Blocks; // 2 байта
            public uint Size;     // 4 байта
            public byte CRC;      // 1 байт
        };
        // ----------------------------------------------------------------------------
        [StructLayout(LayoutKind.Sequential, Pack = 1, Size = 7)]
        public struct SectorPageT
        {
            public byte STATUS;
            public ushort ID;
            public ushort SEGMENT;
            public byte LENGTH;
            public byte CRC8;
        };
        // ----------------------------------------------------------------------------
        [StructLayout(LayoutKind.Sequential, Pack = 1, Size = 256)]
        public struct SectorPage
        {
            public byte STATUS;
            public ushort ID;
            public ushort SEGMENT;
            public byte LENGTH;
            public byte CRC8;
            public byte[] DATA;
        };
        // ----------------------------------------------------------------------------
        /// <summary>
        /// Структура - SystemRecordT
        /// </summary>
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct SystemRecordT
        {
            public uint FlashID;       // 4 байта 
            public uint ContAreaBegin; // 4 байта
            public uint ContFreeBegin; // 4 байта
        };
        // ----------------------------------------------------------------------------
        [StructLayout(LayoutKind.Sequential, Pack = 1, Size = 32)]
        public struct MemoryInfo
        {
            public uint TotalPages;
            public uint UsedPages;
            public uint TrashPages;
            public uint BadPages;
            public uint FreePages;
            public uint ChipSize;
            public uint ContAreaBegin;
            public uint ContAreaFree;
        };
        // ----------------------------------------------------------------------------
        // var status = MemoryMarshal.Read<PacketT>(IncomingData);
        // ----------------------------------------------------------------------------
        /// <summary>
        /// Проверка, представляет ли указанная строка данные протокола X
        /// </summary>
        /// <param name="Data">Проверяемая строка</param>
        /// <returns>Оценка</returns>
        public static bool uart_isProtoPacket(string Data)
        {
            // Строка приходит с /0 на конце
            if (Utils.ArrayIsNullOrEmpty(Data) || Data.Length < 7) { return false; }

            if (Data[0] != UART_PROTO_MAGICBYTE) { return false; }

            UInt16 length = Utils.HexToUInt16((byte)Data[3], (byte)Data[4], (byte)Data[5], (byte)Data[6]);

            if (Data.Length < (length * 2) + 9) { return false; }

            return true;
        }
        // ----------------------------------------------------------------------------
        /// <summary>
        /// Метод декодирования принятого пакета протокола X
        /// </summary>
        /// <param name="Data">Строка, содержащая данные</param>
        /// <param name="DecodedData">Ссылка на буфер, куда будут переданы принятые данные</param>
        /// <returns>Заголовок протокола или null</returns>
        public static ProtoHeader? uart_decodeProto(string Data, out byte[] DecodedData)
        {
            DecodedData = null;

            if (Utils.ArrayIsNullOrEmpty(Data) || Data.Length < 7) { return null; }

            if (Data[0] != UART_PROTO_MAGICBYTE) { return null; }

            UInt16 length = Utils.HexToUInt16((byte)Data[3], (byte)Data[4], (byte)Data[5], (byte)Data[6]);

            if (Data.Length < (length * 2) + 7) { return null; }

            ProtoHeader newHeader = new ProtoHeader();

            newHeader.Length = length;
            newHeader.MagicByte = UART_PROTO_MAGICBYTE;
            newHeader.CRC8 = Utils.HexToByte((byte)Data[1], (byte)Data[2]);
            newHeader.Target = Utils.HexToByte((byte)Data[7], (byte)Data[8]);

            DecodedData = new byte[length];

            int real_index = 9;

            for (int b_index = 0; b_index < length; b_index++)
            {
                DecodedData[b_index] = Utils.HexToByte((byte)Data[real_index], (byte)Data[real_index + 1]);
                real_index += 2;
            }

            byte crc = CRC8_Class.crc8_calculate(DecodedData, length);
            if (crc != newHeader.CRC8) { return null; }

            return newHeader;
        }
        // ----------------------------------------------------------------------------
        // Формирование "протокольного пакета" и его отправка
        // ВНИМАНИЕ! Метод останавливает прием данных до окончания отправки пакета!
        /// <summary>
        /// Формирование пакета, содержащего данные протокола X
        /// </summary>
        /// <param name="Data">Передаваемые данные, до 128 байт</param>
        /// <param name="Header">Заголовок, c заранее подготовленными полями (кроме CRC)</param>
        /// <returns>Строка протокола X или null</returns>
        public static string uart_createProtoPacket(byte[] Data, ProtoHeader Header)
        {
            if (Header.Length > UART_PROTO_MAX_DATA_SIZE) { return null; }

            string result = string.Empty;

            // 0 - заголовок
            result += (char)Header.MagicByte;

            // 1 - CRC8 контрольная сумма данных
            byte crc8 = CRC8_Class.crc8_calculate(Data, Header.Length);
            result += string.Format("{0:X2}", crc8);

            // 2 - длина данных 4 байта (16бит)
            result += string.Format("{0:X4}", Header.Length);

            // 3 - Цель передачи
            result += string.Format("{0:X2}", Header.Target);

            // 4..Length - данные в HEX виде (каждый байт - 2 цифры) до 128 байт
            for (int rx_index = 0; rx_index < Header.Length; rx_index++)
            {
                result += string.Format("{0:X2}", Data[rx_index]);
            }

            result += UART_PROTO_TERMINATOR;

            return result;
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Создание пакета данных XP_BINDATA_PACKET
        /// </summary>
        /// <param name="BinData">Данные для пакета</param>
        /// <param name="Pack_ident">Идентификатор/адрес</param>
        /// <returns>Бинарный пакет или null</returns>
        public static byte[] uart_createBinDataPacket(byte[] BinData, UInt16 Length, UInt32 Pack_ident)
        {
            // -- Пакет данных внутри пакета X-Proto
            // bytes 0..3 - 32 битный идентификатор пакета (обычно адрес начала данных)
            // bytes [4 - ...] --- данные
            if (BinData == null) { return null; }

            PacketT result = new PacketT();
            result.HeaderU32 = Pack_ident;
            result.Data = BinData;

            return XProtoSerializer.Serialize_PacketT(result, Length);
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Создание финального (текстового) пакета XP_BINDATA_PACKET
        /// </summary>
        /// <param name="BinData">Данные для передачи</param>
        /// <param name="Pack_ident">Идентификатор/адрес</param>
        /// <returns>Строка, представляющая собой пакет или null</returns>
        public static string uart_createBinDataPacketStr(byte[] BinData, UInt16 Pack_ident, ProtoTargets.ProtoTarget Target, out ProtoHeader header)
        {
            header = new ProtoHeader();
            header.MagicByte = UART_PROTO_MAGICBYTE;
            header.Target = ProtoTargets.uart_createTarget2(Target);

            if (Utils.ArrayIsNullOrEmpty(BinData) || BinData.Length > ProtoTargets.XP_MAX_BINARY_SIZE) { return null; }

            byte[] bd_tmp = uart_createBinDataPacket(BinData, (UInt16)BinData.Length, Pack_ident);
            if (Utils.ArrayIsNullOrEmpty(bd_tmp)) { return null; }

            header.Length = (UInt16)(BinData.Length + sizeof(UInt32));

            string result = uart_createProtoPacket(bd_tmp, header);
            if (string.IsNullOrEmpty(result)) { return null; }

            return result;
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Декодирование принятого пакета, содержащего XP_BINDATA_PACKET
        /// </summary>
        /// <param name="data_src">Строка, представляющая полный X-Proto пакет</param>
        /// <param name="Pack_ident">Идентификатор/адрес</param>
        /// <returns>Данные или null</returns>
        public static byte[] uart_decodeBinDataPacketStr(string data_src, out UInt32 Pack_ident)
        {
            Pack_ident = 0;
            if (string.IsNullOrEmpty(data_src)) { return null; }

            byte[] decoded_pack;

            ProtoHeader? header = uart_decodeProto(data_src, out decoded_pack);
            if (header == null || Utils.ArrayIsNullOrEmpty(decoded_pack)) { return null; }
            if (decoded_pack.Length < 5) { return null; }

            ProtoTargets.ProtoTarget target = ProtoTargets.uart_decodeTarget(header.Value.Target);

            switch (target.PackIdent)
            {
                case ProtoTargets.XP_BINDATA_PACKET:
                case ProtoTargets.XP_STATUS_PACKET:

                    break;

                default: return null;
            }

            List<byte> pd_tmp = new List<byte>(decoded_pack);

            Pack_ident = BitConverter.ToUInt32(decoded_pack, 0);

            // Удаление 4 байт - pack_ident;
            pd_tmp.RemoveAt(0);
            pd_tmp.RemoveAt(0);
            pd_tmp.RemoveAt(0);
            pd_tmp.RemoveAt(0);

            return pd_tmp.ToArray();
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Декодирование принятого пакета, содержащего XP_BINDATA
        /// </summary>
        /// <param name="packet_data">Данные BIN без оболочки пакета XProto</param>
        /// <param name="real_target">Цель пакета</param>
        /// <param name="Pack_ident">Идентификатор/адрес</param>
        /// <returns>Данные или null</returns>
        public static BINPacket? uart_decodeBinDataPacket(byte[] packet_data, byte real_target)
        {
            if (Utils.ArrayIsNullOrEmpty(packet_data) || packet_data.Length < 5) { return null; }

            ProtoTargets.ProtoTarget target = ProtoTargets.uart_decodeTarget(real_target);

            switch (target.PackIdent)
            {
                case ProtoTargets.XP_BINDATA_PACKET:
                case ProtoTargets.XP_STATUS_PACKET:
                case ProtoTargets.XP_BINDATA_READ_PACKET:
                case ProtoTargets.XP_FLASHPAGE_READ_PACKET:
                case ProtoTargets.XP_FLASHPAGE_WRITE_PACKET:

                    break;

                default: return null;
            }

            PacketT tmp_bin_data = XProtoSerializer.BytesToStructure<PacketT>(packet_data);

            BINPacket result = new BINPacket();

            List<byte> byte_arr = new List<byte>();

            result.HeaderU32 = tmp_bin_data.HeaderU32;
            //result.Data = tmp_bin_data.Data;
            result.Length = (uint)(packet_data.Length - 4);

            for (int index = 0; index < result.Length; index++)
            {
                byte_arr.Add(tmp_bin_data.Data[index]);
            }

            result.Data = byte_arr.ToArray();

            return result;
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Создание пакета команды
        /// </summary>
        /// <param name="pack_ident">Идентификатор команды</param>
        /// <param name="command">Команда</param>
        /// <param name="param">Параметр</param>
        /// <returns>Пакет или null</returns>
        public static byte[] uart_createCMDPacket(UInt32 pack_ident, UInt16 command, UInt32 param, UInt32 ext_param)
        {
            CmdPackExT newpack = new CmdPackExT();
            newpack.Id = pack_ident;
            newpack.Cmd = command;
            newpack.Param = param;
            newpack.ExtParam = ext_param;

            return XProtoSerializer.StructureToBytes(newpack);
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Создание полного XProto пакета, содержащего пакет команды
        /// </summary>
        /// <param name="pack_ident">Идентификатор команды</param>
        /// <param name="command">Команда</param>
        /// <param name="param">Параметр</param>
        /// <param name="target">Цель, учитывается только Device</param>
        /// <returns>Строка полного пакета для отправки или null</returns>
        public static string uart_createCMDPacketStr(UInt32 pack_ident, UInt16 command, UInt32 param, UInt32 ext_param, ProtoTargets.ProtoTarget target, out ProtoHeader header)
        {
            header = new ProtoHeader();
            header.MagicByte = UART_PROTO_MAGICBYTE;
            header.Target = ProtoTargets.uart_createTarget2(target);
            target.PackIdent = ProtoTargets.XP_CMD_PACKET;

            byte[] cmd_tmp = uart_createCMDPacket(pack_ident, command, param, ext_param);
            if (Utils.ArrayIsNullOrEmpty(cmd_tmp)) { return null; }

            header.Length = (UInt16)cmd_tmp.Length;
            header.CRC8 = (byte)CRC8_Class.crc8_calculate(cmd_tmp, (UInt16)cmd_tmp.Length);

            string result = uart_createProtoPacket(cmd_tmp, header);
            if (string.IsNullOrEmpty(result)) { return null; }

            return result;
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Декодирование пакета команды
        /// </summary>
        /// <param name="data">Только байты пакета команды</param>
        /// <returns>Пакет или null</returns>
        public static CmdPackExT? uart_decodeCMDPacket(byte[] data)
        {
            if (Utils.ArrayIsNullOrEmpty(data) || data.Length < 10) { return null; }

            try
            {
                return XProtoSerializer.BytesToStructure<CmdPackExT>(data);
            }
            catch { }

            return null;
        }
        // ------------------------------------------------------------------------
        /// <summary>
        /// Декодирование данных страницы (256 байт)
        /// </summary>
        /// <param name="page_data">Полный дамп страницы флеш-памяти</param>
        /// <param name="check_crc">Проверка контрольной суммы</param>
        /// <returns>Структура с данными или null</returns>
        public static SectorPage? uart_decodePageData(byte[] page_data, bool check_crc)
        {
            if (Utils.ArrayIsNullOrEmpty(page_data) || page_data.Length < 7) { return null; }

            List<byte> data_t = new List<byte>(page_data);
            SectorPage page = new SectorPage();

            page.STATUS = data_t[0];
            page.ID = Utils.BytesToUint16(data_t[1], data_t[2]);
            page.SEGMENT = Utils.BytesToUint16(data_t[3], data_t[4]);
            page.LENGTH = data_t[5];
            page.CRC8 = data_t[6];

            data_t.RemoveRange(0, 7);

            page.DATA = Utils.TruncateArray(data_t.ToArray(), page.LENGTH);

            byte real_crc = CRC8_Class.crc8_calculate(page.DATA, page.LENGTH);
            if (check_crc)
            {
                if (real_crc != page.CRC8) { return null; }
            }
            else
            {
                page.CRC8 = real_crc;
            }

            return page;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Формирование из данных (до 249) байт пакета протокола Flash/X
        /// </summary>
        /// <param name="page_data">Данные для новой страницы</param>
        /// <param name="file_id">Уникальный идентификатор файла</param>
        /// <param name="file_segment">Номер сегмента</param>
        /// <returns>Страница (до 256 байт) или null</returns>
        public static byte[] CreateFlashPage(byte[] page_data, UInt16 file_id, UInt16 file_segment)
        {
            if (Utils.ArrayIsNullOrEmpty(page_data) || page_data.Length > 249) { return null; }

            ProtoHelper.SectorPageT header = new ProtoHelper.SectorPageT();
            header.STATUS = ProtoHelper.SECTOR_STATUS_USABLE;
            header.ID = file_id;
            header.SEGMENT = file_segment;
            header.LENGTH = (byte)page_data.Length;
            header.CRC8 = CRC8_Class.crc8_calculate(page_data, header.LENGTH);

            byte[] hdr_bin = XProtoSerializer.StructureToBytes(header);
            if (Utils.ArrayIsNullOrEmpty(hdr_bin)) { return null; }

            List<byte> result = new List<byte>(hdr_bin);
            result.AddRange(page_data);

            return result.ToArray();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Формирование из пакета данных байтового массива страницы протокола X
        /// </summary>
        /// <param name="page_data">Данные для новой страницы</param>
        /// <param name="sector_data">Пакет данных</param>
        /// <returns>Страница (до 256 байт) или null</returns>
        public static byte[] CreateFlashPageEx(ProtoHelper.SectorPage sector_data)
        {
            List<byte> result = new List<byte>();

            byte crc = CRC8_Class.crc8_calculate(sector_data.DATA, sector_data.LENGTH);

            // Собираем заголовок строго по именам полей
            result.Add(sector_data.STATUS);
            result.AddRange(BitConverter.GetBytes(sector_data.ID));      // Сами разложатся на 2 байта
            result.AddRange(BitConverter.GetBytes(sector_data.SEGMENT)); // Сами разложатся на 2 байта
            result.Add(sector_data.LENGTH);
            result.Add(crc); // Тут будет лежать уже обновленный CRC8

            // Дописываем сам массив данных
            result.AddRange(sector_data.DATA);

            return result.ToArray();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение заголовка из массива сырых данных, представляющих страницу протокола X
        /// </summary>
        /// <param name="data">Страница протокола X</param>
        /// <returns>Заголовок или null</returns>
        public static ProtoHelper.SectorPageT? GetProtoPageHeader(byte[] data)
        {
            if (Utils.ArrayIsNullOrEmpty(data) || data.Length < 7) { return null; }

            try
            {
                ProtoHelper.SectorPageT page = XProtoSerializer.BytesToStructure<ProtoHelper.SectorPageT>(data);
                return page;
            }
            catch { }

            return null;
        }
        // ------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------
}