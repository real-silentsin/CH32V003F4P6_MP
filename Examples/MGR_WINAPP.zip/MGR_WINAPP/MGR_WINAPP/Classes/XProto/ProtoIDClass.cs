﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TEST.COMport_Work1.Classes
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс для работы с универсальными идентификаторами
    /// </summary>
    public static class ProtoIDClass
    {
        // ------------------------------------------------------------------------------------------------------------
        public enum FileTypes : uint
        {
            [Description("Изображение (протокол)")]
            FILE_TYPE_IMAGEPROTO = 0,
            [Description("Изображение (непрерывный)")]
            FILE_TYPE_IMAGECONT = 1,
            [Description("Звуковой фрагмент (протокол)")]
            FILE_TYPE_SOUNDPROTO = 2,
            [Description("Звуковой фрагмент (непрерывный)")]
            FILE_TYPE_SOUNDCONT = 3,
            [Description("Бинарный набор данных")]
            FILE_TYPE_MISC = 4,
            [Description("Малая иконка")]
            FILE_TYPE_ICON = 5,
            [Description("Бинарное изображение для OLED")]
            FILE_TYPE_OLED_BIN_IMAGE = 6
            // ... можно добавить до 16
        }
        // ------------------------------------------------------------------------------------------------------------
        // Маски для упаковки и распаковки
        private const ushort TypeMask = 0x0F;     // 4 бита (0000 1111)
        private const ushort NumberMask = 0x0FFF; // 12 бит (0000 1111 1111 1111)
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Создает упакованный 16-битный ID из типа и номера.
        /// </summary>
        public static UInt16 MakeId(FileTypes type, ushort number)
        {
            // Ограничиваем номер, чтобы он не залез на биты типа
            ushort cleanNumber = (ushort)(number & NumberMask);
            ushort typeBits = (ushort)(((ushort)type & TypeMask) << 12);

            return (ushort)(typeBits | cleanNumber);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Извлекает тип файла из упакованного ID.
        /// </summary>
        public static FileTypes GetFileType(UInt16 fileId)
        {
            int typeVal = (fileId >> 12) & TypeMask;
            return (FileTypes)typeVal;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Извлекает чистый номер файла из упакованного ID.
        /// </summary>
        public static ushort GetFileNumber(UInt16 fileId)
        {
            return (ushort)(fileId & NumberMask);
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}