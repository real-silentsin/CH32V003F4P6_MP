﻿using System;
using System.IO.Ports;
using System.Threading;

namespace ssCOMPort
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс - помощник для использования последовательного порта
    /// </summary>
    public sealed class ssCOMPortHelper : IDisposable
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        public ssCOMPortHelper() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Поток для чтения сообщений из порта
        /// </summary>
        private Thread _acceptThread;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Буфер приема
        /// </summary>
        private string _rx_buffer;
        // ------------------------------------------------------------------------------------------------------------
        private SerialPort _src_port = null;
        /// <summary>
        /// Ссылка на обслуживаемый последовательный порт
        /// </summary>
        public SerialPort Port
        {
            get { return _src_port; }
        }
        // ------------------------------------------------------------------------------------------------------------
        private int _port_baudrate = 9600;
        /// <summary>
        /// Скорость порта
        /// </summary>
        public int Baudrate 
        {
            get { return _port_baudrate; }
            set { if (!IsOpened) { _port_baudrate = value; } }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Флаг, указывающий на то, открыт ли порт и доступен ли для чтения/записи
        /// </summary>
        public bool IsOpened
        {
            get { return (_src_port != null && _src_port.IsOpen) ? true : false; }
        }
        // ------------------------------------------------------------------------------------------------------------
        private bool isNoAnswered = false;
        /// <summary>
        /// Флаг, означающий, что на предыдущую отправку не было ответа
        /// </summary>
        public bool IsNoAnswered
        {
            get { return isNoAnswered; }
            private set 
            { 
                isNoAnswered = value;
                if (OnNoAnswerFlagChanged != null) { OnNoAnswerFlagChanged(this, new EventArgs()); }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие приема сообщения из порта. Асинхронный метод.
        /// </summary>
        public event ssCOMPortStringEventDelegate OnReceived;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие изменения флага
        /// </summary>
        public event EventHandler OnNoAnswerFlagChanged;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие возникновения исключительной ситуации
        /// </summary>
        public event EventHandler OnPortError;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Создание обслуживаемого порта
        /// </summary>
        /// <param name="PortName">Имя реально существующего порта (типа COM1, COM2 и т.д.)</param>
        /// <returns>Оценка успешности операции</returns>
        public bool CreatePort(string PortName)
        {
            // --------------------------------------------------------------------------------------------------------
            if (string.IsNullOrEmpty(PortName)) { return false; }
            // --------------------------------------------------------------------------------------------------------
            try
            {
                // Создание порта с минимальными параметрами
                _src_port = new SerialPort(PortName, _port_baudrate, Parity.None, 8, StopBits.One);

                //_src_port.ReadBufferSize = (10 * 1024);
                //_src_port.WriteBufferSize = (10 * 1024);

                if (_src_port.IsOpen == false)
                {
                    _src_port.Open();
                }

                _src_port.DiscardInBuffer();
                _src_port.DiscardOutBuffer();

                IsNoAnswered = false;

                _acceptThread = new Thread(ReadPortThread);
                _acceptThread.IsBackground = true;
                _acceptThread.Start();

                return _src_port.IsOpen;
            }
            catch { }
            // --------------------------------------------------------------------------------------------------------
            return false;
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Закрытие порта
        /// </summary>
        /// <returns>Всегда true</returns>
        public bool Close()
        {
            try
            {
                Dispose();
            }
            catch { }

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Отправка сообщения в порт. Если порт не был открыт, он автоматически откроется.
        /// </summary>
        /// <param name="Data">Строка, содержащая отправляемое сообщение</param>
        /// <returns>Оценка успешности операции</returns>
        public bool Send(string Data)
        {
            // --------------------------------------------------------------------------------------------------------
            try
            {
                if (_src_port == null) { return false; }

                if (_src_port.IsOpen == false) { _src_port.Open(); }
                if (_src_port.IsOpen == false) { return false; }

                // Отправка сообшения
                _src_port.Write(string.Format("{0}\0", Data));

                IsNoAnswered = true;

                return true;
            }
            catch { }
            // --------------------------------------------------------------------------------------------------------
            return false;
            // --------------------------------------------------------------------------------------------------------
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Полная очистка принимаемых данных порта
        /// </summary>
        /// <returns>Оценка успешности операции</returns>
        public bool ClearPort()
        {
            try
            {
                if (_src_port == null) { return false; }

                if (_src_port.IsOpen == false) { _src_port.Open(); }
                if (_src_port.IsOpen == false) { return false; }

                 _src_port.DiscardInBuffer();
                 _src_port.DiscardOutBuffer();

                 //_src_port.Close();
                 Thread.Sleep(1000);
                 //_src_port.Open();

                return true;
            }
            catch { }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод потока для асинхронного чтения порта
        /// </summary>
        private void ReadPortThread()
        {
            try
            {
                while (Thread.CurrentThread.IsAlive)
                {
                    while (_src_port.BytesToRead > 0)
                    {
                        //Thread.Sleep(100);
                        _rx_buffer += _src_port.ReadExisting();
                    }

                    if (string.IsNullOrEmpty(_rx_buffer) == false && _rx_buffer.IndexOf('\0') > -1)
                    {
                        IsNoAnswered = false;

                        if (OnReceived != null)
                        {
                            OnReceived(this, new SimpleStringEventArgs(_rx_buffer));
                        }

                        _rx_buffer = string.Empty;
                    }
                }
            }
            catch
            {
                _src_port.Close();
                if (OnPortError != null)
                {
                    OnPortError(this, new EventArgs());
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Сброс флага отсутствия ответа
        /// </summary>
        public void ResetAnswerFlag() { IsNoAnswered = false; }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Сброс буфера приема
        /// </summary>
        public void ResetRxBuffer() { _rx_buffer = string.Empty; }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Очистка ресурсов класса при уничтожении объекта
        /// </summary>
        public void Dispose()
        {
            if (_acceptThread != null)
            {
                try { _acceptThread.Abort(); }
                catch { }

                _acceptThread = null;
            }

            if (_src_port != null)
            {
                if (_src_port.IsOpen) { _src_port.Close(); }
                _src_port.Dispose();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
