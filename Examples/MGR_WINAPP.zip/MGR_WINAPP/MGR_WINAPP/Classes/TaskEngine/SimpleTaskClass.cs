﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// Список доступных статусов задачи
    /// </summary>
    public enum SimpleActionStatusTypes
    {
        Stopped,
        Ready,
        Running,
        DataReady,
        Error,
        Complete,
        Unknown
    }
    // ----------------------------------------------------------------------------------------------------------------

    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Абстрактный класс для асинхронных операций
    /// </summary>
    public abstract class SimpleAction : IDisposable
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Приватный конструктор
        /// </summary>
        protected SimpleAction() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="TaskIdent">Обязательный идентификатор устройства</param>
        public SimpleAction(byte Device) { this.device = Device; }
        // ------------------------------------------------------------------------------------------------------------
        protected byte device = 0;
        /// <summary>
        /// Идентификатор устройства
        /// </summary>
        public byte Device { get { return device; } }
        // ------------------------------------------------------------------------------------------------------------
        private SimpleActionStatusTypes status;
        /// <summary>
        /// Текущий статус задачи
        /// </summary>
        public SimpleActionStatusTypes Status 
        { 
            get { return status; }
            protected set
            {
                status = value;

                switch (status)
                {
                    case SimpleActionStatusTypes.Complete:

                        ThrowCompleteEvent();
                        break;

                    case SimpleActionStatusTypes.Error:

                        ThrowErrorEvent();
                        break;

                    case SimpleActionStatusTypes.Ready:
                    case SimpleActionStatusTypes.Stopped:

                        break;
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Краткое описание модуля задачи
        /// </summary>
        public abstract string Description { get; }
        // ------------------------------------------------------------------------------------------------------------
        protected string message = null;
        /// <summary>
        /// Текст сообщения
        /// </summary>
        public string Message { get { return message; } }
        // ------------------------------------------------------------------------------------------------------------
        private uint errorCode = 0;
        /// <summary>
        /// Код ошибки
        /// </summary>
        public uint ErrorCode { get { return errorCode; } set { errorCode = value; } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод получение задачей внешних данных
        /// </summary>
        /// <param name="IncomingData">Массив данных задачи</param>
        /// <returns>Оценка успешности операции</returns>
        public abstract bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData);
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение задачей отклика из вне
        /// </summary>
        /// <param name="Code"></param>
        public abstract void IncomingResponce(uint Code);
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Запуск задачи
        /// </summary>
        public abstract void Start();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Остановка задачи
        /// </summary>
        public abstract void Stop();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Установка именованного значения для задачи
        /// </summary>
        /// <param name="Name">Имя свойства</param>
        /// <param name="Value">Значение свойства</param>
        /// <returns>Оценка успешности операции</returns>
        public abstract bool SetProp<T>(string Name, T Value);
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка валидности данных
        /// </summary>
        /// <returns>Набор данных полон, можно начинать выполение задачи</returns>
        public abstract bool IsValid();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод вызова события "Ошибка"
        /// </summary>
        protected void ThrowLogEvent(string Message)
        {
            this.message = Message;

            if (OnMessage != null)
            {
                OnMessage(this, new SimpleActionEventArgs(this, SimpleEventType.smeLog));

                this.message = null;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод вызова события "Прогресс"
        /// </summary>
        protected void ThrowProgressEvent(int Progress)
        {
            if (OnMessage != null)
            {
                OnMessage(this, new SimpleActionEventArgs(this, SimpleEventType.smeProgress, Progress));
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод вызова события "Ошибка"
        /// </summary>
        protected void ThrowErrorEvent()
        {
            if (OnMessage != null)
            {
                OnMessage(this, new SimpleActionEventArgs(this, SimpleEventType.smeError));
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод вызова события "Передача данных"
        /// </summary>
        /// <param name="OutgoingData">Отправляемые данные</param>
        protected void ThrowSendDataEvent(string OutgoingData)
        {
            if (OnSendDataEvent != null)
            {
                OnSendDataEvent(this, new SimpleActionDoEventArgs(OutgoingData));
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Метод вызова события "Завершение задачи"
        /// </summary>
        /// <param name="OutgoingData">Отправляемые данные</param>
        protected void ThrowCompleteEvent()
        {
            if (OnMessage != null)
            {
                OnMessage(this, new SimpleActionEventArgs(this, SimpleEventType.smeComplete));
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие необходимости отправки данных из задачи во вне
        /// </summary>
        public event EventHandler<SimpleActionDoEventArgs> OnSendDataEvent;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие отправки сообщения в лог
        /// </summary>
        public event EventHandler<SimpleActionEventArgs> OnMessage;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Очистка
        /// </summary>
        public abstract void Dispose();
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
