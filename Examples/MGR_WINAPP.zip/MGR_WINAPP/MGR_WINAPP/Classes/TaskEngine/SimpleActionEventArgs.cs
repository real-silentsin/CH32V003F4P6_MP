﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Тип возникшего события
    /// </summary>
    public enum SimpleEventType
    {
        smeNone,
        smeLog,
        smeProgress,
        smeError,
        smeComplete
    }
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс - аргумент для обработчиков события с указанием индекса
    /// </summary>
    public sealed class SimpleActionEventArgs : EventArgs
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        /// <param name="Task">Ссылка на задачу</param>
        /// <param name="Event">Тип события</param>
        public SimpleActionEventArgs(SimpleAction Task, SimpleEventType Event) 
        {
            this.argEvent = Event;
            this.task = Task; 
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="Task">Ссылка на задачу</param>
        /// <param name="Event">Тип события</param>
        /// <param name="IntValue">Целое значение</param>
        public SimpleActionEventArgs(SimpleAction Task, SimpleEventType Event, int IntValue)
        {
            this.argEvent = Event;
            this.task = Task;
            this.intvalue = IntValue;
        }
        // ------------------------------------------------------------------------------------------------------------
        private SimpleEventType argEvent = SimpleEventType.smeNone;
        /// <summary>
        /// Тип события
        /// </summary>
        public SimpleEventType EventType { get { return argEvent; } }
        // ------------------------------------------------------------------------------------------------------------
        private SimpleAction task = null;
        /// <summary>
        /// Индекс, сгенерировавший событие
        /// </summary>
        public SimpleAction Task { get { return task; } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Сообщение об ошибке
        /// </summary>
        public string Message { get { return task.Message; } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Код ошибки
        /// </summary>
        public uint ErrorCode { get { return task.ErrorCode; } }
        // ------------------------------------------------------------------------------------------------------------
        public int intvalue = 0;
        /// <summary>
        /// Поле для данных
        /// </summary>
        public int IntValue { get { return intvalue; } }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
