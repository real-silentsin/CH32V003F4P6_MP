﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TEST.COMport_Work1.Classes.TaskEngine;
using System.IO;

namespace TEST.COMport_Work1.Classes
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс загрузок файла из внешней флешки
    /// </summary>
    public class ProtoFileDownloaderClass : SimpleAction
    {
        // ------------------------------------------------------------------------------------------------------------
        public ProtoFileDownloaderClass() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public ProtoFileDownloaderClass(byte Device)
        {
            this.device = Device;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Уникальный идентификатор файла
        /// </summary>
        private UInt16 file_id = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Размер скачиваемого файла (для прогресса)
        /// </summary>
        private UInt32 file_size = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Сколько уже скачали в байтах
        /// </summary>
        private int dwnl_total = 0;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Список всех страниц, содержащих данные файла
        /// </summary>
        private List<UInt16> file_segment_idxs = new List<ushort>();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Имя скачиваемого файла
        /// </summary>
        private string exp_filename = null;
        // ------------------------------------------------------------------------------------------------------------
        public override string Description
        {
            get { return "Скачивание файлов из внешней флеши"; }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            if (Target.Device != this.device) { return false; }
            if (Utils.ArrayIsNullOrEmpty(IncomingData)) { return false; }

            bool isPageData = false;

            switch (Target.PackIdent)
            {
                case ProtoTargets.XP_BINDATA_PACKET:

                    break;

                case ProtoTargets.XP_FLASHPAGE_READ_PACKET:

                    // Здесь пришли запрошенные данные (страница памяти)
                    isPageData = true;

                    break;

                default: return false;
            }

            byte _target = ProtoTargets.uart_createTarget2(Target);
            ProtoHelper.BINPacket? bin_pack = ProtoHelper.uart_decodeBinDataPacket(IncomingData, _target);

            if (bin_pack == null) { return false; }

            // Обработка пришедших данных - страница, 256 байт
            if (isPageData)
            {
                DecodePageDataAndSave(bin_pack.Value.Data);

                if (file_segment_idxs.Count == 0)
                {
                    ThrowProgressEvent(0);
                    ThrowLogEvent(string.Format("Скачивание файла ({0:X4}) завершено!", file_id));
                    Status = SimpleActionStatusTypes.Complete;

                    return true;
                }

                // Запрос очередной порции данных
                SendPageRequest();

                return true;
            }

            switch (bin_pack.Value.HeaderU32)
            {
                case FlashConst.FLASH_PACK_MAPDATA:

                    // Здесь есть частичный список страниц файла
                    UInt16[] page_addresses = Utils.DecodeUINT16List(bin_pack.Value.Data);
                    if (Utils.ArrayIsNullOrEmpty(page_addresses) == false)
                    {
                        file_segment_idxs.AddRange(page_addresses);

                        // Повторяем запросы до ответа - завершено
                        SendPageAdressesRequest();
                    }

                    break;
            }

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void IncomingResponce(uint Code)
        {
            // FLASH_STATE_MAPDATA_DONE = 233
            // FLASH_STATE_MAPDATA_ERR = 133
            if (Status != SimpleActionStatusTypes.Ready) { return; }

            if (Code == FlashConst.FLASH_STATE_MAPDATA_ERR)
            {
                ErrorCode = 100;
                Status = SimpleActionStatusTypes.Error;

                return;
            }

            if (Code != FlashConst.FLASH_STATE_MAPDATA_DONE) { return; }


            // Все данные у нас, можно скачивать файл
            if (file_segment_idxs.Count == 0)
            {
                ErrorCode = 200;
                Status = SimpleActionStatusTypes.Complete;

                return;
            }

            if (file_segment_idxs.Count > 0)
            {
                ThrowLogEvent(string.Format("Началось скачивание файла: {0:X4}", file_id));
            }

            // Если файл существует - удалить его
            try
            {
                if (File.Exists(exp_filename))
                {
                    File.Delete(exp_filename);
                }
            }
            catch { }

            // Запрос первой страницы
            SendPageRequest();
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Start()
        {
            if (Status == SimpleActionStatusTypes.Stopped)
            {
                Status = SimpleActionStatusTypes.Ready;

                dwnl_total = 0;
                ThrowProgressEvent(0);

                SendPageAdressesRequest();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Stop()
        {
            Status = SimpleActionStatusTypes.Stopped;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool SetProp<T>(string Name, T Value)
        {
            dynamic val = Value;
            //string val = (string)(object)Value;

            if (Utils.StringCompare(Name, "fileid", false) == 0)
            {
                if ((Value is UInt16) == false) { return false; }

                file_segment_idxs.Clear();
                file_id = (UInt16)val;

                Status = SimpleActionStatusTypes.Stopped;

                return true;
            }

            if (Utils.StringCompare(Name, "filesize", false) == 0)
            {
                if ((Value is UInt32) == false) { return false; }

                file_size = (UInt32)val;

                Status = SimpleActionStatusTypes.Stopped;

                return true;
            }

            if (Utils.StringCompare(Name, "filename", false) == 0)
            {
                if ((Value is string) == false) { return false; }

                exp_filename = (string)val;

                Status = SimpleActionStatusTypes.Stopped;

                return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Dispose()
        {
            Status = SimpleActionStatusTypes.Unknown;

            file_segment_idxs.Clear();
            file_segment_idxs = null;
        }
        // ------------------------------------------------------------------------------------------------------------
        private void SendPageAdressesRequest()
        {
            if (Status != SimpleActionStatusTypes.Ready) { return; }

            ProtoCMDPacket cmdpack = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_FINDFILEPAGES, file_id);

            string cmd_str = cmdpack.Create();

            // Запрос списка секторов указанного файла
            if (string.IsNullOrEmpty(cmd_str) == false)
            {
                ThrowSendDataEvent(cmd_str);
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void SendPageRequest()
        {
            ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_SET_CURPAGE, file_segment_idxs[0]);
            string cmd_str = pcmd.Create();

            if (string.IsNullOrEmpty(cmd_str) == false)
            {
                file_segment_idxs.RemoveAt(0);

                ThrowSendDataEvent(cmd_str);
            }
            else
            {
                ErrorCode = 300;
                Status = SimpleActionStatusTypes.Error;

                return;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        private void DecodePageDataAndSave(byte[] page_data)
        {
            if (Utils.ArrayIsNullOrEmpty(page_data)) { return; }

            ProtoHelper.SectorPage? page = ProtoHelper.uart_decodePageData(page_data, true);
            if (page != null)
            {
                Utils.FileAppendBytes(exp_filename, page.Value.DATA);

                if (file_size > 0)
                {
                    dwnl_total += page.Value.DATA.Length;
                    int progr = (int)((dwnl_total * 100) / file_size);

                    ThrowProgressEvent(progr);
                }
            }
            else
            {
                ErrorCode = 500;
                Status = SimpleActionStatusTypes.Error;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool IsValid()
        {
            if (string.IsNullOrEmpty(exp_filename)) { return false; }
            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
