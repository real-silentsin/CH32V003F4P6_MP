﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Задача замещения существующего сегмента файла новым
    /// </summary>
    public class ProtoReplaceFileSegmentClass : SimpleAction
    {
        // ------------------------------------------------------------------------------------------------------------
        public ProtoReplaceFileSegmentClass() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public ProtoReplaceFileSegmentClass(byte Device)
        {
            this.device = Device;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override string Description
        {
            get { return "Замещение существующего сегмента файла новым"; }
        }
        // ------------------------------------------------------------------------------------------------------------
        private bool isOK = false;
        // ------------------------------------------------------------------------------------------------------------
        private UInt16 file_idx = 0;
        /// <summary>
        /// ID файла
        /// </summary>
        public UInt16 FileID { get { return file_idx; } }

        private UInt16 seg_idx = 0;
        /// <summary>
        /// Номер сегмента
        /// </summary>
        public UInt16 SegmentNum { get { return seg_idx; } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Отправляемые протокольные данные
        /// </summary>
        private byte[] send_data = null;
        // ------------------------------------------------------------------------------------------------------------
        public override bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        // Отправка данных страницы
        private void SendData()
        {
            ProtoDataBINPacket binpack = new ProtoDataBINPacket(0, device, ProtoTargets.XP_FLASHPAGE_WRITE_PACKET);
            binpack.AddData(send_data);

            string result_proto_str = binpack.Create();

            if (string.IsNullOrEmpty(result_proto_str) == false)
            {
                ThrowSendDataEvent(result_proto_str);
            }
            else
            {
                ErrorCode = 102;
                Status = SimpleActionStatusTypes.Error;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void IncomingResponce(uint Code)
        {
            // Ожидаемые ответы
            // 138, 238 - удаление старого сегмента - этап 1
            // 231, 131 - запись нового сегмента - этап 2

            switch (Code)
            {
                // Старый сегмент успешно удален
                case FlashConst.FLASH_STATE_HFS_OK:

                    SendData();

                    break;

                // Запрос на удаление указанного сегмента указанного файла отклонен
                case FlashConst.FLASH_STATE_HFS_FAILED:

                    ErrorCode = FlashConst.FLASH_STATE_HFS_FAILED;
                    ThrowLogEvent(string.Format("Ошибка удаления сегмента файла: {0}/{1}", file_idx, seg_idx));
                    
                    Status = SimpleActionStatusTypes.Complete;

                    break;

                // Новый сегмент успешно записан
                case FlashConst.FLASH_STATE_WRPAGE_OK:

                    ErrorCode = 200;
                    Status = SimpleActionStatusTypes.Complete;

                    break;

                // Сбой записи нового сегмента
                case FlashConst.FLASH_STATE_WRPAGE_FAILED:

                    ErrorCode = FlashConst.FLASH_STATE_WRPAGE_FAILED;
                    ThrowLogEvent(string.Format("Ошибка сохранения сегмента файла: {0}/{1}", file_idx, seg_idx));
                    
                    Status = SimpleActionStatusTypes.Complete;

                    break;

                default: return;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Start()
        {
            if (Status == SimpleActionStatusTypes.Ready)
            {
                // Запрос на удаление сегмента файла
                ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_HIDE_FILESEGMENT, file_idx, seg_idx);
                string cmd_str = pcmd.Create();

                if (string.IsNullOrEmpty(cmd_str) == false)
                {
                    ThrowSendDataEvent(cmd_str);
                }
                else
                {
                    ErrorCode = 300;
                    Status = SimpleActionStatusTypes.Error;

                    return;
                }
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Stop()
        {
            
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool SetProp<T>(string Name, T Value)
        {
            if (Status != SimpleActionStatusTypes.Stopped) { return false; }

            dynamic val = Value;
            isOK = false;

            if (Utils.StringCompare(Name, "pagedata", false) == 0)
            {
                if ((Value is byte[]) == false) { return false; }

                byte[] send_dataex = (byte[])val;

                if (send_dataex == null || send_dataex.Length != 256)
                {
                    return false;
                }

                ProtoHelper.SectorPage? page = ProtoHelper.uart_decodePageData(send_dataex, false);
                if (page != null)
                {
                    // Вытягиваем структуру в локальную переменную (теперь её можно менять!)
                    file_idx = page.Value.ID;
                    seg_idx = page.Value.SEGMENT;

                    send_data = ProtoHelper.CreateFlashPageEx(page.Value);

                    isOK = true;

                    Status = SimpleActionStatusTypes.Ready;

                    return true;
                }
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool IsValid()
        {
            return isOK;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Dispose()
        {
            send_data = null;
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
