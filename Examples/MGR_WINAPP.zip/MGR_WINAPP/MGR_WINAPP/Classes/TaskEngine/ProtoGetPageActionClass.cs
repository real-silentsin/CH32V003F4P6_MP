﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Класс для асинхронного запроса страницы памяти из флеш
    /// </summary>
    public class ProtoGetPageActionClass : SimpleAction
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса по умолчанию
        /// </summary>
        public ProtoGetPageActionClass() { }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Конструктор класса
        /// </summary>
        public ProtoGetPageActionClass(byte Device)
        {
            this.device = Device;
        }
        // ------------------------------------------------------------------------------------------------------------
        private bool isOk = false;
        private UInt32 page_idx = 0;
        private List<byte> page_data = new List<byte>();
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Доступ к данным принятой страницы
        /// </summary>
        public byte[] PageData { get { return page_data.ToArray(); } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Индекс запрошенной/принятой страницы
        /// </summary>
        public UInt32 PageIndex { get { return page_idx; } }
        // ------------------------------------------------------------------------------------------------------------
        private void SendPageRequest()
        {
            if (Status != SimpleActionStatusTypes.Ready) { return; }

            ProtoCMDPacket pcmd = new ProtoCMDPacket(0, this.device, FlashConst.FLASH_CMD_SET_CURPAGE, page_idx);
            string cmd_str = pcmd.Create();

            if (string.IsNullOrEmpty(cmd_str) == false)
            {
                ThrowSendDataEvent(cmd_str);
            }
            else
            {
                ErrorCode = 300;
                Status = SimpleActionStatusTypes.Error;

                return;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override string Description
        {
            get { return "Загрузка страницы памяти из флеш"; }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool Invoke(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            if (Status != SimpleActionStatusTypes.Ready) { return false; }

            if (Utils.ArrayIsNullOrEmpty(IncomingData)) 
            {
                ErrorCode = 500;
                Status = SimpleActionStatusTypes.Error;

                return false; 
            }

            switch (Target.PackIdent)
            {
                case ProtoTargets.XP_FLASHPAGE_READ_PACKET:

                    // Здесь пришли запрошенные данные (страница памяти)

                    byte _target = ProtoTargets.uart_createTarget2(Target);
                    ProtoHelper.BINPacket? bin_pack = ProtoHelper.uart_decodeBinDataPacket(IncomingData, _target);

                    page_data.Clear();
                    if (bin_pack == null) { return false; }
                    
                    page_data.AddRange(bin_pack.Value.Data);
                    page_idx = (UInt16)bin_pack.Value.HeaderU32;

                    Status = SimpleActionStatusTypes.DataReady;

                    ThrowCompleteEvent();

                    return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void IncomingResponce(uint Code)
        {
            // 120 - Read Failed
            if (Status != SimpleActionStatusTypes.Ready) { return; }

            if (Code == FlashConst.FLASH_STATE_RDPAGE_FAILED)
            {
                ErrorCode = 350;
                Status = SimpleActionStatusTypes.Error;
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Start()
        {
            if (Status == SimpleActionStatusTypes.Ready)
            {
                SendPageRequest();
            }
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Stop()
        {
            Status = SimpleActionStatusTypes.Stopped;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool SetProp<T>(string Name, T Value)
        {
            if (Status != SimpleActionStatusTypes.Stopped) { return false; }

            dynamic val = Value;
            //string val = (string)(object)Value;

            if (Utils.StringCompare(Name, "pageidx", false) == 0)
            {
                if ((Value is UInt32) == false) { return false; }

                page_idx = (UInt32)val;

                isOk = true;

                Status = SimpleActionStatusTypes.Ready;

                return true;
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override bool IsValid()
        {
            return isOk;
        }
        // ------------------------------------------------------------------------------------------------------------
        public override void Dispose()
        {
            page_data.Clear();
            page_data = null;
        }
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
