﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TEST.COMport_Work1.Classes.TaskEngine
{
    // ----------------------------------------------------------------------------------------------------------------
    /// <summary>
    /// Механизм управления присоединенными задачами
    /// </summary>
    public static class TaskEngineClass
    {
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Хранилище задач приложения
        /// </summary>
        private static List<SimpleAction> tasks = new List<SimpleAction>();
        // ------------------------------------------------------------------------------------------------------------
        private static bool deteteTaskOnComplete = true;
        /// <summary>
        /// Удалять присоединенные задачи после их завершения
        /// </summary>
        public static bool DeteteTaskOnComplete { get { return deteteTaskOnComplete; } set { deteteTaskOnComplete = value; } }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получить ссылку на экземпляр задачи
        /// </summary>
        /// <param name="TaskDevice">Идентификатор задачи</param>
        /// <returns>Задача или null</returns>
        public static SimpleAction GetTask(byte TaskDevice)
        {
            foreach (SimpleAction task in tasks)
            {
                if (task.Device == TaskDevice) { return task; }
            }

            return null;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка на существование задачи
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <returns>Оценка существования задачи</returns>
        public static bool TaskExists(byte TaskIdent)
        {
            SimpleAction sa = GetTask(TaskIdent);
            return (sa == null) ? false : true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Добавить задачу в стек задач
        /// </summary>
        /// <param name="NewTask">Новая задача</param>
        /// <param name="StartTaskNow">Запуск задачи немедленно</param>
        /// <returns>DeviceID новой задачи или null</returns>
        public static int AddTask<T>(bool StartTaskNow) where T : SimpleAction
        {
            byte currentDeviceID = 1;

            while (currentDeviceID < 16)
            {
                if (TaskExists(currentDeviceID) == false || currentDeviceID == 16) { break; }
                currentDeviceID += 1;
            }

            if (currentDeviceID > 15)
            {
                return -1;
            }

            // Создаст объект, вызвав конструктор вида: public MyTask(int id)
            T task = (T)Activator.CreateInstance(typeof(T), currentDeviceID);

            if (task == null) { return -1; }

            if (TaskExists(task.Device)) { return -1; }

            task.OnSendDataEvent += new EventHandler<SimpleActionDoEventArgs>(NewTask_OnSendDataEvent);
            task.OnMessage += new EventHandler<SimpleActionEventArgs>(NewTask_OnMessage);

            tasks.Add(task);

            if (StartTaskNow) { task.Start(); }

            return currentDeviceID;
        }               
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Удаление задачи из стека задач
        /// </summary>
        /// <param name="TaskDevice">Идентификатор задачи</param>
        /// <returns>Оценка успешности операции</returns>
        public static bool RemoveTask(byte TaskDevice)
        {
            foreach (SimpleAction task in tasks)
            {
                if (task.Device == TaskDevice) 
                {
                    task.Stop();

                    task.OnMessage -= NewTask_OnMessage;
                    task.OnSendDataEvent -= NewTask_OnSendDataEvent;

                    tasks.Remove(task);
                    return TaskExists(TaskDevice);
                }
            }

            return false;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Передача задаче пришедшего из вне отклика
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <param name="ResponceCode">Код отклика</param>
        /// <returns>Оценка успешности операции</returns>
        public static bool PostResponceCode(byte TaskIdent, uint ResponceCode)
        {
            SimpleAction sa = GetTask(TaskIdent);
            if (sa == null) { return false; }

            sa.IncomingResponce(ResponceCode);

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Получение статуса присоединенной задачи
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <returns>Статус задачи</returns>
        public static SimpleActionStatusTypes GetTaskStatus(byte TaskIdent)
        {
            SimpleAction sa = GetTask(TaskIdent);
            if (sa == null) { return SimpleActionStatusTypes.Unknown; }

            return sa.Status;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Запуск задачи с указанным идентификатором
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <returns>Оценка успешности операции</returns>
        public static bool StartTask(byte TaskIdent)
        {
            SimpleAction sa = GetTask(TaskIdent);
            if (sa == null) { return false; }

            sa.Start();

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Остановка задачи с указанным идентификатором
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <returns>Оценка успешности операции</returns>
        public static bool StopTask(byte TaskIdent)
        {
            SimpleAction sa = GetTask(TaskIdent);
            if (sa == null) { return false; }

            sa.Stop();

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Установка именованно свойства для присоединенной задачи
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <param name="Name">Имя свойства (не может быть null)</param>
        /// <param name="Value">Значение свойства (может быть null)</param>
        /// <returns>Оценка успешности операции</returns>
        public static bool SetTaskProp<T>(byte TaskIdent, string Name, T Value)
        {
            if (string.IsNullOrEmpty(Name)) { return false; }

            SimpleAction sa = GetTask(TaskIdent);
            if (sa == null) { return false; }

            sa.SetProp(Name, Value);

            return true;
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Вызвать задачу для передачи ей данных
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <param name="Target">Цель пакета</param>
        /// <param name="IncomingData">Массив данных</param>
        /// <returns>Оценка успешности операции</returns>
        public static bool InvokeTask(ProtoTargets.ProtoTarget Target, byte[] IncomingData)
        {
            SimpleAction sa = GetTask(Target.Device);
            if (sa == null) { return false; }

            return sa.Invoke(Target, IncomingData);
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Проверка задачи на валидность
        /// </summary>
        /// <param name="TaskIdent">Идентификатор задачи</param>
        /// <returns>Оценка валидности исходных данных задачи</returns>
        public static bool TaskIsValid(byte TaskIdent)
        {
            SimpleAction sa = GetTask(TaskIdent);
            if (sa == null) { return false; }

            return sa.IsValid();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Полная остановка и очистка списка присоединенных задач
        /// </summary>
        public static void ClearAll()
        {
            foreach (SimpleAction task in tasks) 
            { 
                task.Stop();
                task.OnSendDataEvent -= NewTask_OnSendDataEvent;
                task.OnMessage -= NewTask_OnMessage;
            }

            tasks.Clear();
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие возникновения исключительной ситуации в присоединенных задачах
        /// </summary>
        public static event EventHandler<SimpleActionEventArgs> OnMessage;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие необходимости отправки данных из присоединенной задачи
        /// </summary>
        public static event EventHandler<SimpleActionDoEventArgs> OnSend;
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие необходимости отправки данных задачей
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        static void NewTask_OnSendDataEvent(object sender, SimpleActionDoEventArgs e)
        {
            if (OnSend != null) { OnSend(sender, e); }
        }
        // ------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Событие присоединенных задач
        /// </summary>
        /// <param name="sender">Инициатор события</param>
        /// <param name="e">Аргументы события</param>
        static void NewTask_OnMessage(object sender, SimpleActionEventArgs e)
        {
            if (OnMessage != null) { OnMessage(sender, e); }

            // Удаление задачи
            if (deteteTaskOnComplete && e.EventType == SimpleEventType.smeComplete)
            {
                if (e.Task.Status == SimpleActionStatusTypes.Complete)
                {
                    RemoveTask(e.Task.Device);
                }
            }
        } 
        // ------------------------------------------------------------------------------------------------------------
    }
    // ----------------------------------------------------------------------------------------------------------------
}
