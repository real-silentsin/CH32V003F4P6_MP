/********************************** (C) COPYRIGHT ******************************
 * File Name          : uart_lib.c
 * Author             : vantr
 * Description        : Библиотека для работы с UART1 CH32V003 (SOP16)
 *******************************************************************************
 * Copyright (c) 2026 Vantr Universal Co., Ltd.
 *******************************************************************************/
// ----------------------------------------------------------------------------
#include "uart_lib.h"
#include "SSS_Common_Lib_V1/sss_classes.h"
#include "SSS_Common_Lib_V1/sss_math.h"
#include "SSS_CRC8_Lib_V1/crc8_Lib_V1.h"
#include "SSS_XProto_Lib3/sss_xproto_lib1.h"
// ----------------------------------------------------------------------------
//  Последний статус приемника
//  ВНИМАНИЕ! Используются не все доступные состояния, а только те,
//  которые управляют очередью приема символов с шины UART
static volatile uint8_t uart_lastState = UART_COM_READY;
// ----------------------------------------------------------------------------
// Инициализация механизма USART
void UART_UNIT_Init(uint32_t baudrate) {
    // ------------------------------------------------------------------------
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};
    // ------------------------------------------------------------------------
#ifndef UART_USE_REMAP
    // 1. Включаем тактирование (обязательно раздельно или через ИЛИ)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOD | RCC_APB2Periph_USART1, ENABLE);

    // 2. Настройка TX (PD5)
    // ВАЖНО: AF_PP — это то, что оживили ваш вывод
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init (GPIOD, &GPIO_InitStructure);

    // 3. Настройка RX (PD6)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init (GPIOD, &GPIO_InitStructure);
    // ------------------------------------------------------------------------
#else
    // 1. ВКЛЮЧАЕМ ТАКТИРОВАНИЕ (AFIO — ключ к ремапу)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOD | RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO, ENABLE);

    // 2. УСТАНАВЛИВАЕМ РЕМАП (До настройки пинов!)
    // Флаг GPIO_FullRemap_USART1 соответствует значению 10 в RM
    GPIO_PinRemapConfig (GPIO_PartialRemap2_USART1, ENABLE);

    // 3. НАСТРОЙКА ПИНОВ (Учитываем новую распиновку)
    // Теперь TX — это PD6
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init (GPIOD, &GPIO_InitStructure);

    // Теперь RX — это PD5
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init (GPIOD, &GPIO_InitStructure);
#endif
    // ------------------------------------------------------------------------
    // 4. Параметры UART
    USART_InitStructure.USART_BaudRate = baudrate;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    // ------------------------------------------------------------------------
    USART_Init (USART1, &USART_InitStructure);
    // ------------------------------------------------------------------------
    // 5. Включаем модуль
    USART_Cmd (USART1, ENABLE);
    // ------------------------------------------------------------------------
    // 5. Настройка NVIC
    // Для CH32V003 лучше использовать простую схему приоритетов
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  // Средний приоритет
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;         // В V003 почти не влияет
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init (&NVIC_InitStructure);
    // ------------------------------------------------------------------------
    // Включаем прерывание именно по приему байта (RX Not Empty)
    USART_ITConfig (USART1, USART_IT_RXNE, ENABLE);
    // ------------------------------------------------------------------------
    // Разрешаем прерывания на уровне ядра RISC-V
    NVIC_EnableIRQ (USART1_IRQn);
    // ------------------------------------------------------------------------
    UART_Reset();
    // ------------------------------------------------------------------------
}
// -----------------------------------------------------------------------------
// Получение последнего состояния приемника команд
uint8_t UART_getLastState() {

    return uart_lastState;
}

// -----------------------------------------------------------------------------
#ifdef UART_USE_XPROTO
// Получение последнего состояния декодера протокола
uint8_t UART_getProtoLastState() {

    return proto_last_err;
}
#endif
// -----------------------------------------------------------------------------
/* void uint16_to_hex (uint16_t value) {
    const char hex_chars[] = "0123456789ABCDEF";
    buffer16[0] = hex_chars[(value >> 12) & 0x0F];  // Старший полубайт первого байта
    buffer16[1] = hex_chars[(value >> 8) & 0x0F];   // Младший полубайт первого байта
    buffer16[2] = hex_chars[(value >> 4) & 0x0F];   // Старший полубайт второго байта
    buffer16[3] = hex_chars[value & 0x0F];          // Младший полубайт второго байта
    buffer16[4] = '\0';                             // Завершаем строку
} */
// -----------------------------------------------------------------------------
// Сброс и подготовка к новому приему
void UART_Reset() {

    uart_lastState = UART_COM_READY;
}
// -----------------------------------------------------------------------------
// Остановка приема
void UART_Stop() {

    uart_lastState = UART_COM_STOPPED;
}
// -----------------------------------------------------------------------------
// Начало нового приема (после остановки "UART_Stop")
void UART_Start() {

    UART_Reset(); //?
    uart_lastState = UART_COM_READY;
}
// -----------------------------------------------------------------------------
// Отправка байта
void UART_SendChar(const uint8_t data) {

    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) { }
    USART_SendData(USART1, data);
}
// ----------------------------------------------------------------------------
// Отправка строки
void UART_SendString(const uint8_t *str) {

    while(*str) { UART_SendChar(*str++); }
    UART_SendChar (UART_ENDOFLINE);
}
// -----------------------------------------------------------------------------
// Безопасная передача строки символов (\0 игнорируется)
uint16_t UART_TxString2(const uint8_t *ptr_string, uint8_t length) {
    // -------------------------------------------------------------------------
    uint16_t result = 0;

    for (int index = 0; index < length; index++) {

        if (ptr_string[index] != 0) {

            UART_SendChar (ptr_string[index]);
            result += 1;
        } else {

            UART_SendChar ('0');
        }
    }
    // -------------------------------------------------------------------------
    return result;
}

// -----------------------------------------------------------------------------
// Печать в канал UART "OK"
void UART_print_ok() {

    UART_SendString((uint8_t *)"OK");
}
// -----------------------------------------------------------------------------
// Печать в канал UART "<CR>"
void UART_print_crlf() { 

    UART_SendChar(UART_ENDOFLINE);
}
// -----------------------------------------------------------------------------
// Объявляем "слабую" функцию-обработчик на один символ
__attribute__ ((weak)) uint8_t UART_OnReceive (uint8_t pData) {
    // По умолчанию ничего не делаем
    (void)pData;

    return UART_COM_READY;
}

// ----------------------------------------------------------------------------
// Обработчик прерывания
void USART1_IRQHandler (void) __attribute__ ((interrupt ("WCH-Interrupt-fast")));

void USART1_IRQHandler (void) {

    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {

        if (uart_lastState == UART_COM_READY) {

            uint8_t data = USART_ReceiveData (USART1);
            uart_lastState = UART_OnReceive(data);
        }

        USART_ClearITPendingBit (USART1, USART_IT_RXNE);
    }
}
// ----------------------------------------------------------------------------
