/********************************** (C) COPYRIGHT *******************************
 * File Name          : sss_spisw_lib1.h
 * Author             : vantr
 * Version            : V1.1.0
 * Date               : 2026/06/08
 * Description        : Драйвер софтверного SPI (CH32V003)
 *********************************************************************************
 * Copyright (c) 2026 Vantr Universal Co., Ltd.
 *******************************************************************************/
// ----------------------------------------------------------------------------
#ifndef __SSSPISW_H__
#define __SSSPISW_H__
// ----------------------------------------------------------------------------
#include "ch32v00x.h"
#include "app_config.h"
// ----------------------------------------------------------------------------
// Все настройки модуля в <app.config>
// ----------------------------------------------------------------------------
// МАКРОСЫ УПРАВЛЕНИЯ (НЕ ТРОГАТЬ!)
// ----------------------------------------------------------------------------
#define SPISW_SCK_LOW() (SPISW_GPIO_PORT_SCK->BCR = SPISW_GPIO_PIN_SCK)
#define SPISW_SCK_HIGH() (SPISW_GPIO_PORT_SCK->BSHR = SPISW_GPIO_PIN_SCK)

#define SPISW_MOSI_LOW() (SPISW_GPIO_PORT_MOSI->BCR = SPISW_GPIO_PIN_MOSI)
#define SPISW_MOSI_HIGH() (SPISW_GPIO_PORT_MOSI->BSHR = SPISW_GPIO_PIN_MOSI)

#define SPISW_MISO_READ() ((SPISW_GPIO_PORT_MISO->INDR & SPISW_GPIO_PIN_MISO) ? 1 : 0)
// ----------------------------------------------------------------------------
void SPISW_Init (void);
#ifdef SPISW_USE_DELAY
void SPISW_SetSpeed (uint32_t target_hz);
#endif

uint8_t SPISW_Transfer (uint8_t data);
// ----------------------------------------------------------------------------
#endif
