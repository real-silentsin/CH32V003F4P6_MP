/********************************** (C) COPYRIGHT ******************************
 * File Name          : matrix_menu.c
 * Author             : vantr
 * Description        : Библиотека графики для OLED дисплея на SSD1306
 * Module             : Графическая библиотека MATRIX™
 *******************************************************************************
 * Copyright (c) 2025 Vantr Universal Co., Ltd.
 *******************************************************************************/
#include "matrix_menu.h"
#include "string.h"
#include "debug.h"
// -----------------------------------------------------------------------------
// Ссылка на главное меню
Menu _mainMenu;
MenuItem _items[MENU_MAX_ITEMS];
// -----------------------------------------------------------------------------
// Отступ снизу при отрисовке имени меню
uint8_t _mm_header_margin = 10;

// -----------------------------------------------------------------------------
// Получение количества элементов в меню
uint8_t matrix_menu_get_count() {

    return _mainMenu.Count;
}
// -----------------------------------------------------------------------------
// Ссылка на главное меню
Menu* matrix_menu_mainmenu() {

    return &_mainMenu;
}
// -----------------------------------------------------------------------------
// Быстрое создание элемента меню из параметров
uint8_t matrix_menu_create_menuitem (uint8_t *caption, uint16_t ActionID) {

    if (_mainMenu.Count < MENU_MAX_ITEMS) {

        MenuItem result;

        result.ActionID = ActionID;
        result.Caption = caption;
        result.Selected = 0;
        result.ColorText = _mainMenu.ColorText;

        _items[_mainMenu.Count] = result;
        _mainMenu.Count += 1;

        return _mainMenu.Count - 1;
    }

    return 0xFF;
}
// -----------------------------------------------------------------------------
// Установка значений по умолчанию
void matrix_menu_default_config(Rect client_rect, uint8_t item_height) {

    _mainMenu.MenuName = (uint8_t *)".";
    _mainMenu.State = Newed; // Только что созданное меню!

    _mainMenu.ColorBackground = CL_BLACK;
    _mainMenu.ColorSelectedBackground = CL_WHITE;
    _mainMenu.ColorText = CL_WHITE;
    _mainMenu.ColorBorder = CL_WHITE;
    _mainMenu.ColorSelectedText = CL_BLACK;
    _mainMenu.ColorMenuHeap = CL_BLUE;
    _mainMenu.ColorMenuHeapText = CL_YELLOW;

    _mainMenu.MenuItemHeight = (item_height < 25) ? 25 : item_height;
    _mainMenu.MenuRect = client_rect;
    _mainMenu.TopItemIndex = 0;
    _mainMenu.TextScale = 1;
    _mainMenu.TextMenuNameScale = 2;
}
// -----------------------------------------------------------------------------
// Установка области отрисовки меню
void matrix_menu_set_rect (Rect client_rect) {

    _mainMenu.MenuRect = client_rect;
}

// -----------------------------------------------------------------------------
// Установка высоты единичного элемента меню
void matrix_menu_set_menuitem_height (uint8_t item_height) {

    _mainMenu.MenuItemHeight = (item_height < 25) ? 25 : item_height;
}

// -----------------------------------------------------------------------------
// Установка первого отображаемого элемента меню
void matrix_menu_set_top_itemindex (uint8_t item_index) {

    _mainMenu.TopItemIndex = item_index;
}
// -----------------------------------------------------------------------------
// Установка цвета текста/выделенного текста
void matrix_menu_set_text_color(uint16_t color, uint8_t selected) {

    switch (selected) {
        
        case 0:

            _mainMenu.ColorText = color;
            break;

        default:

            _mainMenu.ColorSelectedText = color;
            break;
    }
}
// -----------------------------------------------------------------------------
// Установка цвета неактивного/выделенного заднего плана
void matrix_menu_set_back_color(uint16_t color, uint8_t selected) {

    switch (selected) {
        
        case 0:

            _mainMenu.ColorBackground = color;
            break;

        default:

            _mainMenu.ColorSelectedBackground = color;
            break;
    }
}
// -----------------------------------------------------------------------------
// Очистка меню
void matrix_menu_clear() {

    _mainMenu.Count = 0;
    memset(_items, 0, sizeof(_items));
}
// -----------------------------------------------------------------------------
// Получение ссылки на элемент меню
MenuItem* matrix_menu_get (uint8_t index) {

    if (index < _mainMenu.Count) {

        return &_items[index];
    }

    return NULL;
}
// -----------------------------------------------------------------------------
// Сделать видимым указанный элемент меню
void matrix_menu_set_visible (uint8_t item_index) {
    // -------------------------------------------------------------------------
    if (item_index >= _mainMenu.Count) return;

    // 1. Если элемент выше текущего окна просмотра — скроллим вверх до него
    if (item_index < _mainMenu.TopItemIndex) {
        _mainMenu.TopItemIndex = item_index;
        return;
    }

    // 2. Рассчитываем, сколько ПОЛНЫХ пунктов влезает в высоту окна
    uint8_t visible_count = _mainMenu.MenuRect.ClientSize.Height / _mainMenu.MenuItemHeight;

    // 3. Если элемент ниже текущего окна просмотра
    // (item_index - TopItemIndex + 1) — это порядковый номер элемента на экране
    if (item_index - _mainMenu.TopItemIndex + 1 > visible_count) {
        // Устанавливаем TopItemIndex так, чтобы item_index был САМЫМ НИЖНИМ в окне
        _mainMenu.TopItemIndex = item_index - visible_count + 1;
    }
}
// -----------------------------------------------------------------------------
// Установка выделенного элемента меню
void matrix_menu_set_selected (uint8_t item_index) {
    // -------------------------------------------------------------------------
    if (item_index + 1 > _mainMenu.Count) {
        return;
    }
    // -------------------------------------------------------------------------
    for (int index = 0; index < _mainMenu.Count; index++) {

        //_mainMenu.Items[index].Selected = (item_index == index) ? 1 : 0;
        _items[index].Selected = (item_index == index) ? 1 : 0;
    }
    // -------------------------------------------------------------------------
    matrix_menu_set_visible (item_index);
    // -------------------------------------------------------------------------
}
// -----------------------------------------------------------------------------
// Получение индекса выделенного элемента меню
MenuItem* matrix_menu_get_selected() {
    // -------------------------------------------------------------------------
    for (int index = 0; index < _mainMenu.Count; index++) {

        // Если выделенный существует
        if (_items[index].Selected == 1) {

            return &_items[index];
        }
    }

    // Если не существует, возвращаем элемент по умолчанию
    if (_mainMenu.DefaultActionIndex < _mainMenu.Count)
    {

        return &_items[_mainMenu.DefaultActionIndex];
    }
    // -------------------------------------------------------------------------
    // Увы, ничего не нашли
    return NULL;
    // -------------------------------------------------------------------------
}
// -----------------------------------------------------------------------------
// Установка имени меню
void matrix_menu_set_name (uint8_t *caption) {

    _mainMenu.MenuName = caption;
}
// -----------------------------------------------------------------------------
// Установка отступа снизу для имени меню
void matrix_menuname_set_margin (uint8_t value) {

    _mm_header_margin = value;
}
// -----------------------------------------------------------------------------
// Установка курсора на текст
void matrix_menu_itemtext_coord (MenuItem item, uint8_t scale) {

    Point textc = matrix_shift_coords (item.Location, 5, ((_mainMenu.MenuItemHeight - 8 * scale) / 2));
    matrix_setCoord2 (textc);
}
// -----------------------------------------------------------------------------
/* // Рисование главного меню
void matrix_menu_draw() {
    // -------------------------------------------------------------------------
    //matrix_frame_init();

    Rect current_rect = _mainMenu.MenuRect;

    ST7789_setForeColor(_mainMenu.ColorBackground);
    //matrix_fillClipRect(current_rect);
    matrix_client_rect();

    ST7789_setForeColor(_mainMenu.ColorText);
    // -------------------------------------------------------------------------
    if (_mainMenu.Count == 0) { 
    
        ST7789_setForeColor(_mainMenu.ColorBackground);
        matrix_fillRect(current_rect, ForeGround);
        matrix_client_rect();
        
        return; 
    }
    // -------------------------------------------------------------------------
    uint8_t y_current = current_rect.Location.Y;
    uint8_t item_index = _mainMenu.TopItemIndex;

    Size item_size;
    item_size.Width = current_rect.ClientSize.Width;
    item_size.Height = _mainMenu.MenuItemHeight;

    if (_mainMenu.MenuName != (uint8_t *)'.') {

        item_size.Width -= MENU_NAME_WIDTH;
    }
    // -------------------------------------------------------------------------
    // 1. Отрисовка пунктов меню
    // -------------------------------------------------------------------------
    while (y_current < current_rect.Location.Y + current_rect.ClientSize.Height) {

        if (item_index > _mainMenu.Count - 1) {

            break;            
        }
        // ---------------------------------------------------------------------
        // Не помещающийся в область меню последний пункт не рисуем вовсе
        if (y_current + _mainMenu.MenuItemHeight > current_rect.Location.Y + current_rect.ClientSize.Height) {

            break;
        }
        // ---------------------------------------------------------------------
        _items[item_index].Location = matrix_create_point(current_rect.Location.X + 1, y_current + 1);
        // ---------------------------------------------------------------------
        if (_items[item_index].Selected) {
            
            // Выделенный пункт меню
            ST7789_setForeColor(_mainMenu.ColorSelectedBackground);
            ST7789_setBackColor(_mainMenu.ColorSelectedText);
            //matrix_fillRect3(_items[item_index].Location, item_size, ForeGround);

            _items[item_index].Location.extend = 2;
            matrix_filled_rect(_items[item_index].Location, item_size);

            uint16_t delta_h = (item_size.Height - (_mainMenu.TextScale * 8)) + 2;
            Rect item_rect = matrix_create_rect(_items[item_index].Location, item_size);
            //Rect item_rect = matrix_reduce_rect(matrix_create_rect(_items[item_index].Location, item_size), 1);
            Rect f_rect = matrix_reduce_rect_height(item_rect, delta_h);
            matrix_fillRect3(f_rect.Location, f_rect.ClientSize, ForeGround);

            ST7789_setForeColor(_mainMenu.ColorSelectedText);
            ST7789_setBackColor(_mainMenu.ColorSelectedBackground);
           
        } else {
            
            // Не выделенный пункт меню
            ST7789_setForeColor(_mainMenu.ColorBackground);
            ST7789_setBackColor(_mainMenu.ColorText);
            matrix_fillRect3(_items[item_index].Location, item_size, ForeGround);

            ST7789_setForeColor(_items[item_index].ColorText);
            //ST7789_setBackColor(_mainMenu.ColorBackground);
            ST7789_setBackColor(_items[item_index].ColorText);
        }

        // Надпись на текущем пункте меню
        matrix_menu_itemtext_coord(_items[item_index], _mainMenu.TextScale);        
        matrix_writeString((uint8_t *) _items[item_index].Caption, 0, _mainMenu.TextScale);
        // ---------------------------------------------------------------------
        // Переходим к следующему пункту
        item_index++;
        y_current += _mainMenu.MenuItemHeight;
        // ---------------------------------------------------------------------
    }
    // -------------------------------------------------------------------------
    // 2. ЗАЛИВКА ОСТАТКА (Пустое место под последним отрисованным пунктом)
    // -------------------------------------------------------------------------
    // Вычисляем, сколько пикселей осталось до нижнего края client_rect
    int16_t bottom_edge = current_rect.Location.Y + current_rect.ClientSize.Height;
    int16_t diff_y = bottom_edge - y_current;

    if (diff_y > 0) {
        // Формируем Rect для "подвала" меню
        Rect tail_rect;
        tail_rect.Location.X = current_rect.Location.X;
        tail_rect.Location.Y = y_current;
        tail_rect.ClientSize.Width = item_size.Width; //current_rect.ClientSize.Width;
        tail_rect.ClientSize.Height = (uint16_t)diff_y;

        ST7789_setForeColor (_mainMenu.ColorBackground);
        matrix_fillRect (tail_rect, ForeGround);
    }
    // -------------------------------------------------------------------------
    // 3. Отрисовка боковой панели (имени) меню
    if (_mainMenu.MenuName != (uint8_t *)'.') {
    
        Point m_cpt_loc = matrix_get_rect_topright(current_rect);
        m_cpt_loc.X -= MENU_NAME_WIDTH;
        
        // Если рисуем просто с отступом от верха
        //m_cpt_loc.Y += _mm_header_margin;
        
        Size m_cpt_sz = { MENU_NAME_WIDTH, current_rect.ClientSize.Height };

        Rect mm_area = matrix_create_rect(m_cpt_loc, m_cpt_sz);
        ST7789_setForeColor(_mainMenu.ColorMenuHeap);
        matrix_fillRect(mm_area, ForeGround);

        // ---------------------------------------------------------------------
        ST7789_setForeColor(_mainMenu.ColorMenuHeapText);
        ST7789_setBackColor(_mainMenu.ColorMenuHeapText);
        // ---------------------------------------------------------------------
        // Центрование имени меню
        // ---------------------------------------------------------------------
        // Вычисление длины имени меню в пикселях
        uint16_t mh_width = matrix_measureString(_mainMenu.MenuName, _mainMenu.TextMenuNameScale);

        m_cpt_loc = matrix_get_rect_topright(current_rect);
        m_cpt_loc.X -= MENU_NAME_WIDTH;
        m_cpt_loc.X += ((8 * _mainMenu.TextMenuNameScale) / 2) - 3;

        m_cpt_loc.Y += ((m_cpt_sz.Height - mh_width) / 2);

        matrix_setCoord2(m_cpt_loc);
        matrix_writeString((uint8_t *)_mainMenu.MenuName, 1, _mainMenu.TextMenuNameScale);
    }
    // -------------------------------------------------------------------------
    // 4. Рисуем общую рамку области отрисовки
    ST7789_setForeColor(_mainMenu.ColorBorder);
    matrix_draw_rect(current_rect.Location, current_rect.ClientSize);
    // -------------------------------------------------------------------------    
} */
// -----------------------------------------------------------------------------
// Альтернативный метод рисования главного меню
void matrix_menu_draw_alt() {
    // -------------------------------------------------------------------------
    matrix_restoreClientRect();
    Rect current_rect = _mainMenu.MenuRect;

    //ST7789_setBackColor(_mainMenu.ColorText);
    //ST7789_setForeColor(CL_RED);

    //matrix_client_rect();
    // -------------------------------------------------------------------------
    if (_mainMenu.Count == 0) { 
    
        ST7789_setForeColor(_mainMenu.ColorBackground);
        matrix_fillRect(current_rect, ForeGround);
        matrix_client_rect();
        
        return; 
    }
    // -------------------------------------------------------------------------
    Rect menuitems_area;

    menuitems_area.Location = current_rect.Location;
    menuitems_area.ClientSize = current_rect.ClientSize;

    if (_mainMenu.MenuName != (uint8_t *)'.') {

        menuitems_area.ClientSize.Width -= MENU_NAME_WIDTH;
    }

    matrix_set_clientrect(matrix_reduce_rect(menuitems_area, 1));
    current_rect = matrix_get_clientrect();

    /* menuitems_area.Location = current_rect.Location;
    menuitems_area.ClientSize = current_rect.ClientSize;

    menuitems_area.Location.X = current_rect.Location.X; 
    menuitems_area.Location.Y = current_rect.Location.Y; */

    //ST7789_setForeColor(CL_GREEN);

    //matrix_client_rect();
    // -------------------------------------------------------------------------
    Rect heap_area;

    matrix_set_clientrect(_mainMenu.MenuRect);

    heap_area.Location = matrix_get_rect_topright(menuitems_area);
    heap_area.ClientSize = (Size){ MENU_NAME_WIDTH, menuitems_area.ClientSize.Height };

    //heap_area = matrix_reduce_rect(heap_area, 1);

    //ST7789_setForeColor(CL_BLUE);
    //matrix_draw_rect(heap_area.Location, heap_area.ClientSize);
    // -------------------------------------------------------------------------
    uint8_t y_current = current_rect.Location.Y;
    uint8_t item_index = _mainMenu.TopItemIndex;

    Size item_size;
    item_size.Width = menuitems_area.ClientSize.Width;
    item_size.Height = _mainMenu.MenuItemHeight;
    // -------------------------------------------------------------------------
    // 1. Отрисовка пунктов меню
    // -------------------------------------------------------------------------
    //matrix_set_clientrect(menuitems_area);

    while (y_current < current_rect.Location.Y + current_rect.ClientSize.Height) {

        if (item_index > _mainMenu.Count - 1) {

            break;            
        }
        // ---------------------------------------------------------------------
        // Не помещающийся в область меню последний пункт не рисуем вовсе
        //if (y_current + _mainMenu.MenuItemHeight > current_rect.Location.Y + current_rect.ClientSize.Height) {
        if (y_current >= current_rect.Location.Y + current_rect.ClientSize.Height) {

            break;
        }
        // ---------------------------------------------------------------------
        _items[item_index].Location = matrix_create_point(menuitems_area.Location.X + 1, y_current);
        // ---------------------------------------------------------------------
        if (_items[item_index].Selected) {
            
            // Выделенный пункт меню
            ST7789_setForeColor(_mainMenu.ColorSelectedBackground);
            ST7789_setBackColor(_mainMenu.ColorSelectedText);
            //matrix_fillRect3(_items[item_index].Location, item_size, ForeGround);

            _items[item_index].Location.extend = 2;
            matrix_filled_rect(_items[item_index].Location, item_size);

            uint16_t delta_h = (item_size.Height - (_mainMenu.TextScale * 8)) + 2;
            Rect item_rect = matrix_create_rect(_items[item_index].Location, item_size);
            //Rect item_rect = matrix_reduce_rect(matrix_create_rect(_items[item_index].Location, item_size), 1);
            Rect f_rect = matrix_reduce_rect_height(item_rect, delta_h);
            matrix_fillRect3(f_rect.Location, f_rect.ClientSize, ForeGround);

            ST7789_setForeColor(_mainMenu.ColorSelectedText);
            ST7789_setBackColor(_mainMenu.ColorSelectedBackground);
           
        } else {
            
            // Не выделенный пункт меню
            ST7789_setForeColor(_mainMenu.ColorBackground);
            ST7789_setBackColor(_mainMenu.ColorText);
            matrix_fillRect3(_items[item_index].Location, item_size, ForeGround);

            ST7789_setForeColor(_items[item_index].ColorText);
            //ST7789_setBackColor(_mainMenu.ColorBackground);
            ST7789_setBackColor(_items[item_index].ColorText);
        }

        // Надпись на текущем пункте меню
        matrix_menu_itemtext_coord(_items[item_index], _mainMenu.TextScale);        
        matrix_writeString((uint8_t *) _items[item_index].Caption, 0, _mainMenu.TextScale);
        // ---------------------------------------------------------------------
        // Переходим к следующему пункту
        item_index++;
        y_current += _mainMenu.MenuItemHeight;
        // ---------------------------------------------------------------------
    }
    // -------------------------------------------------------------------------
    // 2. ЗАЛИВКА ОСТАТКА (Пустое место под последним отрисованным пунктом)
    // -------------------------------------------------------------------------
    // Вычисляем, сколько пикселей осталось до нижнего края client_rect
    int16_t bottom_edge = current_rect.Location.Y + current_rect.ClientSize.Height;
    int16_t diff_y = bottom_edge - y_current;

    if (diff_y > 0) {
        // Формируем Rect для "подвала" меню
        Rect tail_rect;
        tail_rect.Location.X = current_rect.Location.X;
        tail_rect.Location.Y = y_current;
        tail_rect.ClientSize.Width = item_size.Width; //current_rect.ClientSize.Width;
        tail_rect.ClientSize.Height = (uint16_t)diff_y;

        ST7789_setForeColor (_mainMenu.ColorBackground);
        matrix_fillRect (tail_rect, ForeGround);
    }
    // -------------------------------------------------------------------------
    // 3. Отрисовка боковой панели (имени) меню
    matrix_set_clientrect(_mainMenu.MenuRect);

    if (_mainMenu.MenuName[0] != '.') {
    
        //printf("Width for items: %d\r\n", menuitems_area.ClientSize.Width);

        ST7789_setForeColor(_mainMenu.ColorMenuHeap);
        matrix_fillRect(heap_area, ForeGround);
        // ---------------------------------------------------------------------
        ST7789_setForeColor(_mainMenu.ColorMenuHeapText);
        ST7789_setBackColor(_mainMenu.ColorMenuHeapText);
        // ---------------------------------------------------------------------
        // Центрование имени меню
        // ---------------------------------------------------------------------
        // Вычисление длины имени меню в пикселях
        uint16_t mh_width = matrix_measureString(_mainMenu.MenuName, _mainMenu.TextMenuNameScale);

        Point m_cpt_loc = heap_area.Location;

        m_cpt_loc.X += ((8 * _mainMenu.TextMenuNameScale) / 2) - 3;
        m_cpt_loc.Y += ((heap_area.ClientSize.Height - mh_width) / 2);

        matrix_setCoord2(m_cpt_loc);
        matrix_writeString((uint8_t *)_mainMenu.MenuName, 1, _mainMenu.TextMenuNameScale);
    }
    // -------------------------------------------------------------------------
    // 4. Рисуем общую рамку области отрисовки
    current_rect = matrix_get_clientrect();
    ST7789_setForeColor(_mainMenu.ColorBorder);
    matrix_draw_rect(current_rect.Location, current_rect.ClientSize);
    // -------------------------------------------------------------------------
}
// -----------------------------------------------------------------------------