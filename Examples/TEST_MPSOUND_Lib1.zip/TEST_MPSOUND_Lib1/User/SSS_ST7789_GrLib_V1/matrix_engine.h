/********************************** (C) COPYRIGHT ******************************
 * File Name          : matrix_engine.h
 * Author             : vantr
 * Version            : V1.2.0
 * Date               : 2026/02/20
 * Description        : Библиотека графики для OLED дисплея на ST7789 (CH32X033)
 * Module             : Графическая библиотека MATRIX™
 *******************************************************************************
 * Copyright (c) 2026 Vantr Universal Co., Ltd.
 * Библиотека не проверена в железе.
 *******************************************************************************/
#include "SSS_Common_Lib_V1/sss_classes.h"
#include "SSS_ST7789_GrLib_V1/sss_st7789_grlib1.h"
// -----------------------------------------------------------------------------
// Структура, представляющая герметрические точки
typedef struct {
    int16_t X;
    int16_t Y;
    uint16_t extend;
} Point;
// -----------------------------------------------------------------------------
// Структура, представляющая герметрические размеры
typedef struct {
    uint16_t Width;
    uint16_t Height;
} Size;
// -----------------------------------------------------------------------------
// Структура, представляющая прямоугольную область
typedef struct {
    Point Location;
    Size ClientSize;
} Rect;
// -----------------------------------------------------------------------------
typedef struct {
    Point Location;
    Size ClientSize;
    uint16_t BorderColor;
    uint16_t FillColor;
    uint16_t BackColor;
    uint8_t Value;      // 0...100
    uint8_t PrevValue;  // Для умной перерисовки
} ProgressBar;
// ----------------------------------------------------------------------------
// Выбор поверхности
typedef enum {
    // Цвет переднего плана
    ForeGround,
    // Цвет заднего плана
    BackGround
} TargetPlanes;
// -----------------------------------------------------------------------------
void matrix_restoreClientRect();
//void matrix_setClientRect(Rect new_client_rect);

void matrix_setSpace (uint8_t value);
void matrix_returnCaret();
void matrix_setCaret (int16_t value);
void matrix_setMargin (int16_t value);
void matrix_setCoord (int16_t X, int16_t Y);
void matrix_setCoord2 (Point data);
void matrix_addCaret (int16_t value);

void matrix_setBrush (uint16_t color);
uint16_t matrix_getBrush();
uint16_t matrix_getBackColor();
void matrix_setBackColor(uint16_t color);
Point matrix_create_point (uint16_t X, uint16_t Y);
Size matrix_create_size (uint16_t width, uint16_t height);
Rect matrix_create_rect (Point coords, Size client_size);
Rect matrix_create_rect2 (uint16_t X, uint16_t Y, uint16_t Width, uint16_t Height);
uint8_t matrix_point_in_rect (Point data, Rect rect);
uint8_t matrix_point_in_cliprect (uint16_t X, uint16_t Y);
void matrix_set_clientrect (Rect value);
Rect matrix_get_clientrect();
void matrix_frame_init();
void matrix_clearScreen();
uint16_t matrix_measureString (uint8_t *str, uint8_t scale);
void matrix_line (int16_t x0, int16_t y0, int16_t x1, int16_t y1);
void matrix_line2 (Point A1, Point A2);
void matrix_vertical_line(Point location, uint16_t width, uint8_t thickness);
void matrix_horizon_line(Point location, uint16_t width, uint8_t thickness);
void matrix_drawCircle (int16_t x0, int16_t y0, int16_t radius, uint8_t fill);
//void matrix_line3 (Point p0, Point p1);
void matrix_polygon (Point *data, uint8_t count, uint8_t closed);
Rect matrix_intersect_rects (Rect canvas, Rect window);

void matrix_writeString (uint8_t *str, uint8_t orientation, uint8_t scale);
void matrix_writeChar_Scaled (uint8_t c, uint8_t scale);
void matrix_writeCharV_Scaled (uint8_t c, uint8_t scale);

void matrix_draw_rect (Point loc, Size sz);
void matrix_client_rect();
void matrix_filled_rect (Point data, Size size);
Point matrix_shift_coords (Point data, int16_t X, int16_t Y);
Point matrix_get_rect_topright (Rect rect);
Point matrix_get_rect_bottomright (Rect rect);
Point matrix_get_rect_bottomleft (Rect rect);
Rect matrix_reduce_rect (Rect rect, uint8_t value);
Rect matrix_reduce_rect2 (Rect rect);
Rect matrix_increase_rect (Rect rect, uint8_t value);
Rect matrix_center_rect(Rect owner, Rect area);
Rect matrix_reduce_rect_height(Rect area, uint16_t delta);

void matrix_putPixelClip(uint16_t x, uint16_t y);

void matrix_fillRect3 (Point data, Size size, TargetPlanes target);
void matrix_fillRect2(uint16_t x, uint16_t y, uint16_t w, uint16_t h, TargetPlanes target);
//void matrix_fillRect(Rect area);
void matrix_fillRect(const Rect area, TargetPlanes target);

void matrix_centerCaret (Rect area, char *str, uint8_t scale);
void matrix_drawProgressBar (ProgressBar *pb, uint8_t newValue);

void matrix_draw_bitmap(uint16_t x, uint16_t y, uint8_t scale, const uint8_t *source);
void matrix_draw_bin_data (Rect area, const uint8_t *source);
void matrix_draw_led_font (uint8_t sym_code, Point coords, const uint8_t *font_data);
// -----------------------------------------------------------------------------
