/********************************** (C) COPYRIGHT ******************************
 * File Name          : matrix_engine.c
 * Author             : vantr
 * Version            : V1.1.0
 * Date               : 2026/02/21
 * Description        : Библиотека графики для OLED дисплея на ST7789 (CH32X033)
 * Module             : Графическая библиотека MATRIX™
 *******************************************************************************
 * Copyright (c) 2025 Vantr Universal Co., Ltd.
 * Библиотека проверена в железе
 *******************************************************************************/
// ------------------------------------------------------------------------------------------------
#include "SSS_ST7789_GrLib_V1/sss_st7789_grlib1.h"

#include "fonts.h"
#include "matrix_engine.h"
#include "SSS_Common_Lib_V1/sss_classes.h"

#include "matrix_cyrrilic.h"

#include <stdio.h>
#include <stdlib.h>
// ------------------------------------------------------------------------------------------------
// Настраиваемый шаг символов
#define SYM_STEP(scale, space) (((8 * scale) - (2 * scale)) + space)
// ------------------------------------------------------------------------------------------------
// Каретка отступа по вертикали при печати в буфер
uint16_t x_caret = 0;
// ------------------------------------------------------------------------------------------------
// Каретка отступа по горизонтали при печати в буфер
uint16_t y_caret = 0;
// ------------------------------------------------------------------------------------------------
// Пробел в пикселях между символами
uint8_t x_space = 0;
// ------------------------------------------------------------------------------------------------
/* // Начало отсчета по горизонтали
uint8_t x_scroll = 0;
// ------------------------------------------------------------------------------------------------
// Предел на сдвиг по горизонтали
unsigned int x_scroll_limit = 0; */
// ------------------------------------------------------------------------------------------------
// Область отрисовки
Rect client_rect = {
    { 0, 0 },
    { DISPLAY_WIDTH, DISPLAY_HEIGHT }
};
// -----------------------------------------------------------------------------
// Восстановление области отрисовки по физическому размеру экрана
void matrix_restoreClientRect() {

    client_rect.Location.X = 0;
    client_rect.Location.Y = 0;
    client_rect.ClientSize.Width = DISPLAY_WIDTH;
    client_rect.ClientSize.Height = DISPLAY_HEIGHT;
}
// -----------------------------------------------------------------------------
// Установка значения пробела между символами в пикселях [0...16]
void matrix_setSpace (uint8_t value) {

    if (value > 16) {
        return;
    }

    x_space = value;
}
// ------------------------------------------------------------------------------------------------
// Возврат каретки в начальную, нулевую позицию
void matrix_returnCaret() {

    x_caret = 0;
    y_caret = 0;

    // x_scroll = 0;
}
// ------------------------------------------------------------------------------------------------
// Установка каретки в любое указанное положение [-127...127]
void matrix_setCaret (int16_t value) {

    x_caret = value;
}
// ------------------------------------------------------------------------------------------------
// Установка отступа по вертикали
void matrix_setMargin (int16_t value) {

    y_caret = value;
}
// ------------------------------------------------------------------------------------------------
// Установка каретки в указанные координаты матрицы
void matrix_setCoord (int16_t X, int16_t Y) {

    x_caret = X;
    y_caret = Y;
}
// ------------------------------------------------------------------------------------------------
// Установка каретки в указанные координаты матрицы
void matrix_setCoord2 (Point data) {

    x_caret = data.X;
    y_caret = data.Y;
}
// ------------------------------------------------------------------------------------------------
// Сдвиг каретки на указанное количество пикселей [-127...127]
void matrix_addCaret (int16_t value) {

    x_caret += value;
}
// ------------------------------------------------------------------------------------------------
// Установить цвет переднего плана
void matrix_setBrush (uint16_t color) {

    ST7789_setForeColor (color);
}
// ------------------------------------------------------------------------------------------------
// Посмотреть цвет переднего плана
uint16_t matrix_getBrush() {

    return ST7789_getForeColor();
}
// ------------------------------------------------------------------------------------------------
// Посмотреть цвет заднего плана
uint16_t matrix_getBackColor() {

    return ST7789_getBackColor();
}
// ------------------------------------------------------------------------------------------------
// Установить цвет заднего плана
void matrix_setBackColor(uint16_t color) {

    ST7789_setBackColor(color);
}
// ------------------------------------------------------------------------------------------------
// Создание точки из координат
Point matrix_create_point (uint16_t X, uint16_t Y) {

    Point result;

    result.X = X;
    result.Y = Y;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Создание структуры размера из данных
Size matrix_create_size (uint16_t width, uint16_t height) {

    Size result;

    result.Width = width;
    result.Height = height;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Создание прямоугольной области
Rect matrix_create_rect (Point coords, Size client_size) {

    Rect result;

    result.Location = coords;
    result.ClientSize = client_size;

    return result;
}

// ------------------------------------------------------------------------------------------------
// Вычисление пересечения прямоугольников
Rect matrix_intersect_rects (Rect canvas, Rect window) {
    Rect result;

    // 1. Находим координаты левого верхнего угла пересечения
    int16_t x1 = (canvas.Location.X > window.Location.X) ? canvas.Location.X : window.Location.X;
    int16_t y1 = (canvas.Location.Y > window.Location.Y) ? canvas.Location.Y : window.Location.Y;

    // 2. Находим координаты правого нижнего угла (X + Width, Y + Height)
    int32_t canvas_right = canvas.Location.X + canvas.ClientSize.Width;
    int32_t canvas_bottom = canvas.Location.Y + canvas.ClientSize.Height;
    int32_t window_right = window.Location.X + window.ClientSize.Width;
    int32_t window_bottom = window.Location.Y + window.ClientSize.Height;

    int16_t x2 = (canvas_right < window_right) ? (int16_t)canvas_right : (int16_t)window_right;
    int16_t y2 = (canvas_bottom < window_bottom) ? (int16_t)canvas_bottom : (int16_t)window_bottom;

    // 3. Заполняем результат
    result.Location.X = x1;
    result.Location.Y = y1;
    result.Location.extend = 0;  // Или иное значение по умолчанию

    // Проверяем, есть ли пересечение вообще
    if (x2 > x1 && y2 > y1) {
        result.ClientSize.Width = (uint16_t)(x2 - x1);
        result.ClientSize.Height = (uint16_t)(y2 - y1);
    } else {
        result.ClientSize.Width = 0;
        result.ClientSize.Height = 0;
    }

    return result;
}
// ------------------------------------------------------------------------------------------------
// Создание прямоугольной области
Rect matrix_create_rect2 (uint16_t X, uint16_t Y, uint16_t Width, uint16_t Height) {

    Rect result;

    result.Location = matrix_create_point (X, Y);
    result.ClientSize = matrix_create_size (Width, Height);

    return result;
}
// ------------------------------------------------------------------------------------------------
// Проверка, попадает ли указанная точка в указанную область
uint8_t matrix_point_in_rect (Point data, Rect rect) {

    if (data.X >= rect.Location.X && data.X <= rect.Location.X + rect.ClientSize.Width) {

        if (data.Y >= rect.Location.Y && data.Y <= rect.Location.Y + rect.ClientSize.Height) {

            return 1;
        }
    }

    return 0;
}

// ------------------------------------------------------------------------------------------------
// Проверка, попадает ли указанная точка в отрисовываемую область экрана
uint8_t matrix_point_in_cliprect (uint16_t X, uint16_t Y) {

    // Прибавляем +1 к началу и вычитаем -1 от конца.
    // Теперь область отрисовки для контента СТРОГО внутри рамки.
    if (X > client_rect.Location.X && X < (client_rect.Location.X + client_rect.ClientSize.Width - 1)) {
        if (Y > client_rect.Location.Y && Y < (client_rect.Location.Y + client_rect.ClientSize.Height - 1)) {
            return 1;
        }
    }
    return 0;
}
// ------------------------------------------------------------------------------------------------
// Установка области отрисовки дисплея
void matrix_set_clientrect (Rect value) {

    // 1. Ограничиваем координаты (точка не может быть за пределами дисплея)
    // Используем DISPLAY_WIDTH как предел, координаты от 0 до WIDTH-1
    uint16_t x = (value.Location.X < DISPLAY_WIDTH) ? value.Location.X : (DISPLAY_WIDTH - 1);
    uint16_t y = (value.Location.Y < DISPLAY_HEIGHT) ? value.Location.Y : (DISPLAY_HEIGHT - 1);

    // 2. Считаем максимально возможный размер от этой точки
    uint16_t maxWidth = DISPLAY_WIDTH - x;
    uint16_t maxHeight = DISPLAY_HEIGHT - y;

    // 3. Ограничиваем размер (не больше запрошенного и не больше доступного)
    uint16_t w = (value.ClientSize.Width < maxWidth) ? value.ClientSize.Width : maxWidth;
    uint16_t h = (value.ClientSize.Height < maxHeight) ? value.ClientSize.Height : maxHeight;

    // Записываем результат
    client_rect.Location.X = x;
    client_rect.Location.Y = y;
    client_rect.ClientSize.Width = w;
    client_rect.ClientSize.Height = h;
}
// ------------------------------------------------------------------------------------------------
// Получение области отрисовки экрана
Rect matrix_get_clientrect() {

    return client_rect;
}
// ------------------------------------------------------------------------------------------------
// Очистка буфера и инициализация графики без изменения физического экрана
// Используется для начала рисования фрейма
void matrix_frame_init() {

    matrix_returnCaret();

    x_space = 1;

    matrix_restoreClientRect();
    //client_rect.Location = matrix_create_point (0, 0);
    //client_rect.ClientSize = matrix_create_size (DISPLAY_WIDTH - 1, DISPLAY_HEIGHT - 1);

    ST7789_setForeColor (CL_WHITE);
    ST7789_setBackColor(CL_BLACK);

    matrix_clearScreen();
}
// ------------------------------------------------------------------------------------------------
// Вывести пиксель, если он попадает внутрь области отрисовки
void matrix_putPixelClip(uint16_t x, uint16_t y) {
    
    if (matrix_point_in_cliprect(x, y)) {

        ST7789_putPixelFC(x, y);
    }
}
// ------------------------------------------------------------------------------------------------
// Очистка экрана
void matrix_clearScreen() {

    uint16_t fc_old = matrix_getBackColor();
    matrix_setBackColor(CL_BLACK);
    matrix_fillRect(client_rect, BackGround);
    matrix_setBackColor(fc_old);
}
// ------------------------------------------------------------------------------------------------
// Рассчет длины указанной строки в пикселях
uint16_t matrix_measureString(uint8_t *str, uint8_t scale) {
    uint16_t result = 0;

    for (int i = 0; str[i] != '\0'; ++i) {
        uint8_t c = str[i];

        // Обработка твоего спецсимвола 0xFF
        if (c == 0xFF) {
            result += (uint16_t)(1 * scale + x_space);
            continue;
        }

        // Логика определения КОДА символа для таблицы (ASCII или Кириллица)
        uint8_t char_code;

        if ((c == 0xD0 || c == 0xD1) && (matrix_cyr_Get_NOCyrillic() == 0)) {
            if (str[i+1] == '\0') break; 
            // Здесь должна быть твоя функция преобразования пары байт в индекс
            char_code = matrix_cyr_BASE_UTF2CYR(str[i], str[i+1]) + 0x20; 
            i++; // Пропускаем второй байт UTF-8
        } else {
            char_code = c;
        }

        // БЕРЕМ ШИРИНУ ИЗ 0-ГО БАЙТА ГЛИФА
        uint8_t sw = FONT_IMAGES[char_code - 0x20][0];
        
        // Прибавляем (ширина * масштаб + межсимвольный интервал)
        result += (uint16_t)(sw * scale + x_space);
    }

    // В конце строки последний x_space обычно лишний
    if (result >= x_space) result -= x_space;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Рисование залитого цветом прямоугольника
void matrix_fillRect2(uint16_t x, uint16_t y, uint16_t w, uint16_t h, TargetPlanes target) {

    Rect area_t = {{x, y}, {w, h}};
    matrix_fillRect(area_t, target);
}
// ------------------------------------------------------------------------------------------------
// Рисование залитого цветом прямоугольника
void matrix_fillRect3 (Point data, Size size, TargetPlanes target) {

    Rect area_t = { data, size };
    matrix_fillRect(area_t, target);
}
// ------------------------------------------------------------------------------------------------
// Заливка области, ограниченной областью отрисовки client_rect
void matrix_fillRect(const Rect area, TargetPlanes target) {

    // 1. Входные данные (как они есть)
    int32_t x0 = (int32_t)area.Location.X;
    int32_t y0 = (int32_t)area.Location.Y;
    int32_t x1 = x0 + (int32_t)area.ClientSize.Width - 1;
    int32_t y1 = y0 + (int32_t)area.ClientSize.Height - 1;

    // 2. Границы холста (client_rect)
    int32_t c_l = (int32_t)client_rect.Location.X;
    int32_t c_t = (int32_t)client_rect.Location.Y;
    int32_t c_r = c_l + (int32_t)client_rect.ClientSize.Width - 1;
    int32_t c_b = c_t + (int32_t)client_rect.ClientSize.Height - 1;

    // 3. ЖЕСТКИЙ КЛИППИНГ (Вместо того чтобы выходить, мы ПОДРЕЗАЕМ края)
    if (x0 < c_l) x0 = c_l;
    if (y0 < c_t) y0 = c_t;
    if (x1 > c_r) x1 = c_r;
    if (y1 > c_b) y1 = c_b;

    // 4. ПРОВЕРКА НА ВИДИМОСТЬ (Если после обрезки объект ушел "в минус")
    if (x1 < x0 || y1 < y0) {
        return; // Объект полностью за пределами видимости — вот тут выходим
    }

    // 5. РАСЧЕТ ДЛЯ ST7789 (Теперь x0, y0, x1, y1 гарантированно внутри окна)
    uint16_t real_w = (uint16_t)(x1 - x0 + 1);
    uint16_t real_h = (uint16_t)(y1 - y0 + 1);
    uint32_t total  = (uint32_t)real_w * real_h;

    uint16_t color = (target == ForeGround) ? matrix_getBrush() : matrix_getBackColor();

    // 6. ВЫВОД В ЖЕЛЕЗО
    ST7789_SetAddressWindow((uint16_t)x0, (uint16_t)y0, (uint16_t)x1, (uint16_t)y1);
    ST7789_OpenSession();
    for (uint32_t i = 0; i < total; i++) {
        ST7789_SendColor(color);
    }
    ST7789_CloseSession();
}

/*void matrix_fillRect(const Rect area, TargetPlanes target) {

    // --- 1. Входные данные (ЭКРАННЫЕ) ---
    int32_t x0 = (int32_t)area.Location.X;
    int32_t y0 = (int32_t)area.Location.Y;
    int32_t x1 = x0 + (int32_t)area.ClientSize.Width - 1;
    int32_t y1 = y0 + (int32_t)area.ClientSize.Height - 1;

    // --- 2. Границы "окна" (АБСОЛЮТНЫЕ) ---
    int32_t c_l = (int32_t)client_rect.Location.X;
    int32_t c_t = (int32_t)client_rect.Location.Y;
    int32_t c_r = c_l + (int32_t)client_rect.ClientSize.Width - 1;
    int32_t c_b = c_t + (int32_t)client_rect.ClientSize.Height - 1;

    // --- 3. КЛИППИНГ (Ножницы) ---
    // Если объект ПОЛНОСТЬЮ за пределами окна — выходим сразу
    if (x0 > c_r || y0 > c_b || x1 < c_l || y1 < c_t) return;

    // Подрезаем края, если они ВЫЛЕЗАЮТ за окно
    if (x0 < c_l) x0 = c_l;
    if (y0 < c_t) y0 = c_t;
    if (x1 > c_r) x1 = c_r;
    if (y1 > c_b) y1 = c_b;

    // --- 4. РАСЧЕТ ИТОГОВЫХ ПАРАМЕТРОВ ---
    // После подрезки проверяем, не схлопнулась ли область
    if (x1 < x0 || y1 < y0) return;

    uint16_t real_w = (uint16_t)(x1 - x0 + 1);
    uint16_t real_h = (uint16_t)(y1 - y0 + 1);
    uint32_t total = (uint32_t)real_w * real_h;

    // --- 5. ВЫВОД В ДРАЙВЕР ---
    uint16_t color = (target == ForeGround) ? matrix_getBrush() : matrix_getBackColor();

    ST7789_SetAddressWindow((uint16_t)x0, (uint16_t)y0, (uint16_t)x1, (uint16_t)y1);
    ST7789_OpenSession();
    for (uint32_t i = 0; i < total; i++) {
        ST7789_SendColor(color);
    }
    ST7789_CloseSession();
} */
// ------------------------------------------------------------------------------------------------
// Рисование толстой вертикальной линии цветом переднего плана
void matrix_vertical_line(Point location, uint16_t width, uint8_t thickness) {

    uint8_t thickness_t = (thickness > 30) ? 30 : thickness;

    //Point line_end = { location.X + width, location.Y };
    Size param_t = { thickness_t, width };

    matrix_fillRect3(location, param_t, ForeGround);
}
// ------------------------------------------------------------------------------------------------
// Рисование толстой горизонтальной линии цветом переднего плана
void matrix_horizon_line(Point location, uint16_t width, uint8_t thickness) {

    uint8_t thickness_t = (thickness > 30) ? 30 : thickness;

    //Point line_end = { location.X + width, location.Y };
    Size param_t = { width, thickness_t };

    matrix_fillRect3(location, param_t, ForeGround);
}
// ------------------------------------------------------------------------------------------------
// Рисование линии (Алгоритм Брезенхема)
void matrix_line (int16_t x0, int16_t y0, int16_t x1, int16_t y1) {

    // Вертикаль
    if (x0 == x1) {
        Rect r;
        r.Location.X = x0;
        r.Location.Y = (y0 < y1) ? y0 : y1;
        r.ClientSize.Width = 1;
        r.ClientSize.Height = abs (y1 - y0) + 1;
        //matrix_fillRect (r);
        matrix_fillRect(r, ForeGround);
        return;
    }
    // Горизонталь
    if (y0 == y1) {
        Rect r;
        r.Location.X = (x0 < x1) ? x0 : x1;
        r.Location.Y = y0;
        r.ClientSize.Width = abs(x1 - x0) + 1;
        r.ClientSize.Height = 1;
        //matrix_fillRect(r);
        matrix_fillRect(r, ForeGround);
        return;
    }

    int16_t dx = abs (x1 - x0), sx = x0 < x1 ? 1 : -1;
    int16_t dy = -abs (y1 - y0), sy = y0 < y1 ? 1 : -1;
    int16_t err = dx + dy, e2;

    uint16_t fcolor = matrix_getBrush();

    while (1) {
        // Увы, для наклонной линии без буфера ставим окно 1x1 для каждой точки
        if (matrix_point_in_cliprect(x0, y0)) {
        
            ST7789_SetAddressWindow (x0, y0, x0, y0);
            ST7789_OpenSession();
            ST7789_SendColor (fcolor);
            ST7789_CloseSession();
        }

        if (x0 == x1 && y0 == y1)
            break;
        e2 = 2 * err;
        if (e2 >= dy) {
            err += dy;
            x0 += sx;
        }
        if (e2 <= dx) {
            err += dx;
            y0 += sy;
        }
    }
}
// ------------------------------------------------------------------------------------------------
// Рисование линии (Алгоритм Брезенхема)
void matrix_line2 (Point A1, Point A2) {

    matrix_line (A1.X, A1.Y, A2.X, A2.Y);
}

// ------------------------------------------------------------------------------------------------
// Рисование окружности (Алгоритм Брезенхема)
void matrix_drawCircle (int16_t x0, int16_t y0, int16_t radius, uint8_t fill) {
    int16_t x = radius;
    int16_t y = 0;
    int16_t err = 0;

    while (x >= y) {
        if (fill) {
            // Используем FillRect для горизонтальных линий (заливка)
            // Рисуем 4 горизонтальных хорды
            matrix_fillRect ((Rect){
                {x0 - x,    y0 + y},
                {2 * x + 1, 1     }
            }, ForeGround);
            matrix_fillRect ((Rect){
                {x0 - x,    y0 - y},
                {2 * x + 1, 1     }
            }, ForeGround);
            matrix_fillRect ((Rect){
                {x0 - y,    y0 + x},
                {2 * y + 1, 1     }
            }, ForeGround);
            matrix_fillRect ((Rect){
                {x0 - y,    y0 - x},
                {2 * y + 1, 1     }
            }, ForeGround);
        } else {
            // Одиночные пиксели (8-симметрия)
            matrix_putPixelClip (x0 + x, y0 + y);
            matrix_putPixelClip (x0 + y, y0 + x);
            matrix_putPixelClip (x0 - y, y0 + x);
            matrix_putPixelClip (x0 - x, y0 + y);
            matrix_putPixelClip (x0 - x, y0 - y);
            matrix_putPixelClip (x0 - y, y0 - x);
            matrix_putPixelClip (x0 + y, y0 - x);
            matrix_putPixelClip (x0 + x, y0 - y);
        }

        if (err <= 0) {
            y += 1;
            err += 2 * y + 1;
        }
        if (err > 0) {
            x -= 1;
            err -= 2 * x + 1;
        }
    }
}
// ------------------------------------------------------------------------------------------------
// Рисование полигона (использует текущий цвет переднего плана)
void matrix_polygon (Point *data, uint8_t count, uint8_t closed) {

    // Минимум 2 точки для линии, и указатель не должен быть пустым
    if (data == NULL || count < 2)
        return;

    // Проходим по всем точкам, соединяя текущую со следующей
    for (uint8_t i = 0; i < (count - 1); i++) {
        matrix_line2 (data[i], data[i + 1]);
    }

    // Если полигон замкнутый — соединяем последнюю точку с первой
    if (closed) {
        matrix_line2 (data[count - 1], data[0]);
    }
}
// ------------------------------------------------------------------------------------------------
// Масштабируемая печать прозрачных (без фона) символов с выводом горизонтально
void matrix_writeChar_Scaled(uint8_t c, uint8_t scale) {

    if (scale == 0) return;

    const uint8_t *glyph = FONT_IMAGES[c - 0x20];
    uint8_t sw = glyph[0]; // Реальная ширина символа в битах

    int32_t clip_x0 = (int32_t)client_rect.Location.X;
    int32_t clip_y0 = (int32_t)client_rect.Location.Y;
    int32_t clip_x1 = clip_x0 + (int32_t)client_rect.ClientSize.Width - 1;
    int32_t clip_y1 = clip_y0 + (int32_t)client_rect.ClientSize.Height - 1;

    // 1. Внешний цикл по СТРОКАМ (их всегда 8 под 0-м байтом)
    for (uint8_t row = 0; row < 8; row++) {
        uint8_t row_data = glyph[row + 1]; 

        // 2. Внутренний цикл по БИТАМ (ограничен шириной sw)
        for (uint8_t bit = 0; bit < sw; bit++) {
            
            // Проверяем биты слева направо. 
            // Судя по данным (0x1F для #), старший бит — слева.
            if (row_data & (1 << (sw - 1 - bit))) {
                
                int32_t start_x = (int32_t)x_caret + (bit * scale);
                int32_t start_y = (int32_t)y_caret + (row * scale);

                // --- КЛИППИНГ (рассчитывается исходя из новой ориентации) ---
                if (start_x <= clip_x1 && (start_x + scale - 1) >= clip_x0 &&
                    start_y <= clip_y1 && (start_y + scale - 1) >= clip_y0) 
                {
                    int32_t rx0 = (start_x < clip_x0) ? clip_x0 : start_x;
                    int32_t ry0 = (start_y < clip_y0) ? clip_y0 : start_y;
                    int32_t rx1 = (start_x + scale - 1 > clip_x1) ? clip_x1 : (start_x + scale - 1);
                    int32_t ry1 = (start_y + scale - 1 > clip_y1) ? clip_y1 : (start_y + scale - 1);

                    matrix_fillRect2((uint16_t)rx0, (uint16_t)ry0, 
                                    (uint16_t)(rx1 - rx0 + 1), 
                                    (uint16_t)(ry1 - ry0 + 1), ForeGround);
                }
            }
        }
    }

    // 3. Шаг каретки ВПРАВО на sw
    x_caret += (uint16_t)(sw * scale + x_space);
}
// ------------------------------------------------------------------------------------------------
// Масштабируемая печать прозрачных (без фона) символов с выводом вертикально вниз
void matrix_writeCharV_Scaled (uint8_t c, uint8_t scale) {
    if (scale == 0)
        return;

    const uint8_t *glyph = FONT_IMAGES[c - 0x20];
    uint8_t sw = glyph[0];  // Теперь это будет "высотой" символа при печати вниз

    int32_t clip_x0 = (int32_t)client_rect.Location.X;
    int32_t clip_y0 = (int32_t)client_rect.Location.Y;
    int32_t clip_x1 = clip_x0 + (int32_t)client_rect.ClientSize.Width - 1;
    int32_t clip_y1 = clip_y0 + (int32_t)client_rect.ClientSize.Height - 1;

    // 1. Внешний цикл по байтам (теперь это шаги по ВЕРТИКАЛИ Y)
    for (uint8_t i = 0; i < 8; i++) {
        uint8_t row_data = glyph[i + 1];

        // 2. Внутренний цикл по битам (теперь это шаги по ГОРИЗОНТАЛИ X)
        for (uint8_t bit = 0; bit < sw; bit++) {

            // Проверяем бит. Чтобы буква не была зеркальной при повороте:
            if (row_data & (1 << (sw - 1 - bit))) {

                // ОТРАЖЕНИЕ ПО ГОРИЗОНТАЛИ:
                // Вместо x_caret + (i * scale) используем инверсию индекса i
                // i перебирает байты (0..7), поэтому 7 - i развернет их зеркально
                int32_t start_x = (int32_t)x_caret + ((7 - i) * scale);
                int32_t start_y = (int32_t)y_caret + (bit * scale);

                // --- КЛИППИНГ ---
                if (start_x <= clip_x1 && (start_x + scale - 1) >= clip_x0 &&
                    start_y <= clip_y1 && (start_y + scale - 1) >= clip_y0) {
                    int32_t rx0 = (start_x < clip_x0) ? clip_x0 : start_x;
                    int32_t ry0 = (start_y < clip_y0) ? clip_y0 : start_y;
                    int32_t rx1 = (start_x + scale - 1 > clip_x1) ? clip_x1 : (start_x + scale - 1);
                    int32_t ry1 = (start_y + scale - 1 > clip_y1) ? clip_y1 : (start_y + scale - 1);

                    matrix_fillRect2 ((uint16_t)rx0, (uint16_t)ry0,
                                      (uint16_t)(rx1 - rx0 + 1),
                                      (uint16_t)(ry1 - ry0 + 1), ForeGround);
                }
            }
        }
    }

    // 3. Шаг каретки ВНИЗ (используем sw, так как она стала вертикальным размером)
    y_caret += (uint16_t)(sw * scale + x_space);
}
// ------------------------------------------------------------------------------------------------
// Универсальная печать строки (scale [1..3] если ноль, то без вывода)
// Поддерживается кириллица UTF8 и флаг "здесь нет кириллицы"
void matrix_writeString(uint8_t *str, uint8_t orientation, uint8_t scale) {

    // 1. Предварительный расчет границ окна для проверок (используем знаковые типы)
    int32_t clip_x_min = (int32_t)client_rect.Location.X;
    int32_t clip_y_min = (int32_t)client_rect.Location.Y;
    int32_t clip_x_max = clip_x_min + (int32_t)client_rect.ClientSize.Width - 1;
    int32_t clip_y_max = clip_y_min + (int32_t)client_rect.ClientSize.Height - 1;

    // Реальный шаг символа
    uint8_t sym_step = SYM_STEP(scale, x_space);

    for (uint16_t i = 0; str[i] != '\0'; ++i) {

        // --- ПРОВЕРКА ВЫХОДА ЗА ГРАНИЦЫ (Предотвращение зависания) ---
        if (orientation == 0) {
            // Если каретка уже ниже видимой области — печатать дальше нет смысла
            if ((int32_t)y_caret > clip_y_max) break;
        } else {
            // Если каретка левее видимой области (при вертикальной печати влево)
            if ((int32_t)x_caret < clip_x_min - sym_step) break;
        }

        // Спец-символ 0xFF (сдвиг)
        if (str[i] == 0xFF) {
            if (orientation == 0) x_caret += x_space;
            else y_caret += x_space;
            continue;
        }

        // Перенос строки \n
        if (str[i] == '\n') {
            if (orientation == 0) {
                x_caret = (uint16_t)clip_x_min; // Возврат к левой границе ОКНА
                y_caret += sym_step;         // Шаг вниз с учетом масштаба
            } else {
                y_caret = (uint16_t)clip_y_min; // Возврат к верхней границе ОКНА
                x_caret -= sym_step;         // Шаг влево (вертикальная печать)
            }
            continue;
        }

        uint8_t final_code;
        // Обработка UTF-8
        if ((str[i] == 0xD0 || str[i] == 0xD1) && (matrix_cyr_Get_NOCyrillic() == 0)) {
            if (str[i+1] == '\0') break; // Защита от битой строки
            final_code = matrix_cyr_BASE_UTF2CYR (str[i], str[i + 1]) + 0x20;
            i++;
        } else {
            final_code = str[i];
        }

        // Печать в зависимости от ориентации
        // Функции writeChar внутри сами сделают мягкое отсечение (clipping)
        if (orientation == 0) {
            // Проверка: если символ не влезет по горизонтали, можно сделать автоперенос
            if ((int32_t)x_caret > clip_x_max) {
                 x_caret = (uint16_t)clip_x_min;
                 y_caret += sym_step + x_space;
                 if ((int32_t)y_caret > clip_y_max) break;
            }
            
            matrix_writeChar_Scaled (final_code, scale);
        } else {
            // Проверка для вертикали: если символ не влезет по вертикали
            if ((int32_t)y_caret > clip_y_max) {
                y_caret = (uint16_t)clip_y_min;
                x_caret -= sym_step;
                if ((int32_t)x_caret < clip_x_min) break;
            }

            matrix_writeCharV_Scaled (final_code, scale);
        }
    }

    matrix_cyr_RESet_NOCyrillic();
}

// ------------------------------------------------------------------------------------------------
// Рисование простой рамки указанного размера
void matrix_draw_rect (Point loc, Size sz) {

    if (sz.Width == 0 || sz.Height == 0) return;

    // Считаем КРАЙНИЕ точки один раз
    uint16_t x0 = loc.X;
    uint16_t y0 = loc.Y;
    uint16_t x1 = x0 + sz.Width - 1;
    uint16_t y1 = y0 + sz.Height - 1;

    // Рисуем 4 линии через fillRect (которая сделает клиппинг)
    matrix_fillRect((Rect){{x0, y0}, {sz.Width, 1}}, ForeGround); // Верх
    matrix_fillRect((Rect){{x0, y1}, {sz.Width, 1}}, ForeGround); // Низ
    matrix_fillRect((Rect){{x0, y0}, {1, sz.Height}}, ForeGround); // Лево
    matrix_fillRect((Rect){{x1, y0}, {1, sz.Height}}, ForeGround); // Право
}
// ------------------------------------------------------------------------------------------------
// Рамка в один пиксель по периметру области отрисовки
void matrix_client_rect() {

    Rect cli_r = matrix_get_clientrect(); // Получили АБСОЛЮТНЫЕ границы (например, x=3, y=3)

    uint16_t x = cli_r.Location.X;
    uint16_t y = cli_r.Location.Y;
    uint16_t w = cli_r.ClientSize.Width;
    uint16_t h = cli_r.ClientSize.Height;

    // Рисуем рамку ПО ЭТИМ ЖЕ экранным координатам. 
    // Тогда fillRect увидит, что x >= clip_left (3 >= 3) и пропустит линию.
    matrix_fillRect((Rect){{x, y}, {w, 1}}, ForeGround);         // Верх
    matrix_fillRect((Rect){{x, y}, {1, h}}, ForeGround);         // Лево
    matrix_fillRect((Rect){{x, y + h - 1}, {w, 1}}, ForeGround); // Низ
    matrix_fillRect((Rect){{x + w - 1, y}, {1, h}}, ForeGround); // Право

    /* // Временно делаем ВСЕ линии "толстыми" или "высокими"
    matrix_fillRect((Rect){{x, y}, {w, 5}}, ForeGround);         // Верх (5 пикселей)
    matrix_fillRect((Rect){{x, y}, {5, h}}, ForeGround);         // Лево (5 пикселей)
    matrix_fillRect((Rect){{x, y + h - 5}, {w, 5}}, ForeGround); // Низ (5 пикселей)
    matrix_fillRect((Rect){{x + w - 5, y}, {5, h}}, ForeGround); // Право (5 пикселей) */
}
// ------------------------------------------------------------------------------------------------
// Построение заштрихованного прямоугольника
void matrix_filled_rect (Point data, Size size) {
    // --------------------------------------------------------------------------------------------
    Point data2, data3;

    data2 = data;
    data3.X = data.X + size.Width;
    data3.Y = data.Y;

    uint8_t tackt_f = 0;
    uint8_t step_f = (data.extend > 10 || data.extend < 2) ? 2 : data.extend;

    uint16_t f_color = matrix_getBrush();
    uint16_t b_color = matrix_getBackColor();
    // --------------------------------------------------------------------------------------------
    for (int i = 0; i < size.Height; i++) {

        tackt_f += 1;

        if (tackt_f > step_f) {

            tackt_f = 0;
            matrix_setBrush(b_color);
        } else {

            matrix_setBrush(f_color);
        }

        matrix_line2 (data2, data3);

        data2.Y += 1;
        data3.Y += 1;
    }
    // --------------------------------------------------------------------------------------------
    matrix_setBrush(f_color);
    // --------------------------------------------------------------------------------------------
}
// ------------------------------------------------------------------------------------------------
// Сдвиг указанных координат на указанный диапазон
Point matrix_shift_coords (Point data, int16_t X, int16_t Y) {

    Point result;

    result.X = data.X + X;
    result.Y = data.Y + Y;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Получение координат верхнего правого угла прямоугольной области
Point matrix_get_rect_topright (Rect rect) {

    Point result;

    result.X = rect.Location.X + rect.ClientSize.Width - 1;
    result.Y = rect.Location.Y;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Получение координат верхнего правого угла прямоугольной области
Point matrix_get_rect_bottomright (Rect rect) {

    Point result;

    result.X = rect.Location.X + rect.ClientSize.Width;
    result.Y = rect.Location.Y + rect.ClientSize.Height;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Получение координат верхнего правого угла прямоугольной области
Point matrix_get_rect_bottomleft (Rect rect) {

    Point result;

    result.X = rect.Location.X;
    result.Y = rect.Location.Y + rect.ClientSize.Height;

    return result;
}
// ------------------------------------------------------------------------------------------------
// Пропорционально уменьшить прямоугольную область
Rect matrix_reduce_rect (Rect rect, uint8_t value) {

    Rect result;

    result.Location.X = rect.Location.X + value;
    result.Location.Y = rect.Location.Y + value;
    result.ClientSize.Width = rect.ClientSize.Width - (value * 2);
    result.ClientSize.Height = rect.ClientSize.Height - (value * 2);

    return result;
}
// ------------------------------------------------------------------------------------------------
// Пропорционально уменьшить прямоугольную область на один пиксель
Rect matrix_reduce_rect2 (Rect rect) {

    return matrix_reduce_rect (rect, 1);
}
// ------------------------------------------------------------------------------------------------
// Пропорционально увеличить прямоугольную область
Rect matrix_increase_rect (Rect rect, uint8_t value) {

    Rect result;

    result.Location.X = rect.Location.X - value;
    result.Location.Y = rect.Location.Y - value;
    result.ClientSize.Width = rect.ClientSize.Width + (value * 2);
    result.ClientSize.Height = rect.ClientSize.Height + (value * 2);

    return result;
}
// ------------------------------------------------------------------------------------------------
// Вписать прямоугольник area в центр owner
Rect matrix_center_rect(Rect owner, Rect area) {

    if (area.ClientSize.Width <= owner.ClientSize.Width && area.ClientSize.Height <= owner.ClientSize.Height) {

        uint16_t delta_w = ((owner.ClientSize.Width - area.ClientSize.Width) / 2);
        uint16_t delta_h = ((owner.ClientSize.Height - area.ClientSize.Height) / 2);

        Rect result = {
            {owner.Location.X + delta_w, owner.Location.Y + delta_h},
            {area.ClientSize.Width, area.ClientSize.Height}
        };

        return result;
    }

    return owner;
}
// ------------------------------------------------------------------------------------------------
// Пропорционально уменьшить только высоту указанной области
Rect matrix_reduce_rect_height(Rect area, uint16_t delta) {

    //if (area.ClientSize.Height < delta) { return area; }

    uint16_t delta_h = ((area.ClientSize.Height - delta) / 2);

    Rect result = {
            {area.Location.X, area.Location.Y + delta_h},
            {area.ClientSize.Width, area.ClientSize.Height - delta_h * 2}
        };

        return result;
}
// ------------------------------------------------------------------------------------------------
// Установка каретки для вывода горизонтальной строки по центру указанной области
void matrix_centerCaret (Rect area, char *str, uint8_t scale) {

    uint16_t strLen = 0;
    while (str[strLen] != '\0') strLen++;  // Считаем длину строки

    // 1. Вычисляем физическую ширину и высоту текста
    // (Ширина символа 8 + межсимвольный интервал x_space) * количество букв
    uint16_t shift_val = SYM_STEP(scale, x_space);
    uint16_t textWidth = strLen * shift_val - x_space;
    uint16_t textHeight = 8 * scale;

    // 2. Находим координаты левого верхнего угла текста внутри area
    // Формула: Старт + (Свободное место / 2)
    x_caret = area.Location.X + (area.ClientSize.Width - textWidth) / 2;
    y_caret = area.Location.Y + (area.ClientSize.Height - textHeight) / 2;
}
// ------------------------------------------------------------------------------------------------
// Рисование индикатора прогресса
void matrix_drawProgressBar (ProgressBar *pb, uint8_t newValue) {
    if (newValue > 100) newValue = 100;

    // 1. Отрисовка рамки (только при инициализации)
    if (pb->PrevValue == 0xFF) {
        ST7789_setForeColor(pb->BorderColor); // Устанавливаем цвет рамки
        matrix_draw_rect(pb->Location, pb->ClientSize);
    }

    // 2. Внутренние габариты (минус 2 пикселя на линии рамки)
    uint16_t innerWidth = pb->ClientSize.Width - 2;
    uint16_t innerHeight = pb->ClientSize.Height - 2;
    uint16_t startX = pb->Location.X + 1;
    uint16_t startY = pb->Location.Y + 1;

    // 3. Считаем ширину заполнения
    uint16_t pos = (uint32_t)innerWidth * newValue / 100;

    // 4. Рисуем ЗАПОЛНЕННУЮ часть
    if (pos > 0) {
        ST7789_setForeColor(pb->FillColor); // Устанавливаем цвет прогресса в Fore
        matrix_fillRect((Rect){
            {startX, startY},
            {pos,    innerHeight}
        }, ForeGround);
    }

    // 5. Затираем ОСТАВШУЮСЯ часть (фон внутри прогресс-бара)
    if (pos < innerWidth) {
        ST7789_setForeColor(pb->BackColor); // Устанавливаем цвет фона в Fore
        matrix_fillRect((Rect){
            {startX + pos,  startY},
            {innerWidth - pos, innerHeight}
        } ,ForeGround);
    }

    pb->PrevValue = newValue;
}

// ------------------------------------------------------------------------------------------------
// Вывод RAW форматированных бинарных массивов
void matrix_draw_bin_data (Rect area, const uint8_t *source) {

    uint16_t x_current = area.Location.X;
    uint16_t y_current = area.Location.Y;

    uint16_t f_color = matrix_getBrush();
    uint16_t b_color = matrix_getBackColor();

    // 1. Проходим по исходным пикселям
    for (uint16_t row = 0; row < area.ClientSize.Height; row++) {
        x_current = area.Location.X;

        for (uint16_t col = 0; col < area.ClientSize.Width; col++) {

            uint16_t current_data_index = (row * area.ClientSize.Width) + col;

            // Раскладываем байт на биты MSB
            for (int8_t dot_index = 7; dot_index >= 0; dot_index--) {

                // ПРОВЕРКА CLIPRECT
                if (matrix_point_in_cliprect (x_current, y_current)) {
                    ST7789_SetAddressWindow (x_current, y_current, x_current, y_current);

                    ST7789_OpenSession();

                    if (is_set_idx (source[current_data_index], dot_index)) {

                            ST7789_SendColor (f_color);
                    } else {

                            ST7789_SendColor (b_color);
                    }

                    ST7789_CloseSession();
                }

                x_current += 1;
            }
        }

        y_current += 1;
    }
}
// ------------------------------------------------------------------------------------------------
// Вывод 7Seg шрифтов с подложкой из неактивных символов
// для шрифта 32x50 единым массивом, символ = 200 байт
// Внимание ! Ссылка дается на весь массив символов, а не на конкретный символ!
void matrix_draw_led_font (uint8_t sym_code, Point coords, const uint8_t *font_data) {

    static const uint8_t SEG_SYM_WIDTH = (32 /*точки по вертикали*/ / 8);
    static const uint8_t SEG_SYM_HEIGHT = 50;

    uint8_t real_sym_code = (sym_code < 10) ? sym_code : 9;

    uint16_t x_current = coords.X;
    uint16_t y_current = coords.Y;

    uint16_t f_color = matrix_getBrush();
    uint16_t b_color = matrix_getBackColor();

    //uint16_t CL_BG = ST7789_DarkenColor(CL_GREEN, 3);
    //printf("mid_gray:%08x\r\n", CL_BG);

    // 1. Проходим по исходным пикселям
    for (uint16_t row = 0; row < SEG_SYM_HEIGHT; row++) {
        x_current = coords.X;

        for (uint16_t col = 0; col < SEG_SYM_WIDTH; col++) {

            uint16_t current_data_index = (real_sym_code * 200) + (((row * SEG_SYM_WIDTH) + col));
            uint16_t back_data_index = (8 * 200) + ((row * SEG_SYM_WIDTH) + col);

            // Раскладываем байт на биты MSB
            for (int8_t dot_index = 7; dot_index >= 0; dot_index--) {

                // ПРОВЕРКА CLIPRECT
                if (matrix_point_in_cliprect (x_current, y_current)) {
                    ST7789_SetAddressWindow (x_current, y_current, x_current, y_current);

                    uint8_t bg_present = is_set_idx (font_data[back_data_index], dot_index);

                    ST7789_OpenSession();

                    if (is_set_idx (font_data[current_data_index], dot_index)) {

                        ST7789_SendColor (f_color);
                    } else {

                        if (bg_present) {

                            ST7789_SendColor (CL_DARKENGREEN);
                        } else {

                            ST7789_SendColor (b_color);
                        }
                    }

                    ST7789_CloseSession();
                }

                x_current += 1;
            }
        }

        y_current += 1;
    }
}
// ------------------------------------------------------------------------------------------------
void matrix_draw_bitmap(uint16_t x, uint16_t y, uint8_t scale, const uint8_t *source) {
    
    if (scale < 1 && scale > 5) scale = 1;

    // 1. Извлекаем ширину и высоту (из первых 4 байт)
    Int16x coord;
    coord.cvalue[0] = source[0];
    coord.cvalue[1] = source[1];
    uint16_t w = coord.ivalue;

    coord.cvalue[0] = source[2];
    coord.cvalue[1] = source[3];
    uint16_t h = coord.ivalue;

    // 2. Проходим по исходным пикселям иконки
    for (uint16_t row = 0; row < h; row++) {
        for (uint16_t col = 0; col < w; col++) {
            
            // Рассчитываем координаты начала "увеличенного" пикселя на экране
            uint16_t screen_x = x + (col * scale);
            uint16_t screen_y = y + (row * scale);

            // 3. Быстрая проверка: если начало квадрата вне clipRect,
            // можно либо пропустить, либо проверять каждую точку внутри (для точности)
            
            // Получаем цвет (RGB565 - 2 байта)
            uint32_t pixel_idx = 4 + (row * w + col) * 2;
            uint8_t b1 = source[pixel_idx];
            uint8_t b2 = source[pixel_idx + 1];

            // 4. Отрисовка внутреннего квадрата scale x scale
            for (uint8_t sy = 0; sy < scale; sy++) {
                for (uint8_t sx = 0; sx < scale; sx++) {
                    uint16_t curr_x = screen_x + sx;
                    uint16_t curr_y = screen_y + sy;

                    // ПРОВЕРКА CLIPRECT
                    if (matrix_point_in_cliprect(curr_x, curr_y)) {
                        ST7789_SetAddressWindow(curr_x, curr_y, curr_x, curr_y);
                        ST7789_OpenSession();
                        ST7789_SendByte(b1);
                        ST7789_SendByte(b2);
                        ST7789_CloseSession();
                    }
                }
            }
        }
    }
}
// ------------------------------------------------------------------------------------------------
