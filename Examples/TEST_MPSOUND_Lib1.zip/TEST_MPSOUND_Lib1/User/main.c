/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2026/06/08
 * Description        : Main program body.
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/
// ----------------------------------------------------------------------------
// #define USE_OLED_DEBUG
// ----------------------------------------------------------------------------
#include "SSS_UART_Lib_V1/uart_lib.h"
#include "SSS_XProto_Lib3/sss_xproto_lib1.h"
#include "SSS_XProto_Lib3/sss_xproto_targets.h"

#include "app_config.h"

#ifdef USE_FLASH_W25Q
#include "SSS_W25Qxx_Lib_1/w25qxx.h"
#include "SSS_W25Qxx_Lib_1/hardware.h"
#include "sss_flash_const.h"
#endif

#include "SSS_Common_Lib_V1/sss_classes.h"
#include "SSS_Common_Lib_V1/sss_math.h"
#include "SSS_Common_Lib_V1/sss_byteList.h"

#ifdef USE_SOUND_GEN
#include "SSS_SoundLib1/sss_soundLib.h"
#include "SSS_SoundLib1/test_ui_snd1.h"
#endif

#ifdef USE_TFT_ST7789
#include "SSS_ST7789_GrLib_V1/sss_st7789_grlib1.h"
#include "SSS_ST7789_GrLib_V1/matrix_engine.h"
#endif

#ifdef USE_OLED_SSD1306
#include "SSS_SSD1306_TXT_V5/SSD1306.h"
#include "SSS_SSD1306_TXT_V5/FONTS.h"
#endif

#include "debug.h"
#include <string.h>
// ----------------------------------------------------------------------------
extern void view_oled_promo();
// ----------------------------------------------------------------------------
// Проект оптимизирован -Os, -flto, GCC15
// ----------------------------------------------------------------------------
// Версии компонентов оборудования
#define CONST_HARDWARE_NAME "W25-USB-V003_1"
#define CONST_HARDWARE_VERSION "H1.2"
#define CONST_SOFTWARE_VERSION "S1.2"
// ----------------------------------------------------------------------------
// Максимальное количество обрабатываемых за один раз файловых записей
#define CONST_FILES_INFO_MAX_COUNT          18          // 18 * 14 = 256
#define CONST_FILES_MAP_MAX_COUNT           128         // 128 * 2 = 256
#define FI_STRUCT_SIZE sizeof (fileRecord_t)            // Размер структуры
// ----------------------------------------------------------------------------
// Глобальные переменные
static uint8_t decoded_data[XPROTO_MAX_DATA_SIZE + 4];
static fileRecord_t file_info;
static uint16_t files_info_page_idx = 0;
static uint32_t address_map_ptr;
ProtoHeader _header = {0};
ProtoTarget _target = {0};
// ----------------------------------------------------------------------------
// Текущий номер страницы флеш
uint32_t _current_page = 0;
// ----------------------------------------------------------------------------
// Счетчик адреса непрерывной записи
uint32_t _current_page_writecont = 0;
// ----------------------------------------------------------------------------
// Отправка ББ считанной страницы памяти по адресу
void flash_send_page (uint16_t pagenum) {

    if (pagenum >= flash_hw->chip_size) {

        xproto_createStatusPacket (_header, pagenum, FLASH_STATE_RDPAGE_FAILED);
        return;
    }

    //printf ("pagenum: %u\r\n", (unsigned int)pagenum);

    if (W25_ReadPage (pagenum, decoded_data, 256) == 0) {

        _target.PackIdent = XP_FLASHPAGE_READ_PACKET;

        //W25_PrintPageDump(pagenum, decoded_data, 256);

        xproto_createBINDataPacket (decoded_data, 256, pagenum, _target);
    } else {

        // Больше данных нет!
        xproto_createStatusPacket (_header, pagenum, FLASH_STATE_RDPAGE_FAILED);
        return;
    }
}
// ----------------------------------------------------------------------------
// Отправка полный данных (свойств) указанного файла
void flash_send_fileinfo(uint16_t file_id) {

    //printf ("prop_id:%u\r\n", (unsigned int)file_id);

    fileRecord_t f_info;

    f_info.data.ID = file_id;
    f_info.data.Blocks = 0;
    f_info.data.Size = 0;

    uint8_t pack_len = sizeof(fileRecord_t);

    uint8_t res_fnd = W25_getFilesProperty (&f_info);

    if (res_fnd == 0) {

        memset (decoded_data, 0, sizeof(decoded_data));
        memcpy (decoded_data, f_info.raw, pack_len);

        _target.PackIdent = XP_BINDATA_PACKET;
        xproto_createBINDataPacket (decoded_data, pack_len, FLASH_PACK_SINGLEFILEINFO, _target);
    } else {

        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_FILEINFO_FAILED);
    }
}
// ----------------------------------------------------------------------------
// Получение сегмента указанного файла по номеру
void flash_get_filesegment_byID (uint16_t fileID, uint16_t seg_idx) {

    // printf ("id:%u, seg_idx:%u\r\n", (unsigned int)fileID, (unsigned int)seg_idx);

    volatile uint32_t found_page_idx = 0;
    sectorPage_t *tmp_data = W25_ReadFileSegment (fileID, seg_idx, &found_page_idx);

    // printf ("found:%u\r\n", (unsigned int)found_page_idx);
    // W25_PrintPageDump (0, tmp_data->raw, 16);

    if (W25_GetLastError() == LAST_ERROR_NO_ERROR) {

        // printf("try send packet...\r\n");
        _target.PackIdent = XP_FLASHPAGE_READ_PACKET;
        xproto_createBINDataPacket (tmp_data->raw, 256, found_page_idx, _target);
    } else {

        // Больше данных нет!
        xproto_createStatusPacket (_header, fileID, FLASH_STATE_RDPAGE_FAILED);
        return;
    }
}
// ----------------------------------------------------------------------------
// Получение информации о занимаемой памяти
void flash_get_memoryInfo() {

    sectorPage_t *tmp_data = W25_MemoryInfo();

    if (tmp_data) {

        _target.PackIdent = XP_BINDATA_PACKET;
        xproto_createBINDataPacket (tmp_data->data, tmp_data->LENGTH, FLASH_PACK_MEMINFO, _target);

        if (xproto_getProtoLastState() != XPROTO_PROTO_NO_ERROR) {

            xproto_createStatusPacket (_header, FLASH_PACK_MEMINFO, FLASH_STATE_MEMINFO_FAILED);
        }
    }
}
// ----------------------------------------------------------------------------
void flash_erase_sector (uint32_t sector_num) {

    //printf ("erasing sector: %u\r\n", (unsigned int)sector_num);

    if (sector_num < flash_hw->total_4K_sectors) {

        W25_EraseSector4K (sector_num);

        xproto_createStatusPacket (_header, FLASH_CMD_ERASE_SECTOR, 200);
    }

    // Иначе - статус 106!
    xproto_createStatusPacket (_header, FLASH_CMD_ERASE_SECTOR, 106);
}
// ----------------------------------------------------------------------------
// Получение карты тома (файлы) последовательное
void flash_create_fileList() {

    uint8_t total_founded = 0;
    uint16_t data_ptr = 0;

    while (total_founded < CONST_FILES_INFO_MAX_COUNT) {

        //  Сохраняем индекс найденного файла, как указатель для следующего поиска
        files_info_page_idx = W25_createFilesMap_SinglePassEx (files_info_page_idx, &file_info);

        //printf ("total_founded: %u\r\n", (unsigned int)total_founded);
        //printf ("files_info_page_idx: %u\r\n", (unsigned int)files_info_page_idx);

        if (files_info_page_idx < flash_hw->totalx_pages) {

            if (file_info.data.ID > 0) {

                // Копируем одну структуру
                memcpy (&decoded_data[data_ptr], &file_info, FI_STRUCT_SIZE);

                data_ptr += FI_STRUCT_SIZE;
                total_founded += 1;
            }
        } else {

            break;
        }
    }


    // Отправка пакета
    if (total_founded > 0) {

        //W25_PrintPageDump (0, decoded_data, total_founded * 8);

        _target.PackIdent = XP_BINDATA_PACKET;
        xproto_createBINDataPacket (decoded_data, total_founded * FI_STRUCT_SIZE, FLASH_PACK_FILEINFO, _target);

        if (xproto_getProtoLastState() != XPROTO_PROTO_NO_ERROR) {

            // Ошибка!
            files_info_page_idx = 0;
            xproto_createStatusPacket (_header, FLASH_PACK_FILEINFO, FLASH_STATE_FILEINFO_ERR);
        }
    } else {

        // Данных больше нет
        files_info_page_idx = 0;
        xproto_createStatusPacket (_header, FLASH_PACK_FILEINFO, FLASH_STATE_FILEINFO_DONE);
    }
}
// ----------------------------------------------------------------------------
// Создание карты указанного файла
void flash_create_filemap (uint16_t file_id) {

    //printf ("file_id: %u\r\n", (unsigned int)file_id);
    Params16 param_tmp;

    param_tmp.param1 = file_id;
    param_tmp.param2 = CONST_FILES_MAP_MAX_COUNT;
    param_tmp.param3 = address_map_ptr;
    param_tmp.param4 = 0;

    //printf ("start_idx: %u\r\n", (unsigned int)address_map_ptr);
    //printf ("param1: %u\r\n", (unsigned int)param_tmp.param1);
    //printf ("param2: %u\r\n", (unsigned int)param_tmp.param2);
    //printf ("param3: %u\r\n", (unsigned int)param_tmp.param3);
    //printf ("param4: %u\r\n", (unsigned int)param_tmp.param4);

    uint16_t founded_pages_cnt = W25_BuildFileMapEx2 (param_tmp, decoded_data);

    //W25_PrintPageDump(0, decoded_data, founded_pages_cnt * 2);

    //printf ("page_addr_total: %u\r\n", (unsigned int)founded_pages_cnt);

    if (founded_pages_cnt == 0) {

        //printf ("send_status_233...\r\n");
        address_map_ptr = 0;
        xproto_createStatusPacket (_header, FLASH_PACK_MAPDATA, FLASH_STATE_MAPDATA_DONE);

        return;
    } else {

        //printf ("send_pack_mapdata...\r\n");
        _target.PackIdent = XP_BINDATA_PACKET;
        xproto_createBINDataPacket (decoded_data, founded_pages_cnt * 2, FLASH_PACK_MAPDATA, _target);

        if (xproto_getProtoLastState() == XPROTO_PROTO_NO_ERROR) {

            address_map_ptr += founded_pages_cnt;

            return;
        }
    }

    // Закончено
    address_map_ptr = 0;
    xproto_createStatusPacket (_header, FLASH_PACK_MAPDATA, FLASH_STATE_MAPDATA_DONE);
}
// ----------------------------------------------------------------------------
// Поиск пустого места
void flash_find_freewindows_contarea (uint16_t ID, uint32_t total) {

    // printf ("id: %u, total: %u\r\n", (unsigned int)ID, (unsigned int)total);

    if (flash_hw->nonx_area_begin == 0) {

        xproto_createStatusPacket (_header, FLASH_PACK_FILECONTINFO, FLASH_STATE_CONTAREA_FULL);
        return;
    }

    uint32_t fnd_begin = W25_FindContArea (total);

    //printf("free area begin: %u\r\n", (unsigned int)fnd_begin);

    if (fnd_begin < flash_hw->nonx_area_begin) {

        xproto_createStatusPacket (_header, FLASH_PACK_FILECONTINFO, FLASH_STATE_CONTAREA_FULL);
        return;
    }

    fileRecord_t result = {0};

    result.data.Address = fnd_begin;
    result.data.Blocks = total;
    result.data.ID = ID;

    uint16_t length = sizeof (fileRecord_t);

    memcpy (decoded_data, result.raw, length);

    _target.PackIdent = XP_FLASHPAGE_READ_PACKET;
    xproto_createBINDataPacket (decoded_data, length, FLASH_PACK_FILECONTINFO, _target);

    if (xproto_getProtoLastState() != XPROTO_PROTO_NO_ERROR) {

        xproto_createStatusPacket (_header, FLASH_PACK_FILECONTINFO, FLASH_STATE_CONTAREA_FULL);
    }
}
// ----------------------------------------------------------------------------
// Обработка бинарных пакетов (с адресом)
void execute_bindata_pack (uint8_t *pack_data, uint16_t len, ProtoTarget target) {
    // ------------------------------------------------------------------------
    // printf ("eeprom 1: %u\r\n", (unsigned int)len);
    if (len < 2) {
        return;
    }
    // ------------------------------------------------------------------------
    // xproto_PrintData (pack_data, len);
    // ------------------------------------------------------------------------
    // Пересборка пакета для отладки
    packet_t *packet = xproto_decodeBINPacked (pack_data, len);

    uint8_t real_target = xproto_createTarget2 (target);
    ProtoHeader header = xproto_createProtoHeader (packet->full_buffer, len, real_target);
    // ------------------------------------------------------------------------
    // Сборка окончательного пакета
    xproto_createProtoPacket (packet->full_buffer, header);
    // ------------------------------------------------------------------------
    // Если нет ошибок, отправляем его обратно
    if (xproto_getProtoLastState() == XPROTO_PROTO_NO_ERROR) {

        xproto_sendTXBufferNow();

    } else {

        // Иначе - статус 120!
        xproto_createStatusPacket (header, XP_STATUS_PACKET, 120);
    }
    // -----------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
// Удаление файла по индексу
void flash_erase_file(uint16_t file_idx) {

    if (W25_HideFile(file_idx) == 0) {

        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_DELFILE_OK);
    } else {

        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_DELFILE_FAILED);
    }
}
// ----------------------------------------------------------------------------
// Уборка мусора
void flash_go_gcc() {

    uint8_t result = W25_CollectGarbage();

    // 0 - успешное расселение одного сектора
    // 1 - сектор расселить не удалось (кончилось место?)
    // 2 - критическая ошибка
    // 3 - все хорошо, расселять некого
    xproto_createStatusPacket (_header, result, FLASH_STATE_GCC_COMPLETE);
}
// ----------------------------------------------------------------------------
// Рисование картинки по file_id
void flash_show_bitmap (uint16_t file_idx, uint8_t scale) {
#ifdef USE_TFT_ST7789
    ST7789_DisplayOff();    // Большие картинки (на весь экран) нужно прятать во время вывода
    matrix_clearScreen();    
    ST7789_drawContIconFF(file_idx, 0, 0, 1);
    ST7789_DisplayOn();
#endif
#ifdef USE_OLED_SSD1306
    if (file_idx == 0xFFFF) {

        view_oled_promo();
        return;
    }

    SSD1306_BASE_ClearScreen(1);
    SSD1306_BASE_SetCursor(6, 1);
    SSD1306_BASE_WriteStr ((uint8_t *)"NO", SSD1306_SYMSTYLE_WIDE | SSD1306_SYMSTYLE_INV);
    SSD1306_BASE_SetCursor (0, 4);
    SSD1306_BASE_WriteStr ((uint8_t *)"Graphics", SSD1306_SYMSTYLE_WIDE);
#endif
}
// ----------------------------------------------------------------------------
// Выполнение входящих команд от внешнего приложения
void execute_incoming_cmd (cmd_packex_t cmd_pack) {

    switch (cmd_pack.cmd) {

    // Установка текущей страницы памяти
    case FLASH_CMD_SET_CURPAGE:

        _current_page = cmd_pack.param;
        flash_send_page (_current_page);

        break;

    // Получение указанного сегмента указанного файла
    case FLASH_CMD_GET_FDBYID:

        flash_get_filesegment_byID (cmd_pack.param, cmd_pack.ext_param);
        break;

    // Получение списка файлов флеш-памяти
    // Возвращает первые записи о файлах
    // STATUS 230 - список исчерпан
    case FLASH_CMD_GET_FILES:

        files_info_page_idx = 0;
        flash_create_fileList();

        break;

    // Возвращает остальные записи до STATUS 230
    case FLASH_CMD_GET_FILESINFO:

        flash_create_fileList();

        break;

    // Последовательный поиск адресов страниц указанного файла
    case FLASH_CMD_FINDFILEPAGES:

        flash_create_filemap (cmd_pack.param);

        break;

    // Проверка на существование файла с указанным ID
    // STATUS 237 - файл существует
    // STATUS 137 - файл не существует
    case FLASH_CMD_GET_FILEEXISTSID:

        if (W25_FileExists (cmd_pack.param) == 1) {

            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_FILE_EXISTS);
        } else {

            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_FILE_NOFOUND);
        }

        break;

    // Запрос на удаление указанного сегмента файла
    case FLASH_CMD_HIDE_FILESEGMENT:

        if (W25_EraseFileSegment (cmd_pack.param, cmd_pack.ext_param) == 1) {

            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_HFS_OK);
        } else {

            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_HFS_FAILED);
        }

        break;

    // Удаление файла по ID
    case FLASH_CMD_ERASE_FILE:

        flash_erase_file (cmd_pack.param);

        break;

    // Запрос на поиск свободного места в непрерывной области
    case FLASH_CMD_FINDCONTPLACE:

        //  File ID         нужно страниц
        flash_find_freewindows_contarea (cmd_pack.param, cmd_pack.ext_param);

        break;

#ifdef USE_SOUND_GEN
    // Установка громкости звука
    case FLASH_CMD_PLAY_VOLUME:

        Play_SetVolume(cmd_pack.param);
        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_CMD_OK);

        break;

    // Проиграть файл по его ID
    case FLASH_CMD_PLAY_SND:

        Play_SoundFromFlash (cmd_pack.param);
        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_PLAYSND_OK);

        break;

    case FLASH_CMD_PLAY_CONTSND:

        Play_SoundContFromFlash (cmd_pack.param);
        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_PLAYSND_OK);

        break;

    case FLASH_CMD_PLAY_TEST_SND:

        Play_SoundFromBuffer (SOUND_CLICK_DATA, sizeof (SOUND_CLICK_DATA));
        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_PLAYSND_OK);

        break;
#endif

    // Запрос на установку счетчика адреса непрерывной записи файла
    case FLASH_CMD_SETWRITEADDR:

        if (flash_hw->nonx_area_begin > 0 && flash_hw->nonx_area_begin < flash_hw->chip_size && cmd_pack.param >= flash_hw->nonx_area_begin) {

            _current_page_writecont = cmd_pack.param;
            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_SETWRITEADDR_OK);
        } else {

            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_SETWRITEADDR_FAILED);
        }

        break;

    case FLASH_CMD_WIPE_CONTAREA:

        W25_ClearContArea();
        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_ERASE_CONTMEM_OK);

        break;

    // Получение свойств указанного файла
    case FLASH_CMD_FILE_PROP:

        flash_send_fileinfo(cmd_pack.param);
        break;

    // Получение информации о занимаемой памяти
    case FLASH_CMD_GET_MEMINFO:

        flash_get_memoryInfo();
        break;

    // Стирание сектора
    case FLASH_CMD_ERASE_SECTOR:

        flash_erase_sector (cmd_pack.param);

        break;

    // Показать файл как картинку
    case FLASH_CMD_SHOW_BITMAP:

        flash_show_bitmap(cmd_pack.param, cmd_pack.ext_param);
        break;

    // Полное стирание флешки
    case FLASH_CMD_WIPE_ALL:

        W25_WipeAll_Async (1);
        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_WIPEALL_DONE);

        break;

    case FLASH_CMD_GO_GCC:

        flash_go_gcc();
        break;

    case FLASH_CMD_SYS_REBOOT:

        if (cmd_pack.param == 0x01AD1B72) {

            xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_GO_REBOOT_NOW);
            Delay_Ms (1000);

            NVIC_SystemReset();
        }

        break;

    default:

        xproto_createStatusPacket (_header, XP_STATUS_PACKET, FLASH_STATE_BAD_COMMAND);
        break;
    }
}
// ----------------------------------------------------------------------------
// Обработка данных (не протокол)
// Функцию можно определить в любом внешнем модуле (C файле)
void execute_cmd_noproto() {
    // -------------------------------------------------------------------------
    // Команда "Get hardware name"
    if (xproto_Compare_Str ((uint8_t *)"AW?", 3)) {

        xproto_resetBufferData();
        xproto_sendStr ((uint8_t *)CONST_HARDWARE_NAME, sizeof (CONST_HARDWARE_NAME), 1);
        return;
    }
    // -------------------------------------------------------------------------
    // Команда "Get hardware version"
    if (xproto_Compare_Str ((uint8_t *)"AWHW?", 5)) {

        xproto_resetBufferData();
        xproto_sendStr ((uint8_t *)CONST_HARDWARE_VERSION, sizeof (CONST_HARDWARE_VERSION), 1);
        return;
    }
    // -------------------------------------------------------------------------
    // Команда "Get software version"
    if (xproto_Compare_Str ((uint8_t *)"AWSW?", 5)) {

        xproto_resetBufferData();
        xproto_sendStr ((uint8_t *)CONST_SOFTWARE_VERSION, sizeof (CONST_SOFTWARE_VERSION), 1);
        return;
    }
    // -------------------------------------------------------------------------
    // Команда "Get flash type"
    if (xproto_Compare_Str ((uint8_t *)"AWFT?", 5)) {

        xproto_resetBufferData();

        if (flash_hw == NULL) {

            xproto_sendStr ((uint8_t *)"FLHW_W25Q_UNKNOWN", 17, 1);
            return;
        }

        switch (flash_hw->chip_id) {

        case HW_FLASH_W25Q32_ID:

            xproto_sendStr ((uint8_t *)"FLHW_W25Q32", 11, 1);
            break;

        case HW_FLASH_W25Q64_ID:

            xproto_sendStr ((uint8_t *)"FLHW_W25Q64", 11, 1);
            break;

        case HW_FLASH_W25Q128_ID:

            xproto_sendStr ((uint8_t *)"FLHW_W25Q128", 12, 1);
            break;

        default:

            xproto_sendStr ((uint8_t *)"FLHW_W25QUNKNOWN", 17, 1);
            break;
        }

        return;
    }
    // -------------------------------------------------------------------------
    // Команда "Get equipment" (список оборудования)
    if (xproto_Compare_Str ((uint8_t *)"AWEQ?", 5)) {

        uint8_t eq_tmp[10] = "AWEQ=?????";

#ifdef USE_FLASH_W25Q
        // Флеш память подключена
        eq_tmp[5] = 'F';

        switch (flash_hw->chip_id) {

        case HW_FLASH_W25Q32_ID:

            eq_tmp[6] = '1';
            break;

        case HW_FLASH_W25Q64_ID:

            eq_tmp[6] = '2';
            break;

        case HW_FLASH_W25Q128_ID:

            eq_tmp[6] = '3';
            break;

        default:

            eq_tmp[6] = '0';
            break;
        }
#endif

#ifdef USE_OLED_SSD1306
        // OLED дисплей SSD1306
        eq_tmp[7] = 'W';
#endif

#ifdef USE_TFT_ST7789
        // TFT дисплей ST7789
        eq_tmp[2] = 'T';
#endif

#ifdef USE_SOUND_GEN
        // Звук включен
        eq_tmp[8] = 'S';
#endif

#ifdef USE_SPI_HARDWARE
        // Используется аппаратный SPI
        eq_tmp[9] = 'H';
#else
        // Используется программный SPI
        eq_tmp[9] = 'P';
#endif

        xproto_resetBufferData();
        xproto_sendStr ((uint8_t *)eq_tmp, 10, 1);
        return;
    }
    // -------------------------------------------------------------------------
    // Если принята неизвестная команда
    // -------------------------------------------------------------------------
    // Если нет совпадений по командам
    xproto_sendStr ((uint8_t *)"ERR:100", 7, 1);
    // -------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
// Выполнение команд X-Proto
// Функцию можно определить в любом внешнем модуле (C файле)
void execute_xproto_cmd() {
    // ------------------------------------------------------------------------
    _header = xproto_decodeProtoPacket (decoded_data);
    _target = xproto_decodeTarget (_header.target);

    // printf ("CRC Rx: 0x%02X | CRC Cal: 0x%02X\r\n", _header.crc8, cal_crc);

    if (xproto_getProtoLastState() != XPROTO_PROTO_NO_ERROR) {

        xproto_resetBufferData();
        xproto_sendStr ((uint8_t *)"ERRXP:101", 9, 1);

        return;
    }
    // ------------------------------------------------------------------------
    // Тестовый пакет
    // ------------------------------------------------------------------------
    if (_target.PackIdent == XP_DATA_TEST_PACKET) {

        // Тестовые пакеты не поддерживаются
        xproto_createStatusPacket (_header, XP_DATA_TEST_PACKET, 101);

        return;
    }
    // ------------------------------------------------------------------------
    // Пакет XP_CMD_PACKET
    // ------------------------------------------------------------------------
    if (_target.PackIdent == XP_CMD_PACKET) {

        cmd_packex_t received;

        // 1. Распаковываем то, что пришло от ББ (Большого Брата / ПК)
        // Используем указатель на данные внутри входящего пакета протокола X
        xproto_decodeCMDPacket (decoded_data, _header.length.val, &received);

        // 2. Собираем такой же пакет из тех же самых вытащенных данных
        // target меняем на тот, который ждет ПК (например, XP_CMD_REPLY)
        // ProtoTarget reply_target = _target;

        execute_incoming_cmd (received);
        // xproto_createCMDPacket (received.cmd, received.id, received.param, reply_target);

        return;
    }
    // ------------------------------------------------------------------------
    // Пакет XP_BINDATA_PACKET
    // ------------------------------------------------------------------------
    if (_target.PackIdent == XP_BINDATA_PACKET) {

        // execute_bindata_pack (decoded_data, _header.length.val, _target);
        //  Чистые BINData пакеты не поддерживаются
        xproto_createStatusPacket (_header, XP_BINDATA_PACKET, 102);

        return;
    }
    // ------------------------------------------------------------------------
    // Пакет XP_BINDATA_READ_PACKET (запрос на чтение)
    // ------------------------------------------------------------------------
    if (_target.PackIdent == XP_BINDATA_READ_PACKET) {

        // Чистые BINData пакеты не поддерживаются
        xproto_createStatusPacket (_header, XP_BINDATA_READ_PACKET, 103);

        return;
    }
    // ------------------------------------------------------------------------
    // Пакет XP_BINDATA_WRITE_PACKET
    // ------------------------------------------------------------------------
    if (_target.PackIdent == XP_BINDATA_WRITE_PACKET) {

        packet_t *buffer = xproto_decodeBINPacked (decoded_data, _header.length.val);

        if (buffer) {

            // W25_PrintPageDump(buffer->header_u32, buffer->buffer);

            uint32_t real_addr = buffer->header_u32 * W25Q_PAGE_SIZE;

            if (W25_WritePage_Verified (real_addr, buffer->buffer, _header.length.val - 4) == 0) {
                // Запись успешно завершена
                xproto_createStatusPacket (_header, XP_BINDATA_WRITE_PACKET, 201);

                return;
            }
        }

        // Что-то пошло не так
        xproto_createStatusPacket (_header, XP_BINDATA_WRITE_PACKET, 104);

        return;
    }
    // ------------------------------------------------------------------------
    if (_target.PackIdent == XP_FLASHPAGE_WRITE_PACKET) {

        packet_t *buffer = xproto_decodeBINPacked (decoded_data, _header.length.val);

        // W25_PrintPageDump(0, buffer->buffer);
        //printf ("page_addr: %u\r\n", (unsigned int)buffer->header_u32);
        //printf ("page_leng: %u\r\n", (unsigned int)_header.length.val);

        // Запись страницы
        if (W25_StoreBinDataPart (buffer->buffer, _header.length.val - 4) == 0) {

            // Запись успешно завершена
            xproto_createStatusPacket (_header, XP_FLASHPAGE_WRITE_PACKET, FLASH_STATE_WRPAGE_OK);

            return;
        }

        // Что-то пошло не так
        xproto_createStatusPacket (_header, XP_FLASHPAGE_WRITE_PACKET, FLASH_STATE_WRPAGE_FAILED);

        return;
    }
    // ------------------------------------------------------------------------
    // Пакет записи в непрерывную область памяти
    if (_target.PackIdent == XP_FLASHPAGE_CONTWRITE_PACKET) {

        if (flash_hw->nonx_area_begin > 0 && flash_hw->nonx_area_begin < flash_hw->chip_size && _current_page_writecont >= flash_hw->nonx_area_begin) {

            // printf ("XP_FLASHPAGE_CONTWRITE_PACKET 2\r\n");
            //  Здесь можно производить запись
            packet_t *buffer = xproto_decodeBINPacked (decoded_data, _header.length.val);

            // W25_PrintPageDump (_current_page_writecont, buffer->buffer, _header.length.val);
            // printf ("page_addr: %u\r\n", (unsigned int)_current_page_writecont);
            // printf ("page_leng: %u\r\n", (unsigned int)_header.length.val);

            // Внешнее приложение должно прислать полностью сформированную
            // страницу памяти по протоколу X! 256 байт, включая заголовок!

            // Запись страницы
            if (W25_WriteContPage (_current_page_writecont, buffer->buffer, _header.length.val - 4) == 0) {

                // Инкремент адреса записи
                _current_page_writecont += 1;
                
                if (_current_page_writecont >= flash_hw->chip_size) {

                    // Область заполнена
                    xproto_createStatusPacket (_header, XP_FLASHPAGE_CONTWRITE_PACKET, FLASH_STATE_CONTAREA_FULL);                  

                    return;
                }

                // Запись успешно завершена
                xproto_createStatusPacket (_header, XP_FLASHPAGE_CONTWRITE_PACKET, FLASH_STATE_WRITECONTADDR_OK);

                return;
            }

        } else {

            // Что-то пошло не так
            xproto_createStatusPacket (_header, XP_FLASHPAGE_CONTWRITE_PACKET, FLASH_STATE_WRITECONTADDR_FAILED);

            return;
        }
    }
    // ------------------------------------------------------------------------
    // Если ничего не сработало, значит - ошибка
    xproto_createStatusPacket (_header, 0, 100);
    // ------------------------------------------------------------------------
}
#ifdef USE_TFT_ST7789
// ----------------------------------------------------------------------------
// Графическая демка для TFT экранов
void view_promo() {

    matrix_frame_init();

    ST7789_setForeColor (CL_WHITE);
    matrix_client_rect();

    Rect heap_area;

    heap_area.Location = (Point){ 5, 5 };
    heap_area.ClientSize = (Size){ matrix_get_clientrect().ClientSize.Width - 10, 40 };

    ST7789_setForeColor (CL_BLUE);
    matrix_fillRect(heap_area, ForeGround);

    ST7789_setForeColor (CL_YELLOW);
    matrix_setSpace (3);
    matrix_setCaret (10);
    matrix_setMargin(12);
    matrix_writeString ((uint8_t *)"Тест CH32V003", 0, 3);

    ST7789_drawIconFF (1, 10, 50, 2);
    ST7789_drawIconFF (2, 80, 50, 2);
    ST7789_drawIconFF (3, 150, 50, 2);

    // Рисуется примерно 10 секунд
    //ST7789_drawIconFF (0x00CD, 0, 0, 1);
}
#endif

// ----------------------------------------------------------------------------
#ifdef USE_OLED_SSD1306

uint8_t led_str2[] = {0xC0, 0xC2, 0xC4, 0xC6, 0xC8, 0xCA, 0xCC, 0xCE, 0xD0, 0xD2, 0x00};

void view_oled_promo() {
    // SSD1306_BASE_OFF();
    SSD1306_BASE_ClearScreen (1);

    SSD1306_BASE_SetWrapMode (NOWRAP);

    for (int row_index = 0; row_index < 8; row_index++) {

        // Счетчик строк инверсный
        SSD1306_BASE_SetCursor (0, row_index);
        SSD1306_BASE_PutSymbol (0x30 + row_index, SSD1306_SYMSTYLE_NOALIGN | SSD1306_SYMSTYLE_INV);
    }

    // Wide LED строка
    SSD1306_BASE_SetCursor (2, 4);
    SSD1306_BASE_WriteStr ((uint8_t *)led_str2, SSD1306_SYMSTYLE_WIDTHLED | SSD1306_SYMSTYLE_NOCYR);

    // Широкие символы
    SSD1306_BASE_SetCursor (2, 0);
    SSD1306_BASE_WriteStr ((uint8_t *)"МЕГА", SSD1306_SYMSTYLE_WIDE);

    SSD1306_BASE_SetCursor (2, 2);
    SSD1306_SetStr_Limit (9);
    SSD1306_BASE_WriteStr ((uint8_t *)led_str2, SSD1306_SYMSTYLE_LED | SSD1306_SYMSTYLE_NOCYR);

    // Обычные символы
    SSD1306_BASE_SetCursor (11, 1);
    SSD1306_BASE_WriteStr ((uint8_t *)"Вверх", SSD1306_SYMSTYLE_NORM);

    // Обычные символы
    SSD1306_BASE_SetCursor (11, 2);
    SSD1306_BASE_WriteStr ((uint8_t *)"Вниз-", SSD1306_SYMSTYLE_NORM);

    // SSD1306_BASE_ON();
}
#endif
// ----------------------------------------------------------------------------

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main (void) {
    //-------------------------------------------------------------------------
    NVIC_PriorityGroupConfig (NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();
    //-------------------------------------------------------------------------
#ifdef USE_W25Q_DEBUG
    SDI_Printf_Enable();
    printf ("SystemClk:%u\r\n", (unsigned int)SystemCoreClock);
    printf ("ChipID:%08x\r\n", (unsigned int)DBGMCU_GetCHIPID());
#endif
    //-------------------------------------------------------------------------
    Delay_Ms (500);
    //-------------------------------------------------------------------------
    // Инициализация механизма SPI/Flash
    W25_Init();
    uint32_t _FlashID = W25_ReadID();
    //-------------------------------------------------------------------------
#ifdef USE_W25Q_DEBUG
    printf ("FlashID:%08x\r\n", (unsigned int)_FlashID);
#endif
    //-------------------------------------------------------------------------
    if (W25_InitHardware (_FlashID) == 0) {

        // Блокирование работы программы
#ifdef USE_W25Q_DEBUG
        printf ("ERROR: Unknown FlashID:%08x\r\n", (unsigned int)_FlashID);
        printf ("Stopped...");
#endif
        // Ошибка 404 - нет флеш памяти!
        // xproto_resetBufferData();
        // xproto_sendStr ((uint8_t *)"ERRXP:404", 9, 1);

        while (1) { Delay_Ms (1000); }
    }
    // ------------------------------------------------------------------------
#ifdef USE_TFT_ST7789
    // Инициализация TFT дисплея
    ST7789_SPI_Init();
    ST7789_Init_Landscape();
    // Вывод тестовой графики
    view_promo();
    // ------------------------------------------------------------------------    
#endif
    //-------------------------------------------------------------------------
#ifdef USE_OLED_SSD1306
    SSD1306_BASE_Init (0xCF);
    view_oled_promo();
#endif
    //-------------------------------------------------------------------------
    // UART
    UART_UNIT_Init (115200);
    //-------------------------------------------------------------------------
    //xproto_setReadyToReceive();
#ifdef USE_W25Q_DEBUG
    printf ("Running (v_CH32V003)...\r\n");
#endif
    //-------------------------------------------------------------------------
#ifdef USE_SOUND_GEN
    Play_SoundInit();
#endif
    //-------------------------------------------------------------------------
    while (1) {
        // Выполняем обработку очереди сообщений
        xproto_processingCommand();

        Delay_Ms(100);
    }
    //-------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
